# Distribution Builder 1.0.0

Builds a complete Elementor distribution site in one click:
one random **global kit** (site settings, header, footer, home banner, page banner, CTA)
plus one random **component** per section slot, always in the same section order,
with a full **build track** of every pick.

## 1. Install

1. Fresh WordPress → install and activate **Hello Elementor**, **Elementor 4.2.x**, **Elementor Pro 4.2.x** (licensed),
   **WooCommerce** (setup wizard done), **ElementsKit Lite**, **Skyboot Custom Icons** (same versions as the source sites).
2. Plugins → Add New → Upload → `distribution-builder.zip` → Activate.
3. Open **Distribution Builder** in the admin menu → **Check requirements**.

The plugin ships with a **dummy library** (4 kits, 3 components per slot, offline images), so you can run a
complete build right away. Every dummy section shows a label like `DUMMY · home / section_2 / comp_1`.

## 2. Build a site

**Build screen:** brand name (required), email, phone, address, logo → **Plan build** (picks everything,
validates every picked file, writes nothing) → **Build site**. Each step is its own request, so nothing times out.
If a step fails: read the error, fix it, press **Retry failed step** (it removes what the step half-made first).
Closing the tab is safe: come back and press **Continue**.

**WP-CLI:**

```
wp distb check
wp distb plan  --seed=83920144                       # preview picks, writes nothing
wp distb build --brand="New Brand Distribution" --email=info@newbrand.com --phone="+1 555 010 0100" --yes
wp distb build --brand="New Brand" --seed=83920144 --kit=3 --yes     # reproduce / force a kit
wp distb build --brand="New Brand" --from-track=track-db-....json --yes  # exact replay
wp distb resume --retry
wp distb track
wp distb reset --yes
```

## 3. What one build makes

| Item | Source |
|---|---|
| Kit settings (colors, fonts, buttons, layout) | `global_kits/site_N/site-settings.json` |
| Header + Footer (Theme Builder, Entire Site) | `site_N/header_dist.json`, `footer_dist.json` |
| Loop Item template | random `components/loop_item` |
| Single Product template (All Products) | `site_N/page_banner` (title = Post Title tag) + random `components/single` |
| Home | `home_banner` · random `home/section_2…10` · `cta` |
| About Us | `page_banner` · random `about/section_2…6` · `cta` |
| Brands / Product Categories / FAQs / Contact Us / Products | `page_banner` (H1 = page title) · random `brands` / `category_card` / `faq` / `contact` / `products` |
| Main Menu, front page, site title, permalinks, logo | generated |

Pages are **published WordPress pages** (Elementor Full Width), editable in Elementor. Templates are built
before pages because the Products page's loop grid needs the Loop Item ID.

Recipes live in `includes/recipes.php` (or the `distb_recipes` filter). `product_archive`
(using `components/category`) is included but **off**; set `'enabled' => true` to use it.

## 4. What every section goes through

- **Format detection**: clipboard copy (`elements`), template export (`content`), kit export (`settings`), or raw `_elementor_data`.
- **Caches stripped**: `htmlCache`, `editSettings`, `defaultEditSettings`, `isLocked`.
- **New element IDs** for the whole page (sections from different sites share IDs).
- **Globals check**: `globals/colors?id=…` that the picked kit doesn't define are removed (WARN in track).
- **Media**: every `/wp-content/uploads/` image imported once (media pack first, else download), `id` + `url` remapped. A failed image never stops the build; it stays remote (WARN).
- **Links** to any of the 67 source domains → this site (same slugs). Upload URLs are left to the media step.
- **Emails** on source domains, `mailto:` → new email. **Phones**: `tel:` links, phone-only strings and US-format numbers → new phone (if none entered, the track lists how many are left).
- **Brand names** derived from each domain (`treasuresdistribution` matches "Treasures Distribution", "Treasures%20Distribution") + `registry/sources.json` names → new brand.
- **Copyright** lines in header/footer → `Copyright © YEAR Brand. All rights reserved.`
- **Tokens** you can write into library files: `{{brand_name}} {{site_url}} {{site_host}} {{email}} {{phone}} {{phone_link}} {{address}} {{year}}`.
- **References**: nav-menu → `main-menu`; loop-grid/carousel → new Loop Item; other source template IDs removed; source product/category IDs in queries cleared; header/footer image with "logo" in its file name → your logo.
- **Kit**: Woo page IDs replaced with this site's, `site_name` / `site_logo` set.

## 5. Randomness and the track

`random_build_site_no` and every component are picked with `sha256(seed | slot)` from **the list of files that exist**,
so a pick is always 1…N (20 files → 1…20; gaps like a deleted `comp_7` are skipped). Same seed + same library = same site.

```
global_kits > site_3                                      (pick 3 of 67)
LOOP ITEM  components > loop_item > comp_4                (pick 4 of 9)     OK  post 43
PAGE FAQs (post 49)   OK
  sec_1      global_kits > site_3 > page_banner
  sec_2      components > faq > comp_2                    (pick 2 of 12)
WARN       globals   components > about > section_4 > comp_9   missing colors?id=7a1b2c3 (removed)
```

Tracks: Build screen (Copy / Download JSON), History tab, `wp distb track`, and
`wp-content/uploads/distribution-builder/track-<build_id>.txt|.json` (folder protected from the web).

## 6. Your real library

```
lib/
  registry/sources.json         67 source domains (pre-filled) + per-kit brand/email/phone + extra names
  global_kits/site_1 … site_67/ site-settings, manifest, header_dist, footer_dist, home_banner, page_banner, cta
  components/home/section_2…10/comp_N.json, about/section_2…6/, brands/, category_card/, faq/,
             contact/, products/, loop_item/, single/, category/
  media/                        optional media pack: files + media-map.json
```

**Fastest way to fill it — extract from each finished source site** (install this plugin there):

```
wp distb library extract --site=3 --out=/path/to/lib     # kit, header, footer, banners, CTA, all sections,
                                                         # loop item, single product, registry entry
wp distb library extract --site=3 --out=/path/to/lib --pages=about-us=12,faqs=40   # if slugs differ
```

Pages are split **by position** (Home must have 11 top-level blocks, About Us 7). A page with a different
count goes to `components/_unsorted/` for you to sort by hand, instead of landing in wrong slots.
Components are named after their source site (`comp_3.json` = from site_3), so the track tells you the source.
Extracted files hold Elementor's compact saved data (clipboard copies also carry every default setting, about 600 per container, so they are much larger).

Then, on the builder site:

```
wp distb library validate     # parses every file: invalid JSON, empty slots, unknown widgets,
                              # kits whose global IDs differ, duplicate sections, format A where B is needed
wp distb library media-pack   # download every image into lib/media (builds then work offline and fast)
```

Delete the dummy `site_1…site_4` folders and dummy components when you add real ones, and remove
the dummy `kits` entries in `registry/sources.json`.
Large library? Keep it outside the plugin: `define( 'DISTB_LIB_DIR', '/path/to/lib' );` in wp-config.php.

## 7. 40 sites in a day

1. Make one **base site** (WordPress + theme + all plugins licensed + WooCommerce set up + this plugin + library + media pack). Export it with All-in-One WP Migration.
2. `wp distb batch-plan --count=40 --out=batch.csv` → one seed and a **different kit** per site. Fill in brand/email/phone.
3. Per site (~10 min): new WordPress → import base → Build with the row's seed and kit → quick check → keep the track file next to the CSV row.

## 8. Reset

Reset tab or `wp distb reset`: deletes every page/template/menu/image the build made (meta `_distb_build_id`),
restores pages it updated, kit settings, front page, title, permalinks, menu locations and logo.
Content the build did not make is never touched. A new build on the same site removes the previous one first
(keeping media) unless you untick "Replace the previous build".

## 9. Known limits

- Tested on WordPress 6.5 with an Elementor/Pro/WooCommerce **API test double**. Run your first build
  on a staging copy with real Elementor Pro 4.2 before the batch.
- Loop Item source is set with `_elementor_source = product` (best effort). If the editor preview shows posts,
  open the Loop Item once and set its source to Products; library loop items exported from Theme Builder (format B) keep their own setting.
- Mixed sections get the base kit's colors and fonts only where they use **kit globals**; hard-coded colors stay.
