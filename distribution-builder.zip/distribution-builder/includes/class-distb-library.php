<?php
/**
 * Reads the design library: global kits, component folders and the source registry.
 * Counts are always read from disk, never hard-coded.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'DISTB_TESTING' ) ) {
	exit;
}

class DistB_Library {

	/** @var string Library root with trailing slash. */
	private $root;

	/** @var array|null */
	private $sources = null;

	/** @var array */
	private $list_cache = array();

	public function __construct( $root ) {
		$this->root = rtrim( $root, '/\\' ) . '/';
	}

	public function root() {
		return $this->root;
	}

	public function exists() {
		return is_dir( $this->root . 'global_kits' ) && is_dir( $this->root . 'components' );
	}

	/**
	 * Kit folder names that exist, in natural order: site_1, site_2, ... site_67.
	 *
	 * @return string[]
	 */
	public function kits() {
		if ( isset( $this->list_cache['__kits'] ) ) {
			return $this->list_cache['__kits'];
		}
		$out  = array();
		$dirs = glob( $this->root . 'global_kits/site_*', GLOB_ONLYDIR );
		foreach ( (array) $dirs as $dir ) {
			$name = basename( $dir );
			if ( preg_match( '/^site_\d+$/', $name ) ) {
				$out[] = $name;
			}
		}
		$out                          = distb_natsort( $out );
		$this->list_cache['__kits'] = $out;
		return $out;
	}

	/**
	 * Path of a kit file relative to the library root.
	 *
	 * @param string $kit  Kit folder (site_3).
	 * @param string $file File key without extension (home_banner).
	 * @return string
	 */
	public function kit_file( $kit, $file ) {
		return 'global_kits/' . $kit . '/' . $file . '.json';
	}

	/**
	 * Component files in a slot folder (relative paths), natural order.
	 * Only comp_<number>.json files count. Gaps (comp_4 deleted) are fine.
	 *
	 * @param string $slot Slot key, such as "home/section_2" or "faq".
	 * @return string[]
	 */
	public function components( $slot ) {
		$slot = trim( $slot, '/' );
		if ( isset( $this->list_cache[ $slot ] ) ) {
			return $this->list_cache[ $slot ];
		}
		$this->assert_safe( $slot );
		$names = array();
		$files = glob( $this->root . 'components/' . $slot . '/comp_*.json' );
		foreach ( (array) $files as $file ) {
			$name = basename( $file );
			if ( preg_match( '/^comp_\d+\.json$/i', $name ) && is_file( $file ) ) {
				$names[] = $name;
			}
		}
		$names = distb_natsort( $names );
		$out   = array();
		foreach ( $names as $name ) {
			$out[] = 'components/' . $slot . '/' . $name;
		}
		$this->list_cache[ $slot ] = $out;
		return $out;
	}

	/**
	 * Absolute path of a library-relative path, refusing anything outside the library.
	 *
	 * @param string $relative Relative path.
	 * @return string
	 * @throws DistB_Exception On traversal.
	 */
	public function path( $relative ) {
		$this->assert_safe( $relative );
		return $this->root . ltrim( $relative, '/' );
	}

	private function assert_safe( $relative ) {
		if ( false !== strpos( $relative, '..' ) || false !== strpos( $relative, "\0" ) || preg_match( '#^[a-z]+:#i', $relative ) ) {
			throw new DistB_Exception( 'Unsafe library path', array( 'file' => $relative ) );
		}
	}

	/**
	 * Every slot key the recipes use, grouped by kind.
	 *
	 * @param array $recipes Recipes.
	 * @return array{kit:string[],random:string[]}
	 */
	public static function recipe_slots( array $recipes ) {
		$kit    = array();
		$random = array();
		$groups = array();
		foreach ( $recipes['templates'] as $tpl ) {
			if ( ! empty( $tpl['enabled'] ) ) {
				$groups[] = $tpl['slots'];
			}
		}
		foreach ( $recipes['pages'] as $page ) {
			$groups[] = $page['slots'];
		}
		foreach ( $groups as $slots ) {
			foreach ( $slots as $slot ) {
				if ( 'kit' === $slot[0] ) {
					$kit[ $slot[1] ] = true;
				} else {
					$random[ $slot[1] ] = true;
				}
			}
		}
		return array(
			'kit'    => array_keys( $kit ),
			'random' => array_keys( $random ),
		);
	}

	/**
	 * Structural check without parsing files: kits present, kit files present, no empty slot.
	 *
	 * @param array $recipes Recipes.
	 * @return array{errors:string[],warnings:string[],counts:array}
	 */
	public function check_structure( array $recipes ) {
		$errors   = array();
		$warnings = array();
		$counts   = array();

		if ( ! $this->exists() ) {
			$errors[] = 'Library not found at ' . $this->root . ' (needs global_kits/ and components/).';
			return compact( 'errors', 'warnings', 'counts' );
		}

		$kits = $this->kits();
		if ( ! $kits ) {
			$errors[] = 'No kit folders (site_1, site_2, ...) in global_kits/.';
		}
		$counts['global_kits'] = count( $kits );

		// Gaps in kit numbering are allowed but reported, because the user expects 1..N.
		$numbers = array_map(
			function ( $k ) {
				return (int) substr( $k, 5 );
			},
			$kits
		);
		if ( $numbers && max( $numbers ) !== count( $numbers ) ) {
			$warnings[] = 'Kit numbering has gaps (highest site_' . max( $numbers ) . ', count ' . count( $numbers ) . '). Picks use the folders that exist.';
		}

		$needed = array_unique( array_merge( $recipes['kit_files'], self::recipe_slots( $recipes )['kit'] ) );
		foreach ( $kits as $kit ) {
			foreach ( $needed as $file ) {
				if ( ! is_file( $this->path( $this->kit_file( $kit, $file ) ) ) ) {
					$errors[] = 'Missing ' . $this->kit_file( $kit, $file );
				}
			}
		}

		foreach ( self::recipe_slots( $recipes )['random'] as $slot ) {
			$n                                = count( $this->components( $slot ) );
			$counts[ 'components/' . $slot ] = $n;
			if ( 0 === $n ) {
				$errors[] = 'Empty slot: components/' . $slot . ' has no comp_N.json files.';
			}
		}

		return compact( 'errors', 'warnings', 'counts' );
	}

	/**
	 * Checksum of the library file list (names and sizes). Changes when any file is added, removed or edited.
	 *
	 * @return string 7 characters.
	 */
	public function checksum() {
		$parts = array();
		$iter  = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $this->root, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $iter as $file ) {
			if ( $file->isFile() && 'json' === strtolower( $file->getExtension() ) ) {
				$rel = substr( $file->getPathname(), strlen( $this->root ) );
				if ( 0 === strpos( $rel, 'registry/library-index' ) ) {
					continue;
				}
				$parts[] = str_replace( '\\', '/', $rel ) . ':' . $file->getSize();
			}
		}
		sort( $parts );
		return substr( sha1( implode( '|', $parts ) ), 0, 7 );
	}

	/**
	 * Source registry (registry/sources.json): domains to rewrite, brand names, emails, phones.
	 *
	 * @return array
	 */
	public function sources() {
		if ( null !== $this->sources ) {
			return $this->sources;
		}
		$data = array();
		$file = $this->root . 'registry/sources.json';
		if ( is_file( $file ) ) {
			try {
				$data = distb_read_json( $file );
			} catch ( DistB_Exception $e ) {
				$data = array();
			}
		}
		$data = array_merge(
			array(
				'domains'           => array(),
				'kits'              => array(),
				'extra_brand_names' => array(),
				'extra_emails'      => array(),
				'extra_phones'      => array(),
			),
			$data
		);
		$domains = array();
		foreach ( (array) $data['domains'] as $d ) {
			$d = distb_clean_domain( $d );
			if ( '' !== $d ) {
				$domains[ $d ] = true;
			}
		}
		foreach ( (array) $data['kits'] as $kit ) {
			if ( ! empty( $kit['domain'] ) ) {
				$domains[ distb_clean_domain( $kit['domain'] ) ] = true;
			}
		}
		$data['domains'] = array_keys( $domains );
		$this->sources   = $data;
		return $data;
	}

	/**
	 * Read the "siteurl" of a format A file cheaply (first 1 KB) to know its source domain.
	 *
	 * @param string $relative Relative path.
	 * @return string Domain or ''.
	 */
	public function sniff_source_domain( $relative ) {
		$path = $this->path( $relative );
		$fh   = @fopen( $path, 'rb' ); // phpcs:ignore
		if ( ! $fh ) {
			return '';
		}
		$head = fread( $fh, 1024 ); // phpcs:ignore
		fclose( $fh ); // phpcs:ignore
		if ( preg_match( '#"siteurl"\s*:\s*"(https?:[^"]+)"#', (string) $head, $m ) ) {
			return distb_host( stripslashes( $m[1] ) );
		}
		return '';
	}
}
