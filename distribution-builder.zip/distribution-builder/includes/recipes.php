<?php
/**
 * Page and template recipes: the ordered slot list for every page and Theme Builder template.
 *
 * Slot = array( kind, key )
 *   kind 'kit'    → file "<key>.json" from the picked global kit folder (global_kits/site_N/).
 *   kind 'random' → one random file from components/<key>/.
 *
 * Positions never change. Only the file in each random slot is random.
 * Use the 'distb_recipes' filter to change recipes without editing this file.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'DISTB_TESTING' ) ) {
	exit;
}

$distb_home_slots = array( array( 'kit', 'home_banner' ) );
for ( $distb_n = 2; $distb_n <= 10; $distb_n++ ) {
	$distb_home_slots[] = array( 'random', 'home/section_' . $distb_n );
}
$distb_home_slots[] = array( 'kit', 'cta' );

$distb_about_slots = array( array( 'kit', 'page_banner' ) );
for ( $distb_n = 2; $distb_n <= 6; $distb_n++ ) {
	$distb_about_slots[] = array( 'random', 'about/section_' . $distb_n );
}
$distb_about_slots[] = array( 'kit', 'cta' );

return array(

	// Files every global kit folder must contain.
	'kit_files' => array( 'site-settings', 'header_dist', 'footer_dist', 'home_banner', 'page_banner', 'cta' ),

	// Theme Builder templates, built in this order BEFORE the pages
	// (the Products page's loop grid needs the Loop Item template ID).
	'templates' => array(
		'header'          => array(
			'title'      => 'Site Header',
			'type'       => 'header',
			'slots'      => array( array( 'kit', 'header_dist' ) ),
			'conditions' => array( 'include/general' ),
			'enabled'    => true,
		),
		'footer'          => array(
			'title'      => 'Site Footer',
			'type'       => 'footer',
			'slots'      => array( array( 'kit', 'footer_dist' ) ),
			'conditions' => array( 'include/general' ),
			'enabled'    => true,
		),
		'loop_item'       => array(
			'title'      => 'Product Loop Item',
			'type'       => 'loop-item',
			'slots'      => array( array( 'random', 'loop_item' ) ),
			'conditions' => array(),
			'enabled'    => true,
		),
		'single_product'  => array(
			'title'        => 'Single Product',
			'type'         => 'product',
			'slots'        => array( array( 'kit', 'page_banner' ), array( 'random', 'single' ) ),
			'conditions'   => array( 'include/product' ),
			'banner_title' => 'dynamic', // Banner heading becomes the Post Title dynamic tag.
			'enabled'      => true,
		),
		// Not in the original plan. Turn on to use components/category as a product category archive.
		'product_archive' => array(
			'title'        => 'Product Category Archive',
			'type'         => 'product-archive',
			'slots'        => array( array( 'kit', 'page_banner' ), array( 'random', 'category' ) ),
			'conditions'   => array( 'include/product_archive' ),
			'banner_title' => 'dynamic_archive',
			'enabled'      => false,
		),
	),

	// Published WordPress pages (not templates), Elementor Full Width, in build order.
	'pages'     => array(
		'home'               => array(
			'title' => 'Home',
			'slots' => $distb_home_slots,
		),
		'about-us'           => array(
			'title' => 'About Us',
			'slots' => $distb_about_slots,
		),
		'brands'             => array(
			'title' => 'Brands',
			'slots' => array( array( 'kit', 'page_banner' ), array( 'random', 'brands' ) ),
		),
		'product-categories' => array(
			'title' => 'Product Categories',
			'slots' => array( array( 'kit', 'page_banner' ), array( 'random', 'category_card' ) ),
		),
		'faqs'               => array(
			'title' => 'FAQs',
			'slots' => array( array( 'kit', 'page_banner' ), array( 'random', 'faq' ) ),
		),
		'contact-us'         => array(
			'title' => 'Contact Us',
			'slots' => array( array( 'kit', 'page_banner' ), array( 'random', 'contact' ) ),
		),
		'products'           => array(
			'title' => 'Products',
			'slots' => array( array( 'kit', 'page_banner' ), array( 'random', 'products' ) ),
		),
	),

	// Main Menu order (page slugs).
	'menu'      => array( 'home', 'about-us', 'products', 'product-categories', 'brands', 'faqs', 'contact-us' ),
);
