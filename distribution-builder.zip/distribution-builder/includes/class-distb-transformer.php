<?php
/**
 * Turns library JSON into clean Elementor data for the new site.
 *
 * Pipeline for every section:
 *   load (format A/B/C) → strip caches → banner title → globals check → media remap
 *   → links, emails, phones, brand names, tokens → widget references (menu, loop, query IDs, logo)
 *   → new element IDs for the whole document.
 *
 * No WordPress calls: the context passes in everything site-specific, so this class is unit tested.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'DISTB_TESTING' ) ) {
	exit;
}

class DistB_Transformer {

	/** Keys removed from every element: rendered HTML caches and editor state from the source site. */
	const STRIP_KEYS = array( 'htmlCache', 'defaultEditSettings', 'editSettings', 'isLocked' );

	/** @var array */
	private $ctx;

	/** @var array Compiled regexes. */
	private $re = array();

	/** @var array Brand name regexes, keyed by the name squashed to lower-case letters and digits. */
	private $brand_res = array();

	/** @var array Warnings: list of array( type, file, message ). */
	public $warnings = array();

	/** @var array Counters for the track. */
	public $stats = array(
		'links'          => 0,
		'emails'         => 0,
		'phones'         => 0,
		'phones_left'    => 0,
		'brands'         => 0,
		'tokens'         => 0,
		'media'          => 0,
		'media_remote'   => 0,
		'globals_kept'   => 0,
		'globals_cut'    => 0,
		'query_cleared'  => 0,
		'menus'          => 0,
		'loops'          => 0,
		'template_refs'  => 0,
		'copyright'      => 0,
	);

	/** @var string Current file, for warnings. */
	private $file = '';

	/** @var array Current slot options. */
	private $slot_opts = array();

	/**
	 * @param array $ctx Context:
	 *   home_url (no trailing slash), brand, email, phone, address, year,
	 *   source_domains string[], extra_brand_names string[], extra_emails string[], extra_phones string[],
	 *   kit_global_ids array{colors:array,typography:array},
	 *   media_lookup callable(string $url): ?array{id:int,url:string},
	 *   menu_slug, loop_template_id, logo ?array{id,url}, woo_pages array.
	 */
	public function __construct( array $ctx ) {
		$this->ctx = array_merge(
			array(
				'home_url'          => '',
				'brand'             => '',
				'email'             => '',
				'phone'             => '',
				'address'           => '',
				'year'              => gmdate( 'Y' ),
				'source_domains'    => array(),
				'extra_brand_names' => array(),
				'extra_emails'      => array(),
				'extra_phones'      => array(),
				'kit_global_ids'    => array(),
				'media_lookup'      => null,
				'menu_slug'         => 'main-menu',
				'loop_template_id'  => 0,
				'logo'              => null,
				'woo_pages'         => array(),
			),
			$ctx
		);
		$this->ctx['home_url'] = rtrim( $this->ctx['home_url'], '/' );
		$this->ctx['host']     = distb_host( $this->ctx['home_url'] );
		if ( '' === $this->ctx['email'] && '' !== $this->ctx['host'] ) {
			$this->ctx['email'] = 'info@' . $this->ctx['host'];
		}
		$this->compile();
	}

	/* ------------------------------------------------------------------ */
	/* Loading                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * Load any of the three library formats.
	 *   A  clipboard copy:   { type: "elementor", siteurl, elements: [] }
	 *   B  template export:  { content: [], page_settings, version, title, type }
	 *   C  kit export:       { settings: {}, content: [], metadata, ... }
	 *
	 * @param string $path Absolute path.
	 * @return array{format:string,elements:array,page_settings:array,settings:array,siteurl:string,type:string}
	 * @throws DistB_Exception On a file the builder cannot use.
	 */
	public static function load( $path ) {
		$data = distb_read_json( $path );

		$out = array(
			'format'        => '',
			'elements'      => array(),
			'page_settings' => array(),
			'settings'      => array(),
			'siteurl'       => '',
			'type'          => isset( $data['type'] ) && is_string( $data['type'] ) ? $data['type'] : '',
		);

		if ( distb_is_list( $data ) && $data && isset( $data[0]['elType'] ) ) {
			// Raw _elementor_data array (from "wp post meta get").
			$out['format']   = 'raw';
			$out['elements'] = $data;
		} elseif ( isset( $data['elements'] ) && is_array( $data['elements'] ) ) {
			$out['format']   = 'A';
			$out['elements'] = $data['elements'];
			$out['siteurl']  = isset( $data['siteurl'] ) ? (string) $data['siteurl'] : '';
		} elseif ( isset( $data['settings'] ) && is_array( $data['settings'] ) && ! isset( $data['page_settings'] ) ) {
			$out['format']   = 'C';
			$out['settings'] = $data['settings'];
		} elseif ( isset( $data['content'] ) && is_array( $data['content'] ) ) {
			$out['format']        = 'B';
			$out['elements']      = $data['content'];
			$out['page_settings'] = isset( $data['page_settings'] ) && is_array( $data['page_settings'] ) && ! distb_is_list( $data['page_settings'] ) ? $data['page_settings'] : array();
		} else {
			throw new DistB_Exception( 'Not an Elementor file (no "elements", "content" or "settings")', array( 'file' => $path ) );
		}

		if ( 'C' !== $out['format'] ) {
			if ( ! distb_is_list( $out['elements'] ) ) {
				throw new DistB_Exception( 'Elements are not a list', array( 'file' => $path ) );
			}
			foreach ( $out['elements'] as $i => $el ) {
				if ( ! is_array( $el ) || empty( $el['elType'] ) ) {
					throw new DistB_Exception( 'Element ' . $i . ' has no elType', array( 'file' => $path ) );
				}
			}
			$out['elements'] = array_map( array( __CLASS__, 'strip' ), $out['elements'] );
		}
		return $out;
	}

	/**
	 * Remove rendered caches and editor state, recursively. Normalise settings and elements.
	 *
	 * @param array $el Element.
	 * @return array
	 */
	public static function strip( array $el ) {
		foreach ( self::STRIP_KEYS as $key ) {
			unset( $el[ $key ] );
		}
		if ( ! isset( $el['settings'] ) || ! is_array( $el['settings'] ) ) {
			$el['settings'] = array();
		}
		$children = isset( $el['elements'] ) && is_array( $el['elements'] ) ? $el['elements'] : array();
		$clean    = array();
		foreach ( $children as $child ) {
			if ( is_array( $child ) ) {
				$clean[] = self::strip( $child );
			}
		}
		$el['elements'] = $clean;
		if ( ! isset( $el['isInner'] ) ) {
			$el['isInner'] = false;
		}
		return $el;
	}

	/* ------------------------------------------------------------------ */
	/* Inspection helpers                                                  */
	/* ------------------------------------------------------------------ */

	/**
	 * Widget types used in an element tree.
	 *
	 * @param array $elements Elements.
	 * @return string[]
	 */
	public static function widget_types( array $elements ) {
		$types = array();
		$walk  = function ( $list ) use ( &$walk, &$types ) {
			foreach ( $list as $el ) {
				if ( isset( $el['elType'] ) && 'widget' === $el['elType'] && ! empty( $el['widgetType'] ) ) {
					$types[ $el['widgetType'] ] = true;
				}
				if ( ! empty( $el['elements'] ) ) {
					$walk( $el['elements'] );
				}
			}
		};
		$walk( $elements );
		return array_keys( $types );
	}

	/**
	 * Element types (container, section, column) used in an element tree.
	 *
	 * @param array $elements Elements.
	 * @return string[]
	 */
	public static function element_types( array $elements ) {
		$types = array();
		$walk  = function ( $list ) use ( &$walk, &$types ) {
			foreach ( $list as $el ) {
				if ( isset( $el['elType'] ) && 'widget' !== $el['elType'] ) {
					$types[ $el['elType'] ] = true;
				}
				if ( ! empty( $el['elements'] ) ) {
					$walk( $el['elements'] );
				}
			}
		};
		$walk( $elements );
		return array_keys( $types );
	}

	/**
	 * Count every element in a tree.
	 *
	 * @param array $elements Elements.
	 * @return int
	 */
	public static function count_elements( array $elements ) {
		$n = 0;
		foreach ( $elements as $el ) {
			$n++;
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$n += self::count_elements( $el['elements'] );
			}
		}
		return $n;
	}

	/**
	 * Global color and font IDs defined by a kit.
	 *
	 * @param array $settings Kit settings.
	 * @return array{colors:array,typography:array}
	 */
	public static function kit_global_ids( array $settings ) {
		$ids = array(
			'colors'     => array(),
			'typography' => array(),
		);
		foreach ( array( 'system_colors', 'custom_colors' ) as $key ) {
			foreach ( isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array() as $item ) {
				if ( isset( $item['_id'] ) ) {
					$ids['colors'][ (string) $item['_id'] ] = true;
				}
			}
		}
		foreach ( array( 'system_typography', 'custom_typography' ) as $key ) {
			foreach ( isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array() as $item ) {
				if ( isset( $item['_id'] ) ) {
					$ids['typography'][ (string) $item['_id'] ] = true;
				}
			}
		}
		return $ids;
	}

	/**
	 * Global references in a tree that the kit does not define.
	 *
	 * @param array $elements Elements.
	 * @param array $ids      Kit IDs.
	 * @return string[] Such as "colors?id=7a1b2c3".
	 */
	public static function missing_globals( array $elements, array $ids ) {
		$missing = array();
		$walk    = function ( $node ) use ( &$walk, &$missing, $ids ) {
			if ( ! is_array( $node ) ) {
				return;
			}
			foreach ( $node as $key => $value ) {
				if ( '__globals__' === $key && is_array( $value ) ) {
					foreach ( $value as $ref ) {
						$parsed = DistB_Transformer::parse_global( $ref );
						if ( $parsed && ! isset( $ids[ $parsed[0] ][ $parsed[1] ] ) ) {
							$missing[ $parsed[0] . '?id=' . $parsed[1] ] = true;
						}
					}
				} elseif ( is_array( $value ) ) {
					$walk( $value );
				}
			}
		};
		$walk( $elements );
		return array_keys( $missing );
	}

	/**
	 * Parse "globals/colors?id=abc" into array( 'colors', 'abc' ).
	 *
	 * @param mixed $ref Reference.
	 * @return array|null
	 */
	public static function parse_global( $ref ) {
		if ( is_string( $ref ) && preg_match( '#^globals/(colors|typography)\?id=([A-Za-z0-9_-]+)$#', $ref, $m ) ) {
			return array( $m[1], $m[2] );
		}
		return null;
	}

	/**
	 * Every media URL (wp-content/uploads on another host) in a tree or settings array.
	 *
	 * @param array  $node      Elements or settings.
	 * @param string $site_host Current site host (its own uploads are skipped).
	 * @return string[]
	 */
	public static function collect_media_urls( array $node, $site_host ) {
		$urls = array();
		$walk = function ( $n ) use ( &$walk, &$urls, $site_host ) {
			foreach ( $n as $key => $value ) {
				if ( is_array( $value ) ) {
					$walk( $value );
				} elseif ( is_string( $value ) && false !== stripos( $value, '/wp-content/uploads/' ) ) {
					if ( preg_match_all( '#https?://[^\s"\'<>()\\\\]+/wp-content/uploads/[^\s"\'<>()\\\\]+#i', $value, $m ) ) {
						foreach ( $m[0] as $url ) {
							$url = rtrim( $url, '.,;' );
							if ( distb_host( $url ) !== $site_host && DistB_Transformer::is_media_url( $url ) ) {
								$urls[ $url ] = true;
							}
						}
					}
				}
			}
		};
		$walk( $node );
		return array_keys( $urls );
	}

	/**
	 * True for file types the media importer handles.
	 *
	 * @param string $url URL.
	 * @return bool
	 */
	public static function is_media_url( $url ) {
		$path = (string) parse_url( $url, PHP_URL_PATH ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return (bool) preg_match( '/\.(jpe?g|png|gif|webp|avif|svg|ico|bmp|mp4|webm|mov|pdf|json)$/i', $path );
	}

	/* ------------------------------------------------------------------ */
	/* Transform                                                           */
	/* ------------------------------------------------------------------ */

	/**
	 * Transform the elements of one slot.
	 *
	 * @param array  $elements Elements (already stripped by load()).
	 * @param string $file     Library-relative file, for warnings.
	 * @param array  $opts     banner_title: '' | page title text | 'dynamic' | 'dynamic_archive';
	 *                         is_chrome: true for header and footer (logo + copyright rules).
	 * @return array
	 */
	public function transform( array $elements, $file, array $opts = array() ) {
		$this->file      = $file;
		$this->slot_opts = array_merge(
			array(
				'banner_title' => '',
				'is_chrome'    => false,
			),
			$opts
		);

		if ( '' !== $this->slot_opts['banner_title'] ) {
			$elements = $this->set_banner_title( $elements, $this->slot_opts['banner_title'] );
		}

		$out = array();
		foreach ( $elements as $el ) {
			$out[] = $this->transform_element( $el );
		}
		return $out;
	}

	/**
	 * Transform kit settings (format C "settings").
	 *
	 * @param array $settings Settings.
	 * @return array
	 */
	public function transform_kit( array $settings ) {
		$this->file      = 'site-settings.json';
		$this->slot_opts = array(
			'banner_title' => '',
			'is_chrome'    => true,
		);
		unset( $settings['activeItemIndex'] );

		// Woo page IDs from the source site mean nothing here: use this site's pages.
		foreach ( $settings as $key => $value ) {
			if ( preg_match( '/^woocommerce_([a-z_]+)_page_id$/', $key, $m ) ) {
				$settings[ $key ] = isset( $this->ctx['woo_pages'][ $m[1] ] ) ? $this->ctx['woo_pages'][ $m[1] ] : '';
			}
		}

		$settings = $this->remap_media( $settings );
		$settings = $this->walk_strings( $settings );

		if ( '' !== $this->ctx['brand'] ) {
			$settings['site_name'] = $this->ctx['brand'];
		}
		if ( ! empty( $this->ctx['logo']['id'] ) ) {
			$settings['site_logo'] = array(
				'id'  => (int) $this->ctx['logo']['id'],
				'url' => $this->ctx['logo']['url'],
			);
		}
		return $settings;
	}

	/**
	 * Give every element in a document a new unique ID (sections from different source sites can share IDs).
	 *
	 * @param array $elements Elements.
	 * @param array $used     IDs in use (by reference).
	 * @return array
	 */
	public static function new_ids( array $elements, array &$used ) {
		$out = array();
		foreach ( $elements as $el ) {
			$el['id']       = distb_new_element_id( $used );
			$el['elements'] = self::new_ids( isset( $el['elements'] ) ? $el['elements'] : array(), $used );
			$out[]          = $el;
		}
		return $out;
	}

	private function transform_element( array $el ) {
		$settings = $el['settings'];

		$settings = $this->check_globals( $settings );
		$settings = $this->remap_media( $settings );
		$settings = $this->walk_strings( $settings );

		if ( isset( $el['elType'] ) && 'widget' === $el['elType'] && ! empty( $el['widgetType'] ) ) {
			$settings = $this->widget_rules( $el['widgetType'], $settings );
		}

		$el['settings'] = $settings;

		$children = array();
		foreach ( $el['elements'] as $child ) {
			$children[] = $this->transform_element( $child );
		}
		$el['elements'] = $children;
		return $el;
	}

	/**
	 * Keep global references the base kit defines; remove the others so Elementor uses the section's own values.
	 *
	 * @param array $settings Settings (any depth).
	 * @return array
	 */
	private function check_globals( array $settings ) {
		$ids = $this->ctx['kit_global_ids'];
		foreach ( $settings as $key => $value ) {
			if ( '__globals__' === $key && is_array( $value ) ) {
				foreach ( $value as $control => $ref ) {
					$parsed = self::parse_global( $ref );
					if ( ! $parsed ) {
						continue;
					}
					if ( ! $ids || isset( $ids[ $parsed[0] ][ $parsed[1] ] ) ) {
						$this->stats['globals_kept']++;
						continue;
					}
					unset( $settings['__globals__'][ $control ] );
					$this->stats['globals_cut']++;
					$this->warn( 'globals', 'missing ' . $parsed[0] . '?id=' . $parsed[1] . ' (removed)' );
				}
			} elseif ( is_array( $value ) ) {
				$settings[ $key ] = $this->check_globals( $value );
			}
		}
		return $settings;
	}

	/**
	 * Replace source media with the new site's attachments: {id, url} pairs and URLs inside text.
	 *
	 * @param array $node Settings.
	 * @return array
	 */
	private function remap_media( array $node ) {
		$lookup = $this->ctx['media_lookup'];

		if ( isset( $node['url'] ) && is_string( $node['url'] ) && false !== stripos( $node['url'], '/wp-content/uploads/' ) && distb_host( $node['url'] ) !== $this->ctx['host'] ) {
			$new = $lookup ? call_user_func( $lookup, $node['url'] ) : null;
			if ( $new ) {
				$node['url'] = $new['url'];
				if ( array_key_exists( 'id', $node ) ) {
					$node['id'] = (int) $new['id'];
				}
				if ( isset( $node['source'] ) ) {
					$node['source'] = 'library';
				}
				$this->stats['media']++;
			} else {
				// Keep the remote image but drop the source attachment ID, which points at nothing here.
				if ( array_key_exists( 'id', $node ) && '' !== $node['id'] ) {
					$node['id'] = '';
				}
				$this->stats['media_remote']++;
				$this->warn( 'media', 'not imported, kept remote ' . $node['url'] );
			}
		}

		foreach ( $node as $key => $value ) {
			if ( is_array( $value ) ) {
				$node[ $key ] = $this->remap_media( $value );
			} elseif ( is_string( $value ) && 'url' !== $key && false !== stripos( $value, '/wp-content/uploads/' ) && $lookup ) {
				$self         = $this;
				$node[ $key ] = preg_replace_callback(
					'#https?://[^\s"\'<>()\\\\]+/wp-content/uploads/[^\s"\'<>()\\\\]+#i',
					function ( $m ) use ( $lookup, $self ) {
						$url = rtrim( $m[0], '.,;' );
						$tail = substr( $m[0], strlen( $url ) );
						if ( distb_host( $url ) === $self->host() ) {
							return $m[0];
						}
						$new = call_user_func( $lookup, $url );
						if ( $new ) {
							$self->stats['media']++;
							return $new['url'] . $tail;
						}
						return $m[0];
					},
					$value
				);
			}
		}
		return $node;
	}

	/** @return string */
	public function host() {
		return $this->ctx['host'];
	}

	/**
	 * Apply text rules to every string leaf, except references (__globals__, __dynamic__).
	 *
	 * @param array $node Settings.
	 * @return array
	 */
	private function walk_strings( array $node ) {
		foreach ( $node as $key => $value ) {
			if ( '__globals__' === $key || '__dynamic__' === $key || '_id' === $key || 'id' === $key ) {
				continue;
			}
			if ( is_array( $value ) ) {
				$node[ $key ] = $this->walk_strings( $value );
			} elseif ( is_string( $value ) && '' !== $value && ! is_numeric( $value ) ) {
				$node[ $key ] = $this->replace_text( $value );
			}
		}
		return $node;
	}

	/**
	 * Build the regexes once per build.
	 */
	private function compile() {
		$domains = array();
		foreach ( (array) $this->ctx['source_domains'] as $d ) {
			$d = distb_clean_domain( $d );
			if ( '' !== $d && $d !== $this->ctx['host'] ) {
				$domains[ $d ] = true;
			}
		}
		$domains = array_keys( $domains );
		usort(
			$domains,
			function ( $a, $b ) {
				return strlen( $b ) - strlen( $a );
			}
		);

		$this->re = array();
		if ( $domains ) {
			$alt = implode( '|', array_map( 'preg_quote', $domains, array_fill( 0, count( $domains ), '~' ) ) );
			// Full URL on a source domain, but not its uploads (media is remapped separately).
			$this->re['url'] = '~https?://(?:www\.)?(?:' . $alt . ')(?::\d+)?(?![\w.-])(?!/wp-content/uploads/)~i';
			// Email on a source domain.
			$this->re['email'] = '~[A-Z0-9._%+-]+@(?:www\.)?(?:' . $alt . ')(?![\w.-])~i';
			// Bare domain in text ("treasuresdistribution.com").
			$this->re['bare'] = '~(?<![@/\w.-])(?:www\.)?(?:' . $alt . ')(?![\w-])(?!\.[a-z])~i';
		}

		// Brand names: each source domain name without its TLD, matched with optional spaces or dashes
		// between letters, so "treasuresdistribution" matches "Treasures Distribution" and "Treasures%20Distribution".
		$names = array();
		foreach ( $domains as $d ) {
			$slug = preg_replace( '/\..*$/', '', $d );
			if ( strlen( $slug ) >= 6 ) {
				$names[ strtolower( $slug ) ] = true;
			}
		}
		foreach ( (array) $this->ctx['extra_brand_names'] as $name ) {
			$slug = strtolower( preg_replace( '/[^A-Za-z0-9]/', '', (string) $name ) );
			if ( strlen( $slug ) >= 3 ) {
				$names[ $slug ] = true;
			}
		}
		$new_slug = strtolower( preg_replace( '/[^A-Za-z0-9]/', '', $this->ctx['brand'] ) );
		unset( $names[ $new_slug ] );
		$names = array_keys( $names );
		usort(
			$names,
			function ( $a, $b ) {
				return strlen( $b ) - strlen( $a );
			}
		);
		// One small regex per name (a single combined regex for 67+ names is too large for PCRE).
		$this->brand_res = array();
		if ( $names && '' !== $this->ctx['brand'] ) {
			$sep = '(?:\s|-|_|%20|&nbsp;|&amp;|&)*';
			foreach ( $names as $slug ) {
				$chars                    = str_split( $slug );
				$body                     = implode(
					$sep,
					array_map(
						function ( $c ) {
							return preg_quote( $c, '~' );
						},
						$chars
					)
				);
				$this->brand_res[ $slug ] = '~(?<![A-Za-z0-9])' . $body . '(?![A-Za-z0-9])~i';
			}
		}

		$extra_emails = array_filter( array_map( 'trim', (array) $this->ctx['extra_emails'] ) );
		if ( $extra_emails ) {
			$this->re['extra_email'] = '~(?<![\w.+-])(?:' . implode( '|', array_map( 'preg_quote', $extra_emails, array_fill( 0, count( $extra_emails ), '~' ) ) ) . ')(?![\w-])~i';
		}
		$extra_phones = array_filter( array_map( 'trim', (array) $this->ctx['extra_phones'] ) );
		if ( $extra_phones ) {
			$this->re['extra_phone'] = '~' . implode( '|', array_map( 'preg_quote', $extra_phones, array_fill( 0, count( $extra_phones ), '~' ) ) ) . '~';
		}

		// North American style phone number with separators: +1 917-773-2317, (917) 773 2317, 917.773.2317.
		$this->re['phone'] = '~(?<![\w+])(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}(?![\w])~';
		// A string that is only a phone number (international formats too).
		$this->re['phone_only'] = '~^\s*\+?\d{0,3}[\s.-]?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,5}\s*$~';
	}

	/**
	 * Text rules for one string, in a fixed order.
	 *
	 * @param string $s String.
	 * @return string
	 */
	private function replace_text( $s ) {
		$ctx = $this->ctx;
		$n   = 0;

		// 0. Tokens written into library files: {{brand_name}}, {{email}}, ...
		if ( false !== strpos( $s, '{{' ) ) {
			$map    = array(
				'{{brand_name}}' => $ctx['brand'],
				'{{site_url}}'   => $ctx['home_url'],
				'{{site_host}}'  => $ctx['host'],
				'{{email}}'      => $ctx['email'],
				'{{phone}}'      => $ctx['phone'],
				'{{phone_link}}' => 'tel:' . preg_replace( '/[^\d+]/', '', $ctx['phone'] ),
				'{{address}}'    => $ctx['address'],
				'{{year}}'       => $ctx['year'],
			);
			$before = $s;
			$s      = strtr( $s, $map );
			if ( $before !== $s ) {
				$this->stats['tokens']++;
			}
		}

		// 1. Links to any source site → this site (same slugs, so /contact-us/ keeps working).
		if ( isset( $this->re['url'] ) ) {
			$s                    = $this->rx( $this->re['url'], $ctx['home_url'], $s, $n );
			$this->stats['links'] += $n;
		}

		// 2. Emails.
		if ( isset( $this->re['email'] ) ) {
			$s                     = $this->rx( $this->re['email'], $ctx['email'], $s, $n );
			$this->stats['emails'] += $n;
		}
		if ( isset( $this->re['extra_email'] ) ) {
			$s                     = $this->rx( $this->re['extra_email'], $ctx['email'], $s, $n );
			$this->stats['emails'] += $n;
		}
		if ( 0 === stripos( $s, 'mailto:' ) && '' !== $ctx['email'] ) {
			$s = 'mailto:' . $ctx['email'];
		}

		// 3. Bare domains in text.
		if ( isset( $this->re['bare'] ) && '' !== $ctx['host'] ) {
			$s                    = $this->rx( $this->re['bare'], $ctx['host'], $s, $n );
			$this->stats['links'] += $n;
		}

		// 4. Phones.
		if ( '' !== $ctx['phone'] ) {
			$digits = preg_replace( '/[^\d+]/', '', $ctx['phone'] );
			if ( 0 === stripos( $s, 'tel:' ) ) {
				$this->stats['phones']++;
				return 'tel:' . $digits;
			}
			if ( isset( $this->re['extra_phone'] ) ) {
				$s                     = $this->rx( $this->re['extra_phone'], $ctx['phone'], $s, $n );
				$this->stats['phones'] += $n;
			}
			$plain = trim( html_entity_decode( strip_tags( $s ), ENT_QUOTES ) );
			if ( preg_match( $this->re['phone_only'], $plain ) && strlen( preg_replace( '/\D/', '', $plain ) ) >= 7 ) {
				$s = str_replace( $plain, $ctx['phone'], $s );
				$this->stats['phones']++;
			} else {
				$s                     = $this->rx( $this->re['phone'], $ctx['phone'], $s, $n );
				$this->stats['phones'] += $n;
			}
		} else {
			$this->stats['phones_left'] += preg_match_all( $this->re['phone'], $s );
		}

		// Links and IDs stop here: brand rules must not touch a URL path or slug.
		if ( preg_match( '~^\s*(https?:|/|#|mailto:|tel:|www\.)~i', $s ) ) {
			return $s;
		}

		// 5. Copyright line in header and footer.
		if ( ! empty( $this->slot_opts['is_chrome'] ) && '' !== $ctx['brand'] && false !== stripos( $s, 'all rights reserved' ) && strlen( strip_tags( $s ) ) < 220 ) {
			$line = 'Copyright © ' . $ctx['year'] . ' ' . $ctx['brand'] . '. All rights reserved.';
			if ( preg_match( '~^\s*<(p|span|div)(\s[^>]*)?>~i', $s, $m ) ) {
				$line = $m[0] . $line . '</' . $m[1] . '>';
			}
			if ( $s !== $line ) {
				$s = $line;
				$this->stats['copyright']++;
			}
		}

		// 6. Source brand names → new brand. Cheap substring check first, regex only for names present.
		if ( $this->brand_res ) {
			$squash = strtolower( preg_replace( '~(?:\s|-|_|%20|&nbsp;|&amp;|&)+~i', '', $s ) );
			foreach ( $this->brand_res as $slug => $re ) {
				if ( false !== strpos( $squash, (string) $slug ) ) {
					$s                     = $this->rx( $re, $ctx['brand'], $s, $n );
					$this->stats['brands'] += $n;
				}
			}
		}

		return $s;
	}

	/**
	 * preg_replace that never turns a string into null: on a regex failure the string is kept and a warning logged.
	 *
	 * @param string $re  Regex.
	 * @param string $rep Replacement.
	 * @param string $s   Subject.
	 * @param int    $n   Count (by reference).
	 * @return string
	 */
	private function rx( $re, $rep, $s, &$n ) {
		$n   = 0;
		$out = @preg_replace( $re, str_replace( array( '\\', '$' ), array( '\\\\', '\\$' ), $rep ), $s, -1, $n ); // phpcs:ignore
		if ( null === $out ) {
			$n = 0;
			$this->warn( 'regex', 'text rule skipped: ' . preg_last_error_msg() );
			return $s;
		}
		return $out;
	}

	/**
	 * Widget-specific references: menus, loop templates, other template IDs, query IDs, logos.
	 *
	 * @param string $type     Widget type.
	 * @param array  $settings Settings.
	 * @return array
	 */
	private function widget_rules( $type, array $settings ) {
		// Menus.
		if ( 'nav-menu' === $type ) {
			$settings['menu'] = $this->ctx['menu_slug'];
			$this->stats['menus']++;
		}
		if ( 'ekit-nav-menu' === $type || isset( $settings['elementskit_nav_menu'] ) ) {
			$settings['elementskit_nav_menu'] = $this->ctx['menu_slug'];
			$this->stats['menus']++;
		}

		// Loop grid / carousel → the new Loop Item template.
		if ( in_array( $type, array( 'loop-grid', 'loop-carousel' ), true ) ) {
			if ( $this->ctx['loop_template_id'] ) {
				$settings['template_id'] = (string) $this->ctx['loop_template_id'];
				$this->stats['loops']++;
			} else {
				$this->warn( 'template_ref', $type . ' has no Loop Item template to point at' );
			}
			if ( ! empty( $settings['alternate_templates'] ) ) {
				$settings['alternate_templates'] = array();
				$settings['alternate_template']  = '';
				$this->warn( 'template_ref', $type . ' alternate templates removed (they belong to the source site)' );
			}
		} elseif ( ! empty( $settings['template_id'] ) ) {
			unset( $settings['template_id'] );
			$this->stats['template_refs']++;
			$this->warn( 'template_ref', $type . ' pointed at source template; reference removed' );
		}

		// Product, post and category IDs from the source site → cleared, so widgets show this site's items.
		foreach ( $settings as $key => $value ) {
			if ( is_array( $value ) && $value && preg_match( '/(_ids|_authors)$/', $key ) && preg_match( '/(query|posts|include|exclude|term|product|categor|related|tag)/', $key ) ) {
				$settings[ $key ] = array();
				$this->stats['query_cleared']++;
			}
		}
		if ( 'wc-categories' === $type && isset( $settings['source'] ) && 'by_id' === $settings['source'] ) {
			$settings['source']     = '';
			$settings['categories'] = array();
			$this->stats['query_cleared']++;
		}

		// Logo in header and footer.
		if ( ! empty( $this->slot_opts['is_chrome'] ) && ! empty( $this->ctx['logo']['id'] ) && 'image' === $type && isset( $settings['image']['url'] ) ) {
			$name = strtolower( basename( (string) parse_url( $this->original_url( $settings['image'] ), PHP_URL_PATH ) ) ); // phpcs:ignore
			if ( false !== strpos( $name, 'logo' ) || false !== strpos( strtolower( (string) $settings['image']['url'] ), 'logo' ) ) {
				$settings['image'] = array_merge(
					$settings['image'],
					array(
						'id'  => (int) $this->ctx['logo']['id'],
						'url' => $this->ctx['logo']['url'],
					)
				);
			}
		}

		return $settings;
	}

	private function original_url( array $image ) {
		return isset( $image['url'] ) ? (string) $image['url'] : '';
	}

	/**
	 * Set the banner heading: the first H1 heading, or else the first heading, of the slot.
	 *
	 * @param array  $elements Elements.
	 * @param string $mode     Page title text, 'dynamic' or 'dynamic_archive'.
	 * @return array
	 */
	private function set_banner_title( array $elements, $mode ) {
		$path = $this->find_heading( $elements, 'h1' );
		if ( null === $path ) {
			$path = $this->find_heading( $elements, null );
		}
		if ( null === $path ) {
			$this->warn( 'banner', 'no heading found to set the title' );
			return $elements;
		}
		$ref = &$elements;
		foreach ( $path as $i => $idx ) {
			$ref = &$ref[ $idx ];
			if ( $i < count( $path ) - 1 ) {
				$ref = &$ref['elements'];
			}
		}
		if ( 'dynamic' === $mode || 'dynamic_archive' === $mode ) {
			$used = array();
			$tag  = 'dynamic' === $mode ? 'post-title' : 'archive-title';
			if ( ! isset( $ref['settings']['__dynamic__'] ) || ! is_array( $ref['settings']['__dynamic__'] ) ) {
				$ref['settings']['__dynamic__'] = array();
			}
			$ref['settings']['__dynamic__']['title'] = '[elementor-tag id="' . distb_new_element_id( $used ) . '" name="' . $tag . '" settings="%7B%7D"]';
		} else {
			$ref['settings']['title'] = $mode;
			if ( isset( $ref['settings']['__dynamic__']['title'] ) ) {
				unset( $ref['settings']['__dynamic__']['title'] );
			}
		}
		unset( $ref );
		return $elements;
	}

	/**
	 * Path (list of indexes) to the first heading widget, depth first.
	 *
	 * @param array       $elements Elements.
	 * @param string|null $size     Required header_size, or null for any.
	 * @return int[]|null
	 */
	private function find_heading( array $elements, $size ) {
		foreach ( $elements as $i => $el ) {
			if ( isset( $el['widgetType'] ) && 'heading' === $el['widgetType'] ) {
				$hs = isset( $el['settings']['header_size'] ) ? $el['settings']['header_size'] : 'h2';
				if ( null === $size || $hs === $size ) {
					return array( $i );
				}
			}
			if ( ! empty( $el['elements'] ) ) {
				$sub = $this->find_heading( $el['elements'], $size );
				if ( null !== $sub ) {
					return array_merge( array( $i ), $sub );
				}
			}
		}
		return null;
	}

	private function warn( $type, $message ) {
		$key                    = $type . '|' . $this->file . '|' . $message;
		$this->warnings[ $key ] = array( $type, $this->file, $message );
	}

	/**
	 * Warnings as a list, and reset.
	 *
	 * @return array
	 */
	public function take_warnings() {
		$out            = array_values( $this->warnings );
		$this->warnings = array();
		return $out;
	}
}
