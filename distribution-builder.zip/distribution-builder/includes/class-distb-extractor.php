<?php
/**
 * Library tools: validate the whole library, extract a library from a finished source site,
 * split a page export by position, build the media pack and plan a batch of sites.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DistB_Extractor {

	/** Page slug candidates on source sites (first match wins). */
	const PAGE_SLUGS = array(
		'home'               => array(),
		'about-us'           => array( 'about-us', 'about', 'who-we-are' ),
		'brands'             => array( 'brands', 'our-brands' ),
		'product-categories' => array( 'product-categories', 'categories', 'product-category', 'shop-by-category' ),
		'faqs'               => array( 'faqs', 'faq' ),
		'contact-us'         => array( 'contact-us', 'contact' ),
		'products'           => array( 'products', 'our-products' ),
	);

	/** Simple pages: page slug → components folder for the body. */
	const SIMPLE = array(
		'brands'             => 'brands',
		'product-categories' => 'category_card',
		'faqs'               => 'faq',
		'contact-us'         => 'contact',
		'products'           => 'products',
	);

	/* ------------------------------------------------------------------ */
	/* Validate                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * Parse every library file and report problems.
	 *
	 * @param DistB_Library $lib     Library.
	 * @param array         $recipes Recipes.
	 * @param callable|null $checker Unknown widget checker.
	 * @return array
	 */
	public static function validate_library( DistB_Library $lib, array $recipes, $checker = null ) {
		$errors     = array();
		$warnings   = array();
		$files      = 0;
		$widgets    = array();
		$where      = array();
		$hashes     = array();
		$duplicates = array();

		$struct   = $lib->check_structure( $recipes );
		$errors   = array_merge( $errors, $struct['errors'] );
		$warnings = array_merge( $warnings, $struct['warnings'] );

		$base_ids = null;
		$base_kit = '';
		foreach ( $lib->kits() as $kit ) {
			foreach ( $recipes['kit_files'] as $key ) {
				$rel = $lib->kit_file( $kit, $key );
				if ( ! is_file( $lib->path( $rel ) ) ) {
					continue; // Reported by check_structure.
				}
				$files++;
				try {
					$doc = DistB_Transformer::load( $lib->path( $rel ) );
					if ( 'site-settings' === $key ) {
						if ( 'C' !== $doc['format'] ) {
							$errors[] = $rel . ': not a kit export (needs a "settings" object).';
							continue;
						}
						$ids = DistB_Transformer::kit_global_ids( $doc['settings'] );
						if ( null === $base_ids ) {
							$base_ids = $ids;
							$base_kit = $kit;
						} else {
							foreach ( array( 'colors', 'typography' ) as $g ) {
								$miss = array_diff( array_keys( $base_ids[ $g ] ), array_keys( $ids[ $g ] ) );
								if ( $miss ) {
									$warnings[] = $rel . ': ' . count( $miss ) . ' global ' . $g . ' ID(s) of ' . $base_kit . ' are missing here (' . implode( ', ', array_slice( $miss, 0, 5 ) ) . '). Sections styled with them lose that style with this kit.';
								}
							}
						}
						continue;
					}
					if ( in_array( $key, array( 'header_dist', 'footer_dist' ), true ) && 'B' !== $doc['format'] ) {
						$warnings[] = $rel . ': copied (format A); a Theme Builder export (format B) is preferred.';
					}
					if ( ! $doc['elements'] ) {
						$errors[] = $rel . ': no elements.';
					}
					self::inspect( $doc, $rel, $widgets, $where, $warnings, $hashes, $duplicates, false );
				} catch ( DistB_Exception $e ) {
					$errors[] = $rel . ': ' . $e->getMessage();
				}
			}
		}

		$dirs = self::component_dirs( $lib );
		foreach ( $dirs as $slot ) {
			foreach ( $lib->components( $slot ) as $rel ) {
				$files++;
				try {
					$doc = DistB_Transformer::load( $lib->path( $rel ) );
					if ( ! $doc['elements'] ) {
						$errors[] = $rel . ': no elements.';
						continue;
					}
					if ( in_array( $slot, array( 'loop_item', 'single' ), true ) && 'B' !== $doc['format'] ) {
						$warnings[] = $rel . ': copied (format A); export it from Theme Builder (format B) to keep its template settings.';
					}
					self::inspect( $doc, $rel, $widgets, $where, $warnings, $hashes, $duplicates, true );
				} catch ( DistB_Exception $e ) {
					$errors[] = $rel . ': ' . $e->getMessage();
				}
			}
		}

		if ( $checker && $widgets ) {
			foreach ( call_user_func( $checker, array_keys( $widgets ) ) as $type ) {
				$errors[] = 'Widget "' . $type . '" is not registered on this site; used in ' . count( $where[ $type ] ) . ' file(s): ' . implode( ', ', array_slice( array_unique( $where[ $type ] ), 0, 5 ) );
			}
		}

		ksort( $widgets );
		return array(
			'files'      => $files,
			'errors'     => $errors,
			'warnings'   => $warnings,
			'duplicates' => $duplicates,
			'widgets'    => $widgets,
			'ok'         => ! $errors,
		);
	}

	private static function inspect( array $doc, $rel, array &$widgets, array &$where, array &$warnings, array &$hashes, array &$duplicates, $is_component ) {
		foreach ( DistB_Transformer::widget_types( $doc['elements'] ) as $t ) {
			$widgets[ $t ]  = ( isset( $widgets[ $t ] ) ? $widgets[ $t ] : 0 ) + 1;
			$where[ $t ][] = $rel;
		}
		if ( in_array( 'section', DistB_Transformer::element_types( $doc['elements'] ), true ) ) {
			$warnings[] = $rel . ': legacy Section/Column layout. Containers are recommended.';
		}
		if ( $is_component && count( $doc['elements'] ) > 1 ) {
			$warnings[] = $rel . ': ' . count( $doc['elements'] ) . ' top-level containers (one section per file is the rule; all are imported in order).';
		}
		if ( $is_component ) {
			$hash = md5( wp_json_encode( self::without_ids( $doc['elements'] ) ) );
			if ( isset( $hashes[ $hash ] ) ) {
				$duplicates[] = array( $hashes[ $hash ], $rel );
			} else {
				$hashes[ $hash ] = $rel;
			}
		}
	}

	private static function without_ids( array $elements ) {
		$out = array();
		foreach ( $elements as $el ) {
			unset( $el['id'] );
			$el['elements'] = self::without_ids( isset( $el['elements'] ) ? $el['elements'] : array() );
			$out[]          = $el;
		}
		return $out;
	}

	/**
	 * Every folder under components/ that holds comp_N.json files (e.g. "home/section_2", "faq").
	 *
	 * @param DistB_Library $lib Library.
	 * @return string[]
	 */
	public static function component_dirs( DistB_Library $lib ) {
		$root = $lib->root() . 'components/';
		$out  = array();
		if ( ! is_dir( $root ) ) {
			return $out;
		}
		$iter = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::SELF_FIRST );
		foreach ( $iter as $item ) {
			if ( $item->isDir() && glob( $item->getPathname() . '/comp_*.json' ) ) {
				$rel = str_replace( '\\', '/', substr( $item->getPathname(), strlen( $root ) ) );
				if ( 0 !== strpos( $rel, '_unsorted' ) ) {
					$out[] = $rel;
				}
			}
		}
		return distb_natsort( $out );
	}

	/* ------------------------------------------------------------------ */
	/* Extract from a source site (run with WP-CLI on the finished site)   */
	/* ------------------------------------------------------------------ */

	/**
	 * Write this site's kit, header, footer, banners, CTA, sections, loop item and single product into a library folder.
	 *
	 * @param int    $site_no Kit number for this site (site_N, comp_N).
	 * @param string $out     Library root to write into.
	 * @param array  $opts    force (overwrite), pages (slug => post ID overrides).
	 * @return array{written:string[],warnings:string[],registry:array}
	 */
	public static function extract( $site_no, $out, array $opts = array() ) {
		$site_no = (int) $site_no;
		if ( $site_no < 1 ) {
			throw new DistB_Exception( '--site must be a number from 1.' );
		}
		$out   = rtrim( $out, '/\\' ) . '/';
		$force = ! empty( $opts['force'] );
		$kit   = 'site_' . $site_no;
		$res   = array(
			'written'  => array(),
			'warnings' => array(),
			'registry' => array(),
		);
		$siteurl = home_url( '/wp-json/' );
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		// Kit settings + manifest.
		$kit_id   = DistB_Elementor::active_kit_id();
		$settings = get_post_meta( $kit_id, '_elementor_page_settings', true );
		if ( ! is_array( $settings ) || ! $settings ) {
			throw new DistB_Exception( 'The active Elementor kit has no settings to export.' );
		}
		self::put(
			$out . 'global_kits/' . $kit . '/site-settings.json',
			array(
				'content'  => array(),
				'settings' => $settings,
				'metadata' => array( 'exported_by' => 'distribution-builder ' . DISTB_VERSION ),
			),
			$force,
			$res
		);
		$plugins = array();
		foreach ( (array) get_option( 'active_plugins', array() ) as $p ) {
			$data      = function_exists( 'get_plugin_data' ) ? get_plugin_data( WP_PLUGIN_DIR . '/' . $p, false, false ) : array();
			$plugins[] = array(
				'name'    => isset( $data['Name'] ) ? $data['Name'] : $p,
				'plugin'  => preg_replace( '/\.php$/', '', $p ),
				'version' => isset( $data['Version'] ) ? $data['Version'] : '',
			);
		}
		self::put(
			$out . 'global_kits/' . $kit . '/manifest.json',
			array(
				'name'              => $kit,
				'title'             => get_bloginfo( 'name' ),
				'site'              => home_url(),
				'elementor_version' => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '',
				'created'           => gmdate( 'Y-m-d H:i:s' ),
				'theme'             => array( 'slug' => get_template() ),
				'plugins'           => $plugins,
			),
			true,
			$res
		);

		// Header and footer (format B).
		foreach ( array(
			'header' => 'header_dist',
			'footer' => 'footer_dist',
		) as $type => $name ) {
			$tid = self::find_template( $type, true );
			if ( ! $tid ) {
				$res['warnings'][] = 'No ' . $type . ' template with display conditions found.';
				continue;
			}
			self::put( $out . 'global_kits/' . $kit . '/' . $name . '.json', self::format_b( $tid, $type ), $force, $res );
		}

		// Pages.
		$banner_done = false;
		$cta_done    = false;
		foreach ( self::PAGE_SLUGS as $key => $candidates ) {
			$pid = self::find_page( $key, $candidates, isset( $opts['pages'][ $key ] ) ? (int) $opts['pages'][ $key ] : 0 );
			if ( ! $pid ) {
				$res['warnings'][] = 'Page "' . $key . '" not found (tried: ' . ( $candidates ? implode( ', ', $candidates ) : 'front page' ) . '). Pass --pages=' . $key . '=<ID>.';
				continue;
			}
			$elements = self::page_elements( $pid );
			if ( ! $elements ) {
				$res['warnings'][] = 'Page "' . $key . '" (post ' . $pid . ') has no Elementor data.';
				continue;
			}
			self::split_page( $key, $elements, $site_no, $out, $siteurl, $force, $res, $banner_done, $cta_done );
		}

		// Loop item, single product, product archive (format B).
		$loop = self::find_template( 'loop-item', false );
		if ( $loop ) {
			self::put( $out . 'components/loop_item/comp_' . $site_no . '.json', self::format_b( $loop, 'loop-item' ), $force, $res );
		} else {
			$res['warnings'][] = 'No loop-item template found.';
		}
		foreach ( array(
			'product'         => 'single',
			'product-archive' => 'category',
		) as $type => $dir ) {
			$tid = self::find_template( $type, false );
			if ( ! $tid ) {
				$res['warnings'][] = 'No ' . $type . ' template found.';
				continue;
			}
			$doc = self::format_b( $tid, $type );
			if ( count( $doc['content'] ) >= 2 ) {
				// The recipe puts the kit page banner first, so the template's own first block (its banner) is dropped.
				array_shift( $doc['content'] );
				$res['warnings'][] = $type . ' template: first top-level block treated as its banner and left out (the recipe adds page_banner). Check components/' . $dir . '/comp_' . $site_no . '.json.';
			}
			self::put( $out . 'components/' . $dir . '/comp_' . $site_no . '.json', $doc, $force, $res );
		}

		$res['registry'] = array(
			$kit => array(
				'domain' => distb_host( home_url() ),
				'brand'  => get_bloginfo( 'name' ),
				'email'  => '',
				'phone'  => '',
			),
		);
		self::merge_registry( $out, $res['registry'] );
		return $res;
	}

	/**
	 * Split one page's top-level blocks into library slots by position.
	 *
	 * @param string $key      Page key (home, about-us, faqs, ...).
	 * @param array  $elements Top-level elements.
	 * @param int    $site_no  Site number.
	 * @param string $out      Library root (trailing slash).
	 * @param string $siteurl  Source site REST URL for format A.
	 * @param bool   $force    Overwrite.
	 * @param array  $res      Result collector.
	 * @param bool   $banner_done Page banner already written for this kit.
	 * @param bool   $cta_done    CTA already written for this kit.
	 */
	public static function split_page( $key, array $elements, $site_no, $out, $siteurl, $force, array &$res, &$banner_done, &$cta_done ) {
		$kit   = 'site_' . $site_no;
		$n     = count( $elements );
		$fmt_a = function ( array $els ) use ( $siteurl ) {
			return array(
				'type'     => 'elementor',
				'siteurl'  => $siteurl,
				'elements' => array_values( array_map( array( 'DistB_Transformer', 'strip' ), $els ) ),
			);
		};
		$unsorted = function () use ( $key, $elements, $site_no, $out, $fmt_a, $force, &$res ) {
			foreach ( $elements as $i => $el ) {
				self::put( $out . 'components/_unsorted/' . $key . '/site_' . $site_no . '/position_' . ( $i + 1 ) . '.json', $fmt_a( array( $el ) ), $force, $res );
			}
		};

		if ( 'home' === $key ) {
			if ( 11 !== $n ) {
				$res['warnings'][] = 'Home has ' . $n . ' top-level blocks, the recipe needs 11 (banner + section_2..10 + CTA). Written to components/_unsorted/home/site_' . $site_no . '/ — move them by hand.';
				$unsorted();
				return;
			}
			self::put( $out . 'global_kits/' . $kit . '/home_banner.json', $fmt_a( array( $elements[0] ) ), $force, $res );
			for ( $i = 1; $i <= 9; $i++ ) {
				self::put( $out . 'components/home/section_' . ( $i + 1 ) . '/comp_' . $site_no . '.json', $fmt_a( array( $elements[ $i ] ) ), $force, $res );
			}
			self::put( $out . 'global_kits/' . $kit . '/cta.json', $fmt_a( array( $elements[10] ) ), $force, $res );
			$cta_done = true;
			return;
		}

		if ( 'about-us' === $key ) {
			if ( 7 !== $n ) {
				$res['warnings'][] = 'About Us has ' . $n . ' top-level blocks, the recipe needs 7 (banner + section_2..6 + CTA). Written to components/_unsorted/about-us/site_' . $site_no . '/.';
				$unsorted();
				return;
			}
			self::put( $out . 'global_kits/' . $kit . '/page_banner.json', $fmt_a( array( $elements[0] ) ), $force, $res );
			$banner_done = true;
			for ( $i = 1; $i <= 5; $i++ ) {
				self::put( $out . 'components/about/section_' . ( $i + 1 ) . '/comp_' . $site_no . '.json', $fmt_a( array( $elements[ $i ] ) ), $force, $res );
			}
			if ( ! $cta_done ) {
				self::put( $out . 'global_kits/' . $kit . '/cta.json', $fmt_a( array( $elements[6] ) ), $force, $res );
				$cta_done = true;
			}
			return;
		}

		if ( isset( self::SIMPLE[ $key ] ) ) {
			if ( $n < 2 ) {
				$res['warnings'][] = ucfirst( $key ) . ' has ' . $n . ' top-level block(s), needs banner + body. Written to components/_unsorted/.';
				$unsorted();
				return;
			}
			if ( ! $banner_done ) {
				self::put( $out . 'global_kits/' . $kit . '/page_banner.json', $fmt_a( array( $elements[0] ) ), $force, $res );
				$banner_done = true;
			}
			$body = array_slice( $elements, 1 );
			if ( count( $body ) > 1 ) {
				$res['warnings'][] = ucfirst( $key ) . ': ' . count( $body ) . ' body blocks kept together in one component (they are imported in order).';
			}
			self::put( $out . 'components/' . self::SIMPLE[ $key ] . '/comp_' . $site_no . '.json', $fmt_a( $body ), $force, $res );
		}
	}

	private static function put( $path, array $data, $force, array &$res ) {
		if ( is_file( $path ) && ! $force ) {
			$res['warnings'][] = 'Exists, skipped (use --force to overwrite): ' . $path;
			return;
		}
		distb_write_json( $path, $data, false );
		$res['written'][] = $path;
	}

	private static function format_b( $post_id, $type ) {
		$settings = get_post_meta( $post_id, '_elementor_page_settings', true );
		return array(
			'content'       => array_values( array_map( array( 'DistB_Transformer', 'strip' ), self::page_elements( $post_id ) ) ),
			'page_settings' => is_array( $settings ) ? $settings : array(),
			'version'       => '0.4',
			'title'         => get_the_title( $post_id ),
			'type'          => $type,
		);
	}

	private static function page_elements( $post_id ) {
		$raw  = get_post_meta( $post_id, '_elementor_data', true );
		$data = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
		return is_array( $data ) ? $data : array();
	}

	private static function find_page( $key, array $candidates, $override ) {
		if ( $override && get_post( $override ) ) {
			return $override;
		}
		if ( 'home' === $key ) {
			$front = (int) get_option( 'page_on_front' );
			if ( $front ) {
				return $front;
			}
			$candidates = array( 'home' );
		}
		foreach ( $candidates as $slug ) {
			$p = get_page_by_path( $slug, OBJECT, 'page' );
			if ( $p && 'publish' === $p->post_status ) {
				return (int) $p->ID;
			}
		}
		return 0;
	}

	private static function find_template( $type, $need_conditions ) {
		$ids = get_posts(
			array(
				'post_type'      => 'elementor_library',
				'post_status'    => 'publish',
				'posts_per_page' => 20,
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'   => '_elementor_template_type',
						'value' => $type,
					),
				),
			)
		);
		$fallback = $ids ? (int) $ids[0] : 0;
		foreach ( $ids as $id ) {
			if ( get_post_meta( $id, '_elementor_conditions', true ) ) {
				return (int) $id;
			}
		}
		unset( $need_conditions );
		return $fallback;
	}

	private static function merge_registry( $out, array $entry ) {
		$file = $out . 'registry/sources.json';
		$data = array(
			'domains'           => array(),
			'kits'              => array(),
			'extra_brand_names' => array(),
			'extra_emails'      => array(),
			'extra_phones'      => array(),
		);
		if ( is_file( $file ) ) {
			try {
				$data = array_merge( $data, distb_read_json( $file ) );
			} catch ( DistB_Exception $e ) {
				unset( $e );
			}
		}
		foreach ( $entry as $kit => $info ) {
			$old                  = isset( $data['kits'][ $kit ] ) ? $data['kits'][ $kit ] : array();
			$data['kits'][ $kit ] = array_merge( $info, array_filter( $old ) );
			if ( ! in_array( $info['domain'], $data['domains'], true ) ) {
				$data['domains'][] = $info['domain'];
			}
		}
		ksort( $data['kits'], SORT_NATURAL );
		distb_write_json( $file, $data );
	}

	/* ------------------------------------------------------------------ */
	/* Media pack                                                          */
	/* ------------------------------------------------------------------ */

	/**
	 * Download every image the library uses into lib/media, so builds work offline and fast.
	 *
	 * @param DistB_Library $lib      Library.
	 * @param callable|null $progress fn( string $line ).
	 * @return array{total:int,new:int,failed:array}
	 */
	public static function media_pack( DistB_Library $lib, $progress = null ) {
		$urls = array();
		$all  = array();
		foreach ( $lib->kits() as $kit ) {
			foreach ( glob( $lib->root() . 'global_kits/' . $kit . '/*.json' ) as $f ) {
				$all[] = $f;
			}
		}
		foreach ( self::component_dirs( $lib ) as $slot ) {
			foreach ( $lib->components( $slot ) as $rel ) {
				$all[] = $lib->path( $rel );
			}
		}
		foreach ( $all as $f ) {
			if ( 'manifest.json' === basename( $f ) ) {
				continue;
			}
			try {
				$doc  = DistB_Transformer::load( $f );
				$node = 'C' === $doc['format'] ? $doc['settings'] : $doc['elements'];
				foreach ( DistB_Transformer::collect_media_urls( $node, '' ) as $u ) {
					$urls[ $u ] = true;
				}
			} catch ( DistB_Exception $e ) {
				unset( $e );
			}
		}

		$dir = $lib->root() . 'media/';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		$map = is_file( $dir . 'media-map.json' ) ? distb_read_json( $dir . 'media-map.json' ) : array();
		$new = 0;
		$bad = array();
		foreach ( array_keys( $urls ) as $u ) {
			if ( isset( $map[ $u ] ) && is_file( $dir . $map[ $u ] ) ) {
				continue;
			}
			$ext  = strtolower( pathinfo( (string) wp_parse_url( $u, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
			$name = sha1( $u ) . ( $ext ? '.' . $ext : '' );
			$resp = wp_remote_get(
				$u,
				array(
					'timeout'  => 30,
					'stream'   => true,
					'filename' => $dir . $name,
				)
			);
			if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) {
				if ( is_file( $dir . $name ) ) {
					wp_delete_file( $dir . $name );
				}
				$bad[ $u ] = is_wp_error( $resp ) ? $resp->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $resp );
				if ( $progress ) {
					call_user_func( $progress, 'FAILED ' . $u . ' ' . $bad[ $u ] );
				}
				continue;
			}
			$map[ $u ] = $name;
			$new++;
			if ( $progress ) {
				call_user_func( $progress, 'OK ' . $u );
			}
			if ( 0 === $new % 20 ) {
				distb_write_json( $dir . 'media-map.json', $map );
			}
		}
		distb_write_json( $dir . 'media-map.json', $map );
		return array(
			'total'  => count( $urls ),
			'new'    => $new,
			'failed' => $bad,
		);
	}

	/* ------------------------------------------------------------------ */
	/* Batch plan                                                          */
	/* ------------------------------------------------------------------ */

	/**
	 * Seeds and kits for a batch of sites. Every site gets a different kit while kits last.
	 *
	 * @param DistB_Library $lib   Library.
	 * @param int           $count Number of sites.
	 * @param int           $seed  Batch seed (0 = random).
	 * @return array Rows.
	 */
	public static function batch_plan( DistB_Library $lib, $count, $seed = 0 ) {
		$kits = $lib->kits();
		if ( ! $kits ) {
			throw new DistB_Exception( 'No kits in the library.' );
		}
		$seed  = $seed ? (int) $seed : DistB_Randomizer::new_seed();
		$rand  = new DistB_Randomizer( $seed );
		$order = $rand->shuffle( $kits, 'batch' );
		$rows  = array();
		for ( $i = 0; $i < $count; $i++ ) {
			$kit    = $order[ $i % count( $order ) ];
			$rows[] = array(
				'row'     => $i + 1,
				'seed'    => 1 + $rand->number( 'site|' . $i, DistB_Randomizer::MAX_SEED - 1 ),
				'kit'     => (int) substr( $kit, 5 ),
				'domain'  => '',
				'brand'   => '',
				'email'   => '',
				'phone'   => '',
				'address' => '',
			);
		}
		return array(
			'batch_seed' => $seed,
			'rows'       => $rows,
			'repeats'    => $count > count( $kits ),
		);
	}
}
