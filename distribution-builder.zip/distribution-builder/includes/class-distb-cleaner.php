<?php
/**
 * Reset: removes everything a build made (tracked by the _distb_build_id meta)
 * and restores what it changed (kit settings, pages it updated, options, menu).
 * Never touches content the build did not make.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DistB_Cleaner {

	/**
	 * @param string $build_id   Build ID.
	 * @param bool   $keep_media Keep imported images (faster rebuilds).
	 * @return array{summary:string,deleted:int,restored:int}
	 */
	public function reset( $build_id, $keep_media = false ) {
		$build_id = sanitize_text_field( $build_id );
		if ( '' === $build_id ) {
			return array(
				'summary'  => 'nothing to reset',
				'deleted'  => 0,
				'restored' => 0,
			);
		}

		$deleted  = 0;
		$restored = 0;

		// 1. Posts, pages, templates and (optionally) media made by the build.
		$types = array( 'page', 'elementor_library', 'nav_menu_item' );
		if ( ! $keep_media ) {
			$types[] = 'attachment';
		}
		$ids = get_posts(
			array(
				'post_type'      => $types,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => '_distb_build_id', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $build_id, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		foreach ( $ids as $id ) {
			if ( 'attachment' === get_post_type( $id ) ) {
				wp_delete_attachment( $id, true );
			} else {
				wp_delete_post( $id, true );
			}
			$deleted++;
		}

		$backup = get_option( 'distb_backup_' . $build_id, array() );
		$track  = get_option( 'distb_track_' . $build_id, array() );
		$state  = isset( $track['state'] ) ? $track['state'] : array();
		$live   = get_option( DistB_Runner::STATE_OPTION, array() );
		if ( isset( $live['build_id'] ) && $live['build_id'] === $build_id ) {
			$state = $live;
		}

		// 2. Pages that existed before and were updated by the build.
		if ( ! empty( $backup['pages'] ) ) {
			foreach ( $backup['pages'] as $id => $old ) {
				if ( ! get_post( $id ) ) {
					continue;
				}
				wp_update_post(
					array(
						'ID'          => $id,
						'post_title'  => $old['post_title'],
						'post_status' => $old['post_status'],
					)
				);
				foreach ( array( '_elementor_data', '_elementor_edit_mode', '_wp_page_template', '_elementor_page_settings' ) as $meta ) {
					if ( '' === $old[ $meta ] || null === $old[ $meta ] ) {
						delete_post_meta( $id, $meta );
					} else {
						update_post_meta( $id, $meta, wp_slash( $old[ $meta ] ) );
					}
				}
				delete_post_meta( $id, '_distb_updated_by' );
				DistB_Elementor::delete_post_css( $id );
				$restored++;
			}
		}

		// 3. Menu.
		if ( ! empty( $state['menu']['created'] ) ) {
			wp_delete_nav_menu( (int) $state['menu']['created'] );
			$deleted++;
		} elseif ( ! empty( $backup['menu']['id'] ) && term_exists( (int) $backup['menu']['id'], 'nav_menu' ) ) {
			$menu_id = (int) $backup['menu']['id'];
			foreach ( (array) wp_get_nav_menu_items( $menu_id ) as $it ) {
				wp_delete_post( $it->ID, true );
			}
			foreach ( $backup['menu']['items'] as $it ) {
				$args = array(
					'menu-item-title'    => $it['title'],
					'menu-item-status'   => 'publish',
					'menu-item-position' => $it['order'],
					'menu-item-type'     => $it['type'],
				);
				if ( 'custom' === $it['type'] ) {
					$args['menu-item-url'] = $it['url'];
				} else {
					$args['menu-item-object']    = $it['object'];
					$args['menu-item-object-id'] = $it['object_id'];
				}
				wp_update_nav_menu_item( $menu_id, 0, $args );
			}
			$restored++;
		}

		// 4. Kit settings, options and theme mods.
		if ( ! empty( $backup['kit_id'] ) && get_post( $backup['kit_id'] ) ) {
			if ( empty( $backup['kit_settings'] ) ) {
				delete_post_meta( $backup['kit_id'], '_elementor_page_settings' );
			} else {
				update_post_meta( $backup['kit_id'], '_elementor_page_settings', wp_slash( $backup['kit_settings'] ) );
			}
			DistB_Elementor::delete_post_css( $backup['kit_id'] );
			$restored++;
		}
		if ( ! empty( $backup['options'] ) ) {
			foreach ( $backup['options'] as $opt => $value ) {
				if ( 'page_on_front' === $opt && $value && ! get_post( $value ) ) {
					$value = 0;
				}
				update_option( $opt, $value );
			}
			$restored++;
		}
		if ( ! empty( $backup['theme_mods'] ) ) {
			foreach ( $backup['theme_mods'] as $mod => $value ) {
				if ( false === $value || null === $value ) {
					remove_theme_mod( $mod );
				} else {
					set_theme_mod( $mod, $value );
				}
			}
		}

		if ( class_exists( '\Elementor\Plugin' ) ) {
			DistB_Elementor::regenerate_conditions_cache();
			DistB_Elementor::clear_cache();
		}
		flush_rewrite_rules( false );
		if ( ! $keep_media ) {
			$lib = new DistB_Library( distb_library_dir() );
			( new DistB_Media( $lib ) )->prune();
		}

		// 5. Mark the build as reset.
		$history = get_option( DistB_Runner::HISTORY_OPTION, array() );
		if ( isset( $history[ $build_id ] ) ) {
			$history[ $build_id ]['status'] = 'reset';
			update_option( DistB_Runner::HISTORY_OPTION, $history, false );
		}
		if ( isset( $live['build_id'] ) && $live['build_id'] === $build_id ) {
			$live['status'] = 'reset';
			update_option( DistB_Runner::STATE_OPTION, $live, false );
		}
		delete_option( 'distb_backup_' . $build_id );
		delete_option( DistB_Runner::LOCK_OPTION );

		return array(
			'summary'  => $build_id . ': ' . $deleted . ' item(s) removed, ' . $restored . ' restored' . ( $keep_media ? ', media kept' : '' ),
			'deleted'  => $deleted,
			'restored' => $restored,
		);
	}
}
