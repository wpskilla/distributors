<?php
/**
 * Admin screen: Distribution Builder → Build / Library / History / Reset.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DistB_Admin {

	const SLUG = 'distribution-builder';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DISTB_FILE ), array( __CLASS__, 'links' ) );
	}

	public static function menu() {
		add_menu_page( 'Distribution Builder', 'Distribution Builder', 'manage_options', self::SLUG, array( __CLASS__, 'render' ), 'dashicons-hammer', 58 );
	}

	public static function links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Build</a>' );
		return $links;
	}

	public static function assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'distb-admin', DISTB_URL . 'admin/assets/builder.css', array(), DISTB_VERSION );
		wp_enqueue_script( 'distb-admin', DISTB_URL . 'admin/assets/builder.js', array(), DISTB_VERSION, true );
		wp_localize_script(
			'distb-admin',
			'DISTB',
			array(
				'rest'  => esc_url_raw( rest_url( DistB_Rest::NS . '/' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
				'home'  => home_url(),
				'kits'  => count( distb_library()->exists() ? distb_library()->kits() : array() ),
			)
		);
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include DISTB_PATH . 'admin/views/page-main.php';
	}
}
