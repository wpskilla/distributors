<?php
/**
 * Every call into Elementor and Elementor Pro lives here, so a future Elementor change
 * is fixed in one file. Each call is checked with class_exists / method_exists first.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DistB_Elementor {

	const EXPERIMENTS = array( 'container', 'nested-elements' );

	/**
	 * Missing Elementor APIs, as readable messages. Empty = everything the builder needs exists.
	 *
	 * @return string[]
	 */
	public static function missing_apis() {
		$missing = array();
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return array( 'Elementor is not active.' );
		}
		$el = \Elementor\Plugin::$instance;
		if ( empty( $el->documents ) || ! method_exists( $el->documents, 'get' ) || ! method_exists( $el->documents, 'create' ) ) {
			$missing[] = 'Elementor documents manager (documents->get/create) not found.';
		}
		if ( empty( $el->kits_manager ) || ! method_exists( $el->kits_manager, 'get_active_kit' ) ) {
			$missing[] = 'Elementor kits manager (kits_manager->get_active_kit) not found.';
		}
		if ( empty( $el->widgets_manager ) || ! method_exists( $el->widgets_manager, 'get_widget_types' ) ) {
			$missing[] = 'Elementor widgets manager not found.';
		}
		if ( empty( $el->files_manager ) || ! method_exists( $el->files_manager, 'clear_cache' ) ) {
			$missing[] = 'Elementor files manager not found.';
		}
		if ( ! class_exists( '\ElementorPro\Plugin' ) ) {
			$missing[] = 'Elementor Pro is not active (needed for header, footer, loop item and single product templates).';
		} elseif ( ! class_exists( '\ElementorPro\Modules\ThemeBuilder\Module' ) ) {
			$missing[] = 'Elementor Pro Theme Builder module not found.';
		}
		return $missing;
	}

	/**
	 * Widget types from the list that are not registered on this site.
	 *
	 * @param string[] $types Widget types.
	 * @return string[]
	 */
	public static function unknown_widgets( array $types ) {
		$wm      = \Elementor\Plugin::$instance->widgets_manager;
		$unknown = array();
		foreach ( $types as $type ) {
			if ( ! $wm->get_widget_types( $type ) ) {
				$unknown[] = $type;
			}
		}
		return $unknown;
	}

	/**
	 * Is an Elementor experiment active?
	 *
	 * @param string $name Experiment.
	 * @return bool
	 */
	public static function experiment_active( $name ) {
		$exp = \Elementor\Plugin::$instance->experiments;
		if ( $exp && method_exists( $exp, 'is_feature_active' ) ) {
			return (bool) $exp->is_feature_active( $name );
		}
		return 'active' === get_option( 'elementor_experiment-' . $name );
	}

	/**
	 * Turn on experiments the library needs. Takes effect on the next request.
	 *
	 * @param string[] $names Experiments.
	 * @return string[] Experiments that were switched on.
	 */
	public static function activate_experiments( array $names ) {
		$changed = array();
		foreach ( $names as $name ) {
			if ( ! self::experiment_active( $name ) ) {
				update_option( 'elementor_experiment-' . $name, 'active' );
				$changed[] = $name;
			}
		}
		return $changed;
	}

	/**
	 * Active kit post ID (Elementor creates a default kit if there is none).
	 *
	 * @return int
	 * @throws DistB_Exception When no kit can be found or created.
	 */
	public static function active_kit_id() {
		$km  = \Elementor\Plugin::$instance->kits_manager;
		$kit = $km->get_active_kit();
		$id  = $kit ? (int) $kit->get_main_id() : 0;
		if ( ! $id && method_exists( $km, 'create_default' ) ) {
			$id = (int) $km->create_default();
			update_option( 'elementor_active_kit', $id );
		}
		if ( ! $id ) {
			throw new DistB_Exception( 'No active Elementor kit and none could be created.' );
		}
		return $id;
	}

	/**
	 * Replace the active kit's settings (colors, fonts, buttons, layout).
	 *
	 * @param array $settings Kit settings.
	 * @return int Kit post ID.
	 */
	public static function save_kit_settings( array $settings ) {
		$kit_id = self::active_kit_id();
		update_post_meta( $kit_id, '_elementor_page_settings', wp_slash( $settings ) );
		self::delete_post_css( $kit_id );
		return $kit_id;
	}

	/**
	 * Create a page or update the page that already has this slug.
	 *
	 * @param string $slug     Slug.
	 * @param string $title    Title.
	 * @param string $build_id Build ID.
	 * @param array  $backup   Backup collector (by reference) for pages that existed before.
	 * @return array{id:int,created:bool}
	 * @throws DistB_Exception On failure.
	 */
	public static function upsert_page( $slug, $title, $build_id, array &$backup ) {
		$existing = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $existing && 'trash' !== $existing->post_status ) {
			$id = (int) $existing->ID;
			if ( get_post_meta( $id, '_distb_build_id', true ) !== $build_id && ! isset( $backup[ $id ] ) ) {
				$backup[ $id ] = array(
					'post_title'        => $existing->post_title,
					'post_status'       => $existing->post_status,
					'_elementor_data'   => get_post_meta( $id, '_elementor_data', true ),
					'_elementor_edit_mode' => get_post_meta( $id, '_elementor_edit_mode', true ),
					'_wp_page_template' => get_post_meta( $id, '_wp_page_template', true ),
					'_elementor_page_settings' => get_post_meta( $id, '_elementor_page_settings', true ),
				);
			}
			$res = wp_update_post(
				array(
					'ID'          => $id,
					'post_title'  => $title,
					'post_status' => 'publish',
				),
				true
			);
			if ( is_wp_error( $res ) ) {
				throw new DistB_Exception( 'Cannot update page ' . $slug . ': ' . $res->get_error_message() );
			}
			update_post_meta( $id, '_wp_page_template', 'elementor_header_footer' );
			update_post_meta( $id, '_distb_updated_by', $build_id );
			return array(
				'id'      => $id,
				'created' => false,
			);
		}

		$id = wp_insert_post(
			array(
				'post_type'   => 'page',
				'post_title'  => $title,
				'post_name'   => $slug,
				'post_status' => 'publish',
				'meta_input'  => array(
					'_wp_page_template' => 'elementor_header_footer',
					'_distb_build_id'   => $build_id,
				),
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			throw new DistB_Exception( 'Cannot create page ' . $slug . ': ' . $id->get_error_message() );
		}
		return array(
			'id'      => (int) $id,
			'created' => true,
		);
	}

	/**
	 * Create a Theme Builder template (header, footer, loop-item, product, product-archive).
	 *
	 * @param string $type     Elementor document type.
	 * @param string $title    Title.
	 * @param string $build_id Build ID.
	 * @return int Post ID.
	 * @throws DistB_Exception When Elementor cannot create this type.
	 */
	public static function create_template( $type, $title, $build_id ) {
		$doc = \Elementor\Plugin::$instance->documents->create(
			$type,
			array(
				'post_title'  => $title,
				'post_status' => 'publish',
			)
		);
		if ( is_wp_error( $doc ) ) {
			throw new DistB_Exception( 'Elementor cannot create a "' . $type . '" template: ' . $doc->get_error_message() );
		}
		if ( ! $doc || ! method_exists( $doc, 'get_main_id' ) ) {
			throw new DistB_Exception( 'Elementor cannot create a "' . $type . '" template (is the document type registered? Elementor Pro and WooCommerce must be active).' );
		}
		$id = (int) $doc->get_main_id();
		update_post_meta( $id, '_distb_build_id', $build_id );
		return $id;
	}

	/**
	 * Save Elementor data on a page or template through Elementor's Document API,
	 * then verify it. If the API refuses, the data is written directly so the build never ends with an empty page.
	 *
	 * @param int   $post_id       Post ID.
	 * @param array $elements      Elements.
	 * @param array $page_settings Page settings (format B), may be empty.
	 * @return array{method:string,saved:int,expected:int}
	 * @throws DistB_Exception When nothing could be saved.
	 */
	public static function save_document( $post_id, array $elements, array $page_settings = array() ) {
		$expected = DistB_Transformer::count_elements( $elements );
		update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );

		$method = 'document';
		$doc    = \Elementor\Plugin::$instance->documents->get( $post_id, false );
		$ok     = false;
		if ( $doc ) {
			$data = array( 'elements' => $elements );
			if ( $page_settings ) {
				$data['settings'] = $page_settings;
			}
			try {
				$ok = $doc->save( $data );
			} catch ( \Throwable $e ) {
				$ok = false;
			}
		}

		$saved = self::saved_count( $post_id );
		if ( ! $ok || 0 === $saved ) {
			$method = 'direct';
			update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $elements ) ) );
			if ( $page_settings ) {
				update_post_meta( $post_id, '_elementor_page_settings', wp_slash( $page_settings ) );
			}
			if ( defined( 'ELEMENTOR_VERSION' ) ) {
				update_post_meta( $post_id, '_elementor_version', ELEMENTOR_VERSION );
			}
			$saved = self::saved_count( $post_id );
		}
		if ( 0 === $saved && $expected > 0 ) {
			throw new DistB_Exception( 'Elementor data could not be saved for post ' . $post_id . '.' );
		}
		self::delete_post_css( $post_id );
		return array(
			'method'   => $method,
			'saved'    => $saved,
			'expected' => $expected,
		);
	}

	private static function saved_count( $post_id ) {
		$raw = get_post_meta( $post_id, '_elementor_data', true );
		if ( is_string( $raw ) && '' !== $raw ) {
			$data = json_decode( $raw, true );
			return is_array( $data ) ? DistB_Transformer::count_elements( $data ) : 0;
		}
		return is_array( $raw ) ? DistB_Transformer::count_elements( $raw ) : 0;
	}

	/**
	 * Save Theme Builder display conditions, such as "include/general".
	 *
	 * @param int      $post_id    Template ID.
	 * @param string[] $conditions Conditions.
	 * @return string[] Conditions stored.
	 */
	public static function save_conditions( $post_id, array $conditions ) {
		if ( ! $conditions ) {
			return array();
		}
		$parsed = array();
		foreach ( $conditions as $c ) {
			$parts = explode( '/', $c );
			$item  = array(
				'type' => $parts[0],
				'name' => isset( $parts[1] ) ? $parts[1] : '',
			);
			if ( isset( $parts[2] ) ) {
				$item['sub_name'] = $parts[2];
			}
			if ( isset( $parts[3] ) ) {
				$item['sub_id'] = $parts[3];
			}
			$parsed[] = $item;
		}

		$manager = null;
		if ( class_exists( '\ElementorPro\Modules\ThemeBuilder\Module' ) ) {
			$module = \ElementorPro\Modules\ThemeBuilder\Module::instance();
			if ( $module && method_exists( $module, 'get_conditions_manager' ) ) {
				$manager = $module->get_conditions_manager();
			}
		}
		if ( $manager && method_exists( $manager, 'save_conditions' ) ) {
			try {
				$manager->save_conditions( $post_id, $parsed );
			} catch ( \Throwable $e ) {
				unset( $e ); // Fall back below.
			}
		}

		$stored = (array) get_post_meta( $post_id, '_elementor_conditions', true );
		if ( array_values( array_filter( $stored ) ) !== array_values( $conditions ) ) {
			update_post_meta( $post_id, '_elementor_conditions', $conditions );
			self::regenerate_conditions_cache();
			$stored = $conditions;
		}
		return $stored;
	}

	public static function regenerate_conditions_cache() {
		if ( ! class_exists( '\ElementorPro\Modules\ThemeBuilder\Module' ) ) {
			return;
		}
		$module = \ElementorPro\Modules\ThemeBuilder\Module::instance();
		if ( ! $module || ! method_exists( $module, 'get_conditions_manager' ) ) {
			return;
		}
		$manager = $module->get_conditions_manager();
		if ( method_exists( $manager, 'get_cache' ) ) {
			$cache = $manager->get_cache();
			if ( $cache && method_exists( $cache, 'regenerate' ) ) {
				$cache->regenerate();
			}
		}
	}

	/**
	 * Theme Builder templates of a type that are active on the whole site (to warn about conflicts).
	 *
	 * @param string $type Template type.
	 * @return int[]
	 */
	public static function existing_templates( $type ) {
		$q = get_posts(
			array(
				'post_type'      => 'elementor_library',
				'post_status'    => 'publish',
				'posts_per_page' => 20,
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'   => '_elementor_template_type',
						'value' => $type,
					),
				),
			)
		);
		$out = array();
		foreach ( $q as $id ) {
			$cond = get_post_meta( $id, '_elementor_conditions', true );
			if ( ! empty( $cond ) ) {
				$out[] = (int) $id;
			}
		}
		return $out;
	}

	public static function delete_post_css( $post_id ) {
		delete_post_meta( $post_id, '_elementor_css' );
		delete_post_meta( $post_id, '_elementor_element_cache' );
		delete_post_meta( $post_id, '_elementor_page_assets' );
	}

	public static function clear_cache() {
		$el = \Elementor\Plugin::$instance;
		if ( ! empty( $el->files_manager ) && method_exists( $el->files_manager, 'clear_cache' ) ) {
			$el->files_manager->clear_cache();
		}
	}
}
