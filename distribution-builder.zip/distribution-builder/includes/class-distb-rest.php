<?php
/**
 * REST routes used by the Build screen. Every route needs manage_options and the REST nonce.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DistB_Rest {

	const NS = 'distb/v1';

	public static function routes() {
		$admin = function () {
			return current_user_can( 'manage_options' );
		};
		$routes = array(
			array( '/status', 'GET', 'status' ),
			array( '/check', 'POST', 'check' ),
			array( '/plan', 'POST', 'plan' ),
			array( '/build', 'POST', 'build' ),
			array( '/step', 'POST', 'step' ),
			array( '/cancel', 'POST', 'cancel' ),
			array( '/reset', 'POST', 'reset' ),
			array( '/library', 'GET', 'library' ),
			array( '/library/validate', 'POST', 'validate' ),
			array( '/track/(?P<id>[A-Za-z0-9_-]+)', 'GET', 'track' ),
		);
		foreach ( $routes as $r ) {
			register_rest_route(
				self::NS,
				$r[0],
				array(
					'methods'             => $r[1],
					'callback'            => array( __CLASS__, $r[2] ),
					'permission_callback' => $admin,
				)
			);
		}
	}

	private static function guard( $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( DistB_Exception $e ) {
			$data = array( 'status' => 400 );
			if ( ! empty( $e->context['errors'] ) ) {
				$data['errors'] = $e->context['errors'];
			}
			if ( ! empty( $e->context['plan'] ) ) {
				$data['track'] = DistB_Track::text( $e->context['plan'] );
			}
			return new WP_Error( 'distb_error', $e->getMessage(), $data );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'distb_fatal', $e->getMessage() . ' (' . basename( $e->getFile() ) . ':' . $e->getLine() . ')', array( 'status' => 500 ) );
		}
	}

	public static function status() {
		return self::guard(
			function () {
				$runner  = new DistB_Runner( distb_library() );
				$state   = $runner->state();
				$plan    = $runner->plan();
				$pending = get_option( DistB_Plugin::PENDING_OPTION, array() );
				$out     = array(
					'state'    => $state ? array(
						'build_id' => $state['build_id'],
						'status'   => $state['status'],
						'steps'    => $state['steps'],
					) : null,
					'track'    => ( $state && $plan ) ? DistB_Track::text( $plan, $state ) : '',
					'pending'  => $pending ? array(
						'build_id' => $pending['build_id'],
						'track'    => DistB_Track::text( $pending ),
						'warnings' => $pending['warnings'],
					) : null,
					'pages'    => array(),
					'history'  => array_reverse( array_values( (array) get_option( DistB_Runner::HISTORY_OPTION, array() ) ) ),
					'previous' => $runner->previous_build(),
				);
				if ( $state && ! empty( $state['pages'] ) ) {
					foreach ( $state['pages'] as $slug => $id ) {
						$out['pages'][] = array(
							'title' => get_the_title( $id ),
							'view'  => get_permalink( $id ),
							'edit'  => admin_url( 'post.php?post=' . $id . '&action=elementor' ),
						);
					}
				}
				return $out;
			}
		);
	}

	public static function check() {
		return self::guard(
			function () {
				return ( new DistB_Preflight( distb_library(), distb_recipes() ) )->run();
			}
		);
	}

	public static function plan( WP_REST_Request $req ) {
		return self::guard(
			function () use ( $req ) {
				$in = $req->get_json_params();
				$in = is_array( $in ) ? $in : array();
				if ( ! empty( $in['track_json'] ) ) {
					$track = json_decode( (string) $in['track_json'], true );
					if ( ! is_array( $track ) ) {
						throw new DistB_Exception( 'The track file is not valid JSON.' );
					}
					$in['track'] = $track;
				}
				$plan = DistB_Plugin::make_plan( $in );
				return array(
					'build_id' => $plan['build_id'],
					'seed'     => $plan['seed'],
					'kit'      => $plan['kit']['name'],
					'warnings' => $plan['warnings'],
					'track'    => DistB_Track::text( $plan ),
				);
			}
		);
	}

	public static function build( WP_REST_Request $req ) {
		return self::guard(
			function () use ( $req ) {
				return DistB_Plugin::start_pending( (string) $req->get_param( 'build_id' ) );
			}
		);
	}

	public static function step( WP_REST_Request $req ) {
		return self::guard(
			function () use ( $req ) {
				$runner = new DistB_Runner( distb_library() );
				$res    = $runner->run_next( (bool) $req->get_param( 'retry' ) );
				$res['track'] = DistB_Track::text( $runner->plan(), $runner->state() );
				return $res;
			}
		);
	}

	public static function cancel() {
		return self::guard(
			function () {
				delete_option( DistB_Plugin::PENDING_OPTION );
				( new DistB_Runner( distb_library() ) )->cancel();
				return array( 'ok' => true );
			}
		);
	}

	public static function reset( WP_REST_Request $req ) {
		return self::guard(
			function () use ( $req ) {
				$runner   = new DistB_Runner( distb_library() );
				$state    = $runner->state();
				$build_id = (string) $req->get_param( 'build_id' );
				if ( '' === $build_id && ! empty( $state['build_id'] ) ) {
					$build_id = $state['build_id'];
				}
				if ( '' === $build_id ) {
					throw new DistB_Exception( 'There is no build to reset.' );
				}
				$plan  = $runner->plan();
				$brand = isset( $plan['site']['brand'] ) && $plan['build_id'] === $build_id ? $plan['site']['brand'] : $build_id;
				if ( trim( (string) $req->get_param( 'confirm' ) ) !== $brand ) {
					throw new DistB_Exception( 'Type "' . $brand . '" to confirm the reset.' );
				}
				if ( $runner->is_running() ) {
					$runner->cancel();
				}
				return ( new DistB_Cleaner() )->reset( $build_id, (bool) $req->get_param( 'keep_media' ) );
			}
		);
	}

	public static function library() {
		return self::guard(
			function () {
				$lib    = distb_library();
				$struct = $lib->check_structure( distb_recipes() );
				return array(
					'root'     => $lib->root(),
					'counts'   => $struct['counts'],
					'errors'   => $struct['errors'],
					'warnings' => $struct['warnings'],
					'checksum' => $lib->exists() ? $lib->checksum() : '',
					'media'    => is_file( $lib->root() . 'media/media-map.json' ),
				);
			}
		);
	}

	public static function validate() {
		return self::guard(
			function () {
				@set_time_limit( 300 ); // phpcs:ignore
				$checker = class_exists( '\Elementor\Plugin' ) ? array( 'DistB_Elementor', 'unknown_widgets' ) : null;
				return DistB_Extractor::validate_library( distb_library(), distb_recipes(), $checker );
			}
		);
	}

	public static function track( WP_REST_Request $req ) {
		return self::guard(
			function () use ( $req ) {
				$id    = (string) $req['id'];
				$track = get_option( 'distb_track_' . $id, array() );
				if ( ! $track ) {
					$runner = new DistB_Runner( distb_library() );
					$plan   = $runner->plan();
					if ( ! empty( $plan['build_id'] ) && $plan['build_id'] === $id ) {
						$track = DistB_Track::build( $plan, $runner->state() );
					}
				}
				if ( ! $track ) {
					throw new DistB_Exception( 'No track for ' . $id );
				}
				return $track;
			}
		);
	}
}
