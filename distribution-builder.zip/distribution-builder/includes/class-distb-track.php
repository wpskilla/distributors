<?php
/**
 * The build track: every random pick, every file, every step result and warning.
 * Text to read, JSON to replay ("Rebuild from track").
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'DISTB_TESTING' ) ) {
	exit;
}

class DistB_Track {

	const TEMPLATE_LABELS = array(
		'header'          => 'HEADER',
		'footer'          => 'FOOTER',
		'loop_item'       => 'LOOP ITEM',
		'single_product'  => 'SINGLE',
		'product_archive' => 'ARCHIVE',
	);

	/**
	 * @param array $plan  Plan.
	 * @param array $state Runner state (may be empty for a plan preview).
	 * @return array{version:int,build_id:string,text:string,plan:array,state:array}
	 */
	public static function build( array $plan, array $state = array() ) {
		return array(
			'version'  => 1,
			'build_id' => $plan['build_id'],
			'text'     => self::text( $plan, $state ),
			'plan'     => $plan,
			'state'    => $state,
		);
	}

	/**
	 * Human-readable track.
	 *
	 * @param array $plan  Plan.
	 * @param array $state State.
	 * @return string
	 */
	public static function text( array $plan, array $state = array() ) {
		$steps = isset( $state['steps'] ) ? $state['steps'] : array();
		$L     = array();
		$site  = isset( $plan['site'] ) ? $plan['site'] : array();

		$L[] = 'DISTRIBUTION BUILDER — BUILD TRACK';
		$L[] = self::kv( 'build_id', $plan['build_id'] );
		$L[] = self::kv( 'status', $state ? $state['status'] : 'plan only (nothing written yet)' );
		$L[] = self::kv( 'seed', $plan['seed'] );
		if ( ! empty( $plan['replayed'] ) ) {
			$L[] = self::kv( 'replay of', $plan['replayed'] );
		}
		$L[] = self::kv( 'site', ( isset( $site['site_url'] ) ? $site['site_url'] . '  ' : '' ) . '(' . ( isset( $site['brand'] ) ? $site['brand'] : '' ) . ')' );
		$L[] = self::kv( 'library', $plan['library']['kits'] . ' kits · checksum ' . $plan['library']['checksum'] );
		if ( ! empty( $state['started'] ) ) {
			$L[] = self::kv( 'started', gmdate( 'Y-m-d H:i:s', $state['started'] ) . ' UTC' );
		}
		$L[] = '';
		$L[] = self::row( 'global_kits > ' . $plan['kit']['name'], $plan['kit']['forced'] ? '(forced)' : '(pick ' . $plan['kit']['index'] . ' of ' . $plan['kit']['of'] . ')', '', 0 );
		$L[] = '';

		if ( $state ) {
			if ( isset( $steps['cleanup'] ) ) {
				$L[] = self::row( 'CLEANUP    previous build', '', self::status( $steps['cleanup'] ), 0 );
			}
			if ( isset( $steps['kit'] ) ) {
				$L[] = self::row( 'KIT        global_kits > ' . $plan['kit']['name'] . ' > site-settings', '', self::status( $steps['kit'] ), 0 );
			}
			if ( isset( $steps['media'] ) ) {
				$L[] = self::row( 'MEDIA      ' . ( isset( $steps['media']['note'] ) && $steps['media']['note'] ? $steps['media']['note'] : '' ), '', self::status( $steps['media'], false ), 0 );
			}
		}

		foreach ( $plan['templates'] as $key => $tpl ) {
			$label = isset( self::TEMPLATE_LABELS[ $key ] ) ? self::TEMPLATE_LABELS[ $key ] : strtoupper( $key );
			foreach ( $tpl['slots'] as $i => $slot ) {
				$head = 0 === $i ? str_pad( $label, 11 ) : str_repeat( ' ', 11 );
				$last = count( $tpl['slots'] ) - 1 === $i;
				$L[]  = self::row( $head . $slot['label'], self::pick( $slot ), $last && isset( $steps[ 'tpl:' . $key ] ) ? self::status( $steps[ 'tpl:' . $key ] ) : '', 0 );
			}
		}
		$L[] = '';

		foreach ( $plan['pages'] as $slug => $page ) {
			$st  = isset( $steps[ 'page:' . $slug ] ) ? $steps[ 'page:' . $slug ] : null;
			$pid = isset( $state['pages'][ $slug ] ) ? ' (post ' . $state['pages'][ $slug ] . ')' : '';
			$L[] = 'PAGE ' . $page['title'] . $pid . ( $st ? '   ' . self::status( $st ) : '' );
			foreach ( $page['slots'] as $i => $slot ) {
				$L[] = self::row( '  sec_' . ( $i + 1 ) . str_repeat( ' ', max( 1, 7 - strlen( (string) ( $i + 1 ) ) ) ) . $slot['label'], self::pick( $slot ), '', 0 );
			}
		}

		if ( $state ) {
			$L[] = '';
			$s   = isset( $state['stats'] ) ? $state['stats'] : array();
			$g   = function ( $k ) use ( $s ) {
				return isset( $s[ $k ] ) ? $s[ $k ] : 0;
			};
			$L[] = 'TEXT       links ' . $g( 'links' ) . ' · emails ' . $g( 'emails' ) . ' · phones ' . $g( 'phones' ) . ' · brand names ' . $g( 'brands' ) . ' · tokens ' . $g( 'tokens' ) . ' · copyright ' . $g( 'copyright' );
			$L[] = 'REFS       menus ' . $g( 'menus' ) . ' · loop grids ' . $g( 'loops' ) . ' · source template refs removed ' . $g( 'template_refs' ) . ' · query IDs cleared ' . $g( 'query_cleared' );
			$L[] = 'GLOBALS    kept ' . $g( 'globals_kept' ) . ' · removed ' . $g( 'globals_cut' );
			if ( $g( 'phones_left' ) ) {
				$L[] = 'REVIEW     ' . $g( 'phones_left' ) . ' phone-like number(s) left from source sites (no phone was entered for this site)';
			}
			if ( isset( $steps['menu'] ) ) {
				$L[] = 'MENU       ' . self::status( $steps['menu'] );
			}
			if ( isset( $steps['settings'] ) ) {
				$L[] = 'SETTINGS   ' . self::status( $steps['settings'] );
			}
			if ( ! empty( $state['media']['failed'] ) ) {
				foreach ( $state['media']['failed'] as $url => $err ) {
					$L[] = 'WARN       media     ' . $url . '   ' . $err;
				}
			}
			foreach ( isset( $state['warnings'] ) ? $state['warnings'] : array() as $w ) {
				if ( 'media' === $w[0] ) {
					continue; // Already listed above with the reason.
				}
				$L[] = 'WARN       ' . str_pad( $w[0], 9 ) . ' ' . $w[1] . '   ' . $w[2];
			}
			foreach ( $steps as $key => $st ) {
				if ( 'failed' === $st['status'] ) {
					$L[] = 'FAILED     ' . $st['label'] . ': ' . $st['error'];
				}
			}
			if ( 'done' === $state['status'] ) {
				$L[] = 'DONE       ' . distb_duration( $state['finished'] - $state['started'] );
			}
		}
		if ( ! empty( $plan['warnings'] ) ) {
			$L[] = '';
			foreach ( $plan['warnings'] as $w ) {
				$L[] = 'PLAN WARN  ' . $w;
			}
		}
		return implode( "\n", $L ) . "\n";
	}

	private static function kv( $k, $v ) {
		return str_pad( $k, 11 ) . $v;
	}

	private static function row( $left, $mid, $right, $unused ) {
		$line = str_pad( $left, 58 );
		if ( '' !== $mid ) {
			$line .= str_pad( $mid, 18 );
		}
		if ( '' !== $right ) {
			$line .= ( '' === $mid ? str_repeat( ' ', 18 ) : '' ) . $right;
		}
		return rtrim( $line );
	}

	private static function pick( array $slot ) {
		return 'random' === $slot['kind'] ? '(pick ' . $slot['index'] . ' of ' . $slot['of'] . ')' : '';
	}

	private static function status( array $step, $with_note = true ) {
		$map = array(
			'done'    => 'OK',
			'failed'  => 'FAILED',
			'running' => 'RUNNING',
			'waiting' => 'WAITING',
		);
		$s   = isset( $map[ $step['status'] ] ) ? $map[ $step['status'] ] : $step['status'];
		if ( $with_note && ! empty( $step['note'] ) ) {
			$s .= '  ' . $step['note'];
		}
		if ( 'failed' === $step['status'] && ! empty( $step['error'] ) ) {
			$s .= '  ' . $step['error'];
		}
		return $s;
	}

	/**
	 * Folder for track files, protected from direct web access.
	 *
	 * @return string
	 */
	public static function dir() {
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'distribution-builder/';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! is_file( $dir . 'index.php' ) ) {
			file_put_contents( $dir . 'index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
		}
		if ( ! is_file( $dir . '.htaccess' ) ) {
			file_put_contents( $dir . '.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
		}
		return $dir;
	}

	public static function write_files( array $track ) {
		$dir  = self::dir();
		$base = $dir . 'track-' . sanitize_file_name( $track['build_id'] );
		file_put_contents( $base . '.txt', $track['text'] ); // phpcs:ignore
		file_put_contents( $base . '.json', wp_json_encode( $track, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ); // phpcs:ignore
	}
}
