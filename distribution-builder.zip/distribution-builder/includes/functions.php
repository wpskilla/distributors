<?php
/**
 * Shared helpers. No WordPress calls here, so the core can be unit tested without WordPress.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'DISTB_TESTING' ) ) {
	exit;
}

/**
 * Exception thrown by the builder. Carries optional context (file, slot) for the track.
 */
class DistB_Exception extends Exception {

	/** @var array */
	public $context = array();

	public function __construct( $message, array $context = array() ) {
		parent::__construct( $message );
		$this->context = $context;
	}
}

/**
 * Natural sort of file names: comp_1, comp_2, ..., comp_10 (not comp_1, comp_10, comp_2).
 *
 * @param string[] $names Base names.
 * @return string[]
 */
function distb_natsort( array $names ) {
	usort(
		$names,
		function ( $a, $b ) {
			return strnatcasecmp( $a, $b );
		}
	);
	return array_values( $names );
}

/**
 * Read a JSON file as an associative array. Strips a UTF-8 BOM if present.
 *
 * @param string $path Absolute path.
 * @return array
 * @throws DistB_Exception On a missing file or invalid JSON.
 */
function distb_read_json( $path ) {
	if ( ! is_file( $path ) || ! is_readable( $path ) ) {
		throw new DistB_Exception( 'File not found or not readable', array( 'file' => $path ) );
	}
	$raw = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( false === $raw || '' === trim( $raw ) ) {
		throw new DistB_Exception( 'File is empty', array( 'file' => $path ) );
	}
	if ( 0 === strpos( $raw, "\xEF\xBB\xBF" ) ) {
		$raw = substr( $raw, 3 );
	}
	$data = json_decode( $raw, true, 1024 );
	if ( JSON_ERROR_NONE !== json_last_error() ) {
		throw new DistB_Exception( 'Invalid JSON: ' . json_last_error_msg(), array( 'file' => $path ) );
	}
	if ( ! is_array( $data ) ) {
		throw new DistB_Exception( 'JSON root is not an object or array', array( 'file' => $path ) );
	}
	return $data;
}

/**
 * Write JSON to a file, creating folders as needed.
 *
 * @param string $path Absolute path.
 * @param mixed  $data Data.
 * @param bool   $pretty Pretty print.
 * @return void
 * @throws DistB_Exception On write failure.
 */
function distb_write_json( $path, $data, $pretty = true ) {
	$dir = dirname( $path );
	if ( ! is_dir( $dir ) && ! mkdir( $dir, 0755, true ) && ! is_dir( $dir ) ) { // phpcs:ignore
		throw new DistB_Exception( 'Cannot create folder', array( 'file' => $dir ) );
	}
	$flags = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
	if ( $pretty ) {
		$flags |= JSON_PRETTY_PRINT;
	}
	$json = json_encode( $data, $flags ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( false === $json ) {
		throw new DistB_Exception( 'Cannot encode JSON: ' . json_last_error_msg(), array( 'file' => $path ) );
	}
	if ( false === file_put_contents( $path, $json ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
		throw new DistB_Exception( 'Cannot write file', array( 'file' => $path ) );
	}
}

/**
 * True when an array is a list (0..n-1 keys).
 *
 * @param mixed $value Value.
 * @return bool
 */
function distb_is_list( $value ) {
	if ( ! is_array( $value ) ) {
		return false;
	}
	if ( array() === $value ) {
		return true;
	}
	return array_keys( $value ) === range( 0, count( $value ) - 1 );
}

/**
 * Turn "components/home/section_2/comp_11.json" into "components > home > section_2 > comp_11".
 *
 * @param string $relative Path relative to the library root.
 * @return string
 */
function distb_track_label( $relative ) {
	$relative = preg_replace( '/\.json$/i', '', $relative );
	return str_replace( '/', ' > ', $relative );
}

/**
 * Host of a URL in lower case without "www.".
 *
 * @param string $url URL.
 * @return string
 */
function distb_host( $url ) {
	$host = parse_url( $url, PHP_URL_HOST ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( ! is_string( $host ) ) {
		return '';
	}
	$host = strtolower( $host );
	return 0 === strpos( $host, 'www.' ) ? substr( $host, 4 ) : $host;
}

/**
 * Normalise a domain from user input: lower case, no scheme, no www, no path.
 *
 * @param string $domain Domain or URL.
 * @return string
 */
function distb_clean_domain( $domain ) {
	$domain = strtolower( trim( (string) $domain ) );
	$domain = preg_replace( '#^[a-z]+://#', '', $domain );
	$domain = preg_replace( '#[/?\#].*$#', '', $domain );
	$domain = preg_replace( '/^www\./', '', $domain );
	return $domain;
}

/**
 * Seven character hexadecimal Elementor element ID, unique within $used.
 *
 * @param array $used Map of IDs already used in this document (by reference).
 * @return string
 */
function distb_new_element_id( array &$used ) {
	do {
		$id = substr( bin2hex( random_bytes( 4 ) ), 0, 7 );
	} while ( isset( $used[ $id ] ) );
	$used[ $id ] = true;
	return $id;
}

/**
 * Format a duration in seconds as "2 min 41 s".
 *
 * @param float $seconds Seconds.
 * @return string
 */
function distb_duration( $seconds ) {
	$seconds = (int) round( $seconds );
	if ( $seconds < 60 ) {
		return $seconds . ' s';
	}
	return floor( $seconds / 60 ) . ' min ' . ( $seconds % 60 ) . ' s';
}
