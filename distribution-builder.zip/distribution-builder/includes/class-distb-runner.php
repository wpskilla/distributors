<?php
/**
 * Runs a saved build plan one step per request, so no request times out.
 * Every step is idempotent: Retry removes what the failed step half-made, then runs it again.
 * Progress is stored, so closing the browser tab and coming back resumes at the next step.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DistB_Runner {

	const PLAN_OPTION    = 'distb_plan';
	const STATE_OPTION   = 'distb_state';
	const LOCK_OPTION    = 'distb_step_lock';
	const HISTORY_OPTION = 'distb_history';
	const MEDIA_PER_STEP = 12;

	/** @var DistB_Library */
	private $library;

	/** @var array */
	private $plan;

	/** @var array */
	private $state;

	public function __construct( DistB_Library $library ) {
		$this->library = $library;
		$this->plan    = get_option( self::PLAN_OPTION, array() );
		$this->state   = get_option( self::STATE_OPTION, array() );
	}

	public function plan() {
		return $this->plan;
	}

	public function state() {
		return $this->state;
	}

	/* ------------------------------------------------------------------ */
	/* Starting                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * Save a validated plan and lay out its steps.
	 *
	 * @param array $plan    Plan.
	 * @param array $options replace_previous bool, media 'auto'|'pack'|'download'|'off'.
	 * @return array State.
	 * @throws DistB_Exception When another build is running.
	 */
	public function start( array $plan, array $options = array() ) {
		if ( $this->is_running() ) {
			throw new DistB_Exception( 'A build is already running (' . $this->state['build_id'] . '). Finish it, or Cancel it on the Build screen.' );
		}
		$previous = $this->previous_build();

		$plan['options'] = array_merge(
			array(
				'replace_previous' => true,
				'media'            => 'auto',
			),
			$options
		);

		$order = array();
		if ( $previous && $plan['options']['replace_previous'] ) {
			$order['cleanup'] = 'Remove previous build ' . $previous;
		}
		$order['backup'] = 'Back up current settings';
		$order['kit']    = 'Kit: ' . $plan['kit']['name'] . ' site settings';
		$order['media']  = 'Media';
		foreach ( $plan['templates'] as $key => $tpl ) {
			$order[ 'tpl:' . $key ] = 'Template: ' . $tpl['title'];
		}
		foreach ( $plan['pages'] as $slug => $page ) {
			$order[ 'page:' . $slug ] = 'Page: ' . $page['title'];
		}
		$order['menu']     = 'Main Menu';
		$order['settings'] = 'Site settings (front page, title, permalinks, logo)';
		$order['finalize'] = 'Finalize (CSS, caches, track)';

		$steps = array();
		foreach ( $order as $key => $label ) {
			$steps[ $key ] = array(
				'label'  => $label,
				'status' => 'waiting',
				'ms'     => 0,
				'note'   => '',
				'error'  => '',
			);
		}

		$this->plan  = $plan;
		$this->state = array(
			'build_id'  => $plan['build_id'],
			'status'    => 'running',
			'started'   => time(),
			'finished'  => 0,
			'previous'  => $previous,
			'steps'     => $steps,
			'objects'   => array(),
			'pages'     => array(),
			'templates' => array(),
			'kit'       => array(),
			'menu'      => array(),
			'media'     => array(
				'queue'    => null,
				'pos'      => 0,
				'pack'     => 0,
				'download' => 0,
				'reused'   => 0,
				'failed'   => array(),
				'skipped'  => 0,
			),
			'warnings'  => array(),
			'stats'     => array(),
		);
		update_option( self::PLAN_OPTION, $this->plan, false );
		$this->save();
		$this->history( 'running' );
		return $this->state;
	}

	public function is_running() {
		return ! empty( $this->state['status'] ) && 'running' === $this->state['status'];
	}

	/**
	 * Build ID of the last build that left content on this site, or ''.
	 *
	 * @return string
	 */
	public function previous_build() {
		if ( ! empty( $this->state['build_id'] ) && in_array( $this->state['status'], array( 'done', 'failed', 'cancelled' ), true ) ) {
			return $this->state['build_id'];
		}
		return '';
	}

	/**
	 * Stop a running build. What it made stays until Reset.
	 */
	public function cancel() {
		if ( $this->is_running() ) {
			$this->state['status']   = 'cancelled';
			$this->state['finished'] = time();
			$this->save();
			$this->history( 'cancelled' );
			$this->write_track();
		}
		delete_option( self::LOCK_OPTION );
	}

	/* ------------------------------------------------------------------ */
	/* Running                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * Run the next step.
	 *
	 * @param bool $retry Retry a failed step (cleans what it half-made first).
	 * @return array Response: state summary + done flag.
	 * @throws DistB_Exception When there is nothing to run or another request holds the lock.
	 */
	public function run_next( $retry = false ) {
		if ( ! $this->is_running() ) {
			throw new DistB_Exception( 'No build is running. Make a plan first.' );
		}
		$key = $this->next_step();
		if ( null === $key ) {
			return $this->response( null );
		}
		$step = $this->state['steps'][ $key ];
		if ( 'failed' === $step['status'] && ! $retry ) {
			throw new DistB_Exception( 'Step "' . $step['label'] . '" failed: ' . $step['error'] . ' Press Retry.' );
		}

		$this->lock();
		@set_time_limit( 120 ); // phpcs:ignore
		wp_raise_memory_limit( 'admin' );

		$t0 = microtime( true );
		try {
			if ( 'failed' === $step['status'] ) {
				$this->rollback_step( $key );
			}
			$this->state['steps'][ $key ]['status'] = 'running';
			$this->state['steps'][ $key ]['error']  = '';
			$more                                   = $this->execute( $key );
			$this->state['steps'][ $key ]['ms']    += (int) round( ( microtime( true ) - $t0 ) * 1000 );
			$this->state['steps'][ $key ]['status'] = $more ? 'running' : 'done';
		} catch ( \Throwable $e ) {
			$this->state['steps'][ $key ]['ms']    += (int) round( ( microtime( true ) - $t0 ) * 1000 );
			$this->state['steps'][ $key ]['status'] = 'failed';
			$msg                                    = $e->getMessage();
			if ( $e instanceof DistB_Exception && ! empty( $e->context['file'] ) ) {
				$msg .= ' [' . str_replace( $this->library->root(), '', $e->context['file'] ) . ']';
			}
			if ( ! ( $e instanceof DistB_Exception ) ) {
				$msg .= ' (' . basename( $e->getFile() ) . ':' . $e->getLine() . ')';
			}
			$this->state['steps'][ $key ]['error'] = $msg;
			$this->save();
			$this->write_track();
			$this->unlock();
			return $this->response( $key );
		}
		$this->save();
		$this->unlock();
		return $this->response( $key );
	}

	private function next_step() {
		foreach ( $this->state['steps'] as $key => $step ) {
			if ( 'done' !== $step['status'] ) {
				return $key;
			}
		}
		return null;
	}

	private function response( $key ) {
		$total = count( $this->state['steps'] );
		$done  = 0;
		foreach ( $this->state['steps'] as $s ) {
			if ( 'done' === $s['status'] ) {
				$done++;
			}
		}
		return array(
			'build_id' => $this->state['build_id'],
			'status'   => $this->state['status'],
			'step'     => $key,
			'steps'    => $this->state['steps'],
			'progress' => $total ? (int) floor( 100 * $done / $total ) : 0,
			'done'     => 'done' === $this->state['status'],
			'failed'   => $key && 'failed' === $this->state['steps'][ $key ]['status'],
		);
	}

	private function lock() {
		$now = time();
		if ( ! add_option( self::LOCK_OPTION, $now, '', false ) ) {
			$held = (int) get_option( self::LOCK_OPTION );
			if ( $now - $held < 300 ) {
				throw new DistB_Exception( 'Another step is still running. Wait a moment and try again.' );
			}
			update_option( self::LOCK_OPTION, $now, false );
		}
	}

	private function unlock() {
		delete_option( self::LOCK_OPTION );
	}

	private function save() {
		update_option( self::STATE_OPTION, $this->state, false );
	}

	/**
	 * @param string $key Step key.
	 * @return bool True when the step needs another request (media).
	 */
	private function execute( $key ) {
		if ( 'cleanup' === $key ) {
			$this->step_cleanup();
		} elseif ( 'backup' === $key ) {
			$this->step_backup();
		} elseif ( 'kit' === $key ) {
			$this->step_kit();
		} elseif ( 'media' === $key ) {
			return $this->step_media();
		} elseif ( 0 === strpos( $key, 'tpl:' ) ) {
			$this->step_template( substr( $key, 4 ), $key );
		} elseif ( 0 === strpos( $key, 'page:' ) ) {
			$this->step_page( substr( $key, 5 ), $key );
		} elseif ( 'menu' === $key ) {
			$this->step_menu();
		} elseif ( 'settings' === $key ) {
			$this->step_settings();
		} elseif ( 'finalize' === $key ) {
			$this->step_finalize();
		} else {
			throw new DistB_Exception( 'Unknown step ' . $key );
		}
		return false;
	}

	/* ------------------------------------------------------------------ */
	/* Steps                                                               */
	/* ------------------------------------------------------------------ */

	private function step_cleanup() {
		$cleaner = new DistB_Cleaner();
		$report  = $cleaner->reset( $this->state['previous'], true );
		$this->note( 'cleanup', $report['summary'] );
	}

	private function step_backup() {
		$kit_id = DistB_Elementor::active_kit_id();
		$backup = array(
			'kit_id'       => $kit_id,
			'kit_settings' => get_post_meta( $kit_id, '_elementor_page_settings', true ),
			'options'      => array(),
			'theme_mods'   => array(
				'nav_menu_locations' => get_theme_mod( 'nav_menu_locations' ),
				'custom_logo'        => get_theme_mod( 'custom_logo' ),
			),
			'pages'        => array(),
			'menu'         => null,
		);
		foreach ( array( 'show_on_front', 'page_on_front', 'blogname', 'permalink_structure' ) as $opt ) {
			$backup['options'][ $opt ] = get_option( $opt );
		}
		update_option( 'distb_backup_' . $this->state['build_id'], $backup, false );
		$this->note( 'backup', 'kit ' . $kit_id . ', 4 options, 2 theme mods' );
	}

	private function step_kit() {
		$changed = DistB_Elementor::activate_experiments( DistB_Elementor::EXPERIMENTS );
		if ( $changed ) {
			$this->warn( 'experiments', 'site-settings', 'activated ' . implode( ', ', $changed ) );
		}

		$file = 'global_kits/' . $this->plan['kit']['name'] . '/site-settings.json';
		$doc  = DistB_Transformer::load( $this->library->path( $file ) );
		if ( 'C' !== $doc['format'] ) {
			throw new DistB_Exception( 'site-settings.json is not a kit export (no "settings")', array( 'file' => $this->library->path( $file ) ) );
		}
		$t        = $this->transformer( array( $file ) );
		$settings = $t->transform_kit( $doc['settings'] );
		$this->collect( $t );
		$kit_id = DistB_Elementor::save_kit_settings( $settings );
		$ids    = DistB_Transformer::kit_global_ids( $settings );

		$this->state['kit'] = array(
			'id'     => $kit_id,
			'colors' => count( $ids['colors'] ),
			'fonts'  => count( $ids['typography'] ),
		);
		$this->note( 'kit', 'post ' . $kit_id . ' · colors ' . count( $ids['colors'] ) . ' · fonts ' . count( $ids['typography'] ) );
	}

	private function step_media() {
		$mode  = isset( $this->plan['options']['media'] ) ? $this->plan['options']['media'] : 'auto';
		$m     = &$this->state['media'];
		$media = new DistB_Media( $this->library );

		if ( null === $m['queue'] ) {
			$urls = array();
			$host = distb_host( home_url() );
			foreach ( DistB_Planner::files( $this->plan ) as $file ) {
				$doc  = DistB_Transformer::load( $this->library->path( $file ) );
				$node = 'C' === $doc['format'] ? $doc['settings'] : $doc['elements'];
				foreach ( DistB_Transformer::collect_media_urls( $node, $host ) as $url ) {
					$urls[ $url ] = true;
				}
			}
			$m['queue'] = array_keys( $urls );
			$m['pos']   = 0;
		}

		$t0    = microtime( true );
		$total = count( $m['queue'] );
		$n     = 0;
		while ( $m['pos'] < $total && $n < self::MEDIA_PER_STEP && ( microtime( true ) - $t0 ) < 25 ) {
			$url = $m['queue'][ $m['pos'] ];
			$res = $media->import( $url, $this->state['build_id'], $mode );
			if ( 'failed' === $res['status'] ) {
				$m['failed'][ $url ] = $res['error'];
			} elseif ( 'skipped' === $res['status'] ) {
				$m['skipped']++;
			} else {
				$m[ $res['status'] ]++;
				if ( in_array( $res['status'], array( 'pack', 'download' ), true ) ) {
					$this->object( 'media', $res['id'] );
				}
			}
			$m['pos']++;
			$n++;
		}
		unset( $m );
		$m = $this->state['media'];
		$this->note( 'media', $m['pos'] . ' of ' . $total . ' · pack ' . $m['pack'] . ' · downloaded ' . $m['download'] . ' · reused ' . $m['reused'] . ' · failed ' . count( $m['failed'] ) . ( $m['skipped'] ? ' · skipped ' . $m['skipped'] : '' ) );
		return $m['pos'] < $total;
	}

	private function step_template( $key, $step_key ) {
		$tpl = $this->plan['templates'][ $key ];
		$id  = DistB_Elementor::create_template( $tpl['type'], $tpl['title'], $this->state['build_id'] );
		$this->object( $step_key, $id );

		$opts = array(
			'is_chrome'    => in_array( $key, array( 'header', 'footer' ), true ),
			'banner_title' => $tpl['banner_title'],
		);
		list( $elements, $page_settings ) = $this->assemble( $tpl['slots'], $opts );
		if ( 'loop_item' === $key && ! isset( $page_settings['source'] ) ) {
			// Elementor Pro reads the loop item source from this meta (best effort; harmless if unused).
			update_post_meta( $id, '_elementor_source', 'product' );
		}
		$res        = DistB_Elementor::save_document( $id, $elements, $page_settings );
		$conditions = DistB_Elementor::save_conditions( $id, $tpl['conditions'] );

		$this->state['templates'][ $key ] = $id;
		$note                             = 'post ' . $id . ' · ' . $res['saved'] . ' elements' . ( 'direct' === $res['method'] ? ' (direct save)' : '' );
		if ( $conditions ) {
			$note .= ' · ' . implode( ', ', $conditions );
		}
		$this->check_saved( $res, $step_key );
		$this->note( $step_key, $note );
	}

	private function step_page( $slug, $step_key ) {
		$page   = $this->plan['pages'][ $slug ];
		$backup = get_option( 'distb_backup_' . $this->state['build_id'], array() );
		$pages  = isset( $backup['pages'] ) ? $backup['pages'] : array();
		$res    = DistB_Elementor::upsert_page( $slug, $page['title'], $this->state['build_id'], $pages );
		if ( $res['created'] ) {
			$this->object( $step_key, $res['id'] );
		} else {
			$backup['pages'] = $pages;
			update_option( 'distb_backup_' . $this->state['build_id'], $backup, false );
		}

		$first = $page['slots'][0];
		$opts  = array(
			'banner_title' => ( 'kit' === $first['kind'] && 'page_banner' === $first['key'] ) ? $page['title'] : '',
		);
		list( $elements ) = $this->assemble( $page['slots'], $opts );
		$save             = DistB_Elementor::save_document( $res['id'], $elements );

		$this->state['pages'][ $slug ] = $res['id'];
		$this->check_saved( $save, $step_key );
		$this->note( $step_key, 'post ' . $res['id'] . ( $res['created'] ? '' : ' (updated existing page)' ) . ' · ' . $save['saved'] . ' elements' . ( 'direct' === $save['method'] ? ' (direct save)' : '' ) );
	}

	private function step_menu() {
		$backup = get_option( 'distb_backup_' . $this->state['build_id'], array() );
		$term   = get_term_by( 'slug', 'main-menu', 'nav_menu' );
		if ( $term ) {
			$menu_id = (int) $term->term_id;
			$items   = wp_get_nav_menu_items( $menu_id );
			if ( empty( $backup['menu'] ) && empty( $this->state['menu']['created'] ) ) {
				$saved = array();
				foreach ( (array) $items as $it ) {
					$saved[] = array(
						'title'     => $it->title,
						'object'    => $it->object,
						'object_id' => $it->object_id,
						'type'      => $it->type,
						'url'       => $it->url,
						'parent'    => $it->menu_item_parent,
						'order'     => $it->menu_order,
					);
				}
				$backup['menu'] = array(
					'id'    => $menu_id,
					'items' => $saved,
				);
				update_option( 'distb_backup_' . $this->state['build_id'], $backup, false );
			}
			foreach ( (array) $items as $it ) {
				wp_delete_post( $it->ID, true );
			}
		} else {
			$menu_id = wp_create_nav_menu( 'Main Menu' );
			if ( is_wp_error( $menu_id ) ) {
				throw new DistB_Exception( 'Cannot create the menu: ' . $menu_id->get_error_message() );
			}
			wp_update_term( $menu_id, 'nav_menu', array( 'slug' => 'main-menu' ) );
			$this->state['menu']['created'] = (int) $menu_id;
		}

		$count = 0;
		foreach ( $this->plan['menu'] as $i => $slug ) {
			if ( empty( $this->state['pages'][ $slug ] ) ) {
				continue;
			}
			$item = wp_update_nav_menu_item(
				$menu_id,
				0,
				array(
					'menu-item-object-id' => $this->state['pages'][ $slug ],
					'menu-item-object'    => 'page',
					'menu-item-type'      => 'post_type',
					'menu-item-status'    => 'publish',
					'menu-item-position'  => $i + 1,
				)
			);
			if ( ! is_wp_error( $item ) ) {
				$count++;
			}
		}

		$locations = get_theme_mod( 'nav_menu_locations', array() );
		if ( ! is_array( $locations ) ) {
			$locations = array();
		}
		$locations['menu-1'] = (int) $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );

		$this->state['menu']['id']    = (int) $menu_id;
		$this->state['menu']['items'] = $count;
		$this->note( 'menu', 'main-menu · ' . $count . ' items' );
	}

	private function step_settings() {
		$notes = array();
		if ( ! empty( $this->state['pages']['home'] ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', (int) $this->state['pages']['home'] );
			$notes[] = 'front page = Home';
		}
		$site = $this->plan['site'];
		if ( ! empty( $site['brand'] ) ) {
			update_option( 'blogname', $site['brand'] );
			$notes[] = 'title = ' . $site['brand'];
		}
		if ( '/%postname%/' !== get_option( 'permalink_structure' ) ) {
			global $wp_rewrite;
			$wp_rewrite->set_permalink_structure( '/%postname%/' );
			$notes[] = 'permalinks = post name';
		}
		if ( ! empty( $site['logo_id'] ) && get_post( (int) $site['logo_id'] ) ) {
			set_theme_mod( 'custom_logo', (int) $site['logo_id'] );
			$notes[] = 'logo set';
		}
		$this->note( 'settings', implode( ' · ', $notes ) );
	}

	private function step_finalize() {
		DistB_Elementor::clear_cache();
		DistB_Elementor::regenerate_conditions_cache();
		flush_rewrite_rules( false );
		( new DistB_Media( $this->library ) )->prune();

		$this->state['status']   = 'done';
		$this->state['finished'] = time();
		$this->note( 'finalize', 'done in ' . distb_duration( $this->state['finished'] - $this->state['started'] ) );
		$this->state['steps']['finalize']['status'] = 'done';
		$this->save();
		$this->history( 'done' );
		$this->write_track();
	}

	/* ------------------------------------------------------------------ */
	/* Assembly                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * Load, transform and join the slots of one page or template, in order.
	 *
	 * @param array $slots Plan slots.
	 * @param array $opts  is_chrome, banner_title (applied to slot 1).
	 * @return array array( elements, page_settings )
	 */
	private function assemble( array $slots, array $opts ) {
		$files = array();
		foreach ( $slots as $slot ) {
			$files[] = $slot['file'];
		}
		$t             = $this->transformer( $files );
		$elements      = array();
		$page_settings = array();
		foreach ( $slots as $i => $slot ) {
			$doc = DistB_Transformer::load( $this->library->path( $slot['file'] ) );
			if ( $doc['page_settings'] ) {
				$page_settings = array_merge( $page_settings, $doc['page_settings'] );
			}
			$slot_opts = array(
				'is_chrome'    => ! empty( $opts['is_chrome'] ),
				'banner_title' => 0 === $i && ! empty( $opts['banner_title'] ) ? $opts['banner_title'] : '',
			);
			$elements  = array_merge( $elements, $t->transform( $doc['elements'], distb_track_label( $slot['file'] ), $slot_opts ) );
		}
		unset( $page_settings['preview_id'] );
		$used     = array();
		$elements = DistB_Transformer::new_ids( $elements, $used );
		$this->collect( $t );
		return array( $elements, $page_settings );
	}

	/**
	 * A transformer configured for this site and build.
	 *
	 * @param string[] $files Files the step will read (their source domains are added).
	 * @return DistB_Transformer
	 */
	private function transformer( array $files ) {
		$sources = $this->library->sources();
		$domains = $sources['domains'];
		if ( ! empty( $this->plan['kit']['domain'] ) ) {
			$domains[] = $this->plan['kit']['domain'];
		}
		foreach ( $files as $file ) {
			$d = $this->library->sniff_source_domain( $file );
			if ( $d ) {
				$domains[] = $d;
			}
		}
		$brands = (array) $sources['extra_brand_names'];
		foreach ( (array) $sources['kits'] as $kit ) {
			if ( ! empty( $kit['brand'] ) ) {
				$brands[] = $kit['brand'];
			}
		}
		$emails = (array) $sources['extra_emails'];
		$phones = (array) $sources['extra_phones'];
		foreach ( (array) $sources['kits'] as $kit ) {
			if ( ! empty( $kit['email'] ) ) {
				$emails[] = $kit['email'];
			}
			if ( ! empty( $kit['phone'] ) ) {
				$phones[] = $kit['phone'];
			}
		}

		$kit_ids = array();
		try {
			$kit     = DistB_Transformer::load( $this->library->path( 'global_kits/' . $this->plan['kit']['name'] . '/site-settings.json' ) );
			$kit_ids = DistB_Transformer::kit_global_ids( $kit['settings'] );
		} catch ( DistB_Exception $e ) {
			$kit_ids = array();
		}

		$site  = $this->plan['site'];
		$logo  = null;
		if ( ! empty( $site['logo_id'] ) && get_post( (int) $site['logo_id'] ) ) {
			$logo = array(
				'id'  => (int) $site['logo_id'],
				'url' => (string) wp_get_attachment_url( (int) $site['logo_id'] ),
			);
		}
		$woo = array();
		foreach ( array( 'shop', 'cart', 'checkout', 'myaccount', 'terms' ) as $p ) {
			$id        = (int) get_option( 'woocommerce_' . $p . '_page_id' );
			$woo[ $p ] = $id > 0 ? $id : '';
		}
		$media = new DistB_Media( $this->library );

		return new DistB_Transformer(
			array(
				'home_url'          => home_url(),
				'brand'             => isset( $site['brand'] ) ? $site['brand'] : '',
				'email'             => isset( $site['email'] ) ? $site['email'] : '',
				'phone'             => isset( $site['phone'] ) ? $site['phone'] : '',
				'address'           => isset( $site['address'] ) ? $site['address'] : '',
				'year'              => gmdate( 'Y' ),
				'source_domains'    => $domains,
				'extra_brand_names' => $brands,
				'extra_emails'      => $emails,
				'extra_phones'      => $phones,
				'kit_global_ids'    => $kit_ids,
				'media_lookup'      => array( $media, 'lookup' ),
				'menu_slug'         => 'main-menu',
				'loop_template_id'  => isset( $this->state['templates']['loop_item'] ) ? (int) $this->state['templates']['loop_item'] : 0,
				'logo'              => $logo,
				'woo_pages'         => $woo,
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Bookkeeping                                                         */
	/* ------------------------------------------------------------------ */

	private function collect( DistB_Transformer $t ) {
		foreach ( $t->stats as $k => $v ) {
			$this->state['stats'][ $k ] = ( isset( $this->state['stats'][ $k ] ) ? $this->state['stats'][ $k ] : 0 ) + $v;
		}
		foreach ( $t->take_warnings() as $w ) {
			$this->warn( $w[0], $w[1], $w[2] );
		}
	}

	private function warn( $type, $file, $message ) {
		$key = md5( $type . $file . $message );
		if ( count( $this->state['warnings'] ) < 300 ) {
			$this->state['warnings'][ $key ] = array( $type, $file, $message );
		}
	}

	private function note( $step, $note ) {
		$this->state['steps'][ $step ]['note'] = $note;
	}

	private function object( $step, $id ) {
		$this->state['objects'][ $step ][] = (int) $id;
	}

	private function check_saved( array $res, $step_key ) {
		if ( $res['saved'] < $res['expected'] ) {
			$this->warn( 'save', $step_key, ( $res['expected'] - $res['saved'] ) . ' element(s) dropped by Elementor on save (unregistered widget?)' );
		}
	}

	/**
	 * Remove what a failed step half-made, so Retry starts clean.
	 *
	 * @param string $key Step key.
	 */
	private function rollback_step( $key ) {
		if ( ! empty( $this->state['objects'][ $key ] ) ) {
			foreach ( $this->state['objects'][ $key ] as $id ) {
				if ( 'attachment' === get_post_type( $id ) ) {
					continue; // Media is reusable; the map keeps it.
				}
				wp_delete_post( $id, true );
			}
			$this->state['objects'][ $key ] = array();
		}
		if ( 'menu' === $key && ! empty( $this->state['menu']['created'] ) ) {
			wp_delete_nav_menu( $this->state['menu']['created'] );
			$this->state['menu'] = array();
		}
		if ( 0 === strpos( $key, 'tpl:' ) ) {
			unset( $this->state['templates'][ substr( $key, 4 ) ] );
		}
	}

	private function history( $status ) {
		$history = get_option( self::HISTORY_OPTION, array() );
		if ( ! is_array( $history ) ) {
			$history = array();
		}
		$id             = $this->plan['build_id'];
		$history[ $id ] = array(
			'build_id' => $id,
			'status'   => $status,
			'kit'      => $this->plan['kit']['name'],
			'seed'     => $this->plan['seed'],
			'brand'    => isset( $this->plan['site']['brand'] ) ? $this->plan['site']['brand'] : '',
			'time'     => time(),
		);
		if ( count( $history ) > 100 ) {
			$history = array_slice( $history, -100, null, true );
		}
		update_option( self::HISTORY_OPTION, $history, false );
	}

	/**
	 * Save the track as an option and as text + JSON files in uploads/distribution-builder/.
	 */
	public function write_track() {
		$track = DistB_Track::build( $this->plan, $this->state );
		update_option( 'distb_track_' . $this->plan['build_id'], $track, false );
		DistB_Track::write_files( $track );
	}
}
