<?php
/**
 * Imports images used by the plan, once per URL, from the media pack (lib/media) or the live source site.
 * Keeps a map source URL → {id, url}. A failed image never stops the build.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DistB_Media {

	const MAP_OPTION = 'distb_media_map';

	/** @var DistB_Library */
	private $library;

	/** @var array|null */
	private $pack = null;

	/** @var array */
	private $map;

	public function __construct( DistB_Library $library ) {
		$this->library = $library;
		$map           = get_option( self::MAP_OPTION, array() );
		$this->map     = is_array( $map ) ? $map : array();
	}

	/**
	 * Lookup used by the transformer.
	 *
	 * @param string $url Source URL.
	 * @return array{id:int,url:string}|null
	 */
	public function lookup( $url ) {
		if ( isset( $this->map[ $url ] ) ) {
			$entry = $this->map[ $url ];
			if ( get_post( $entry['id'] ) ) {
				return $entry;
			}
		}
		return null;
	}

	/**
	 * Import one URL. Returns the result for the track.
	 *
	 * @param string $url      Source URL.
	 * @param string $build_id Build ID.
	 * @param string $mode     'auto' (pack, then download), 'pack' (pack only), 'download', 'off'.
	 * @return array{status:string,id?:int,url?:string,error?:string}
	 */
	public function import( $url, $build_id, $mode = 'auto' ) {
		$existing = $this->lookup( $url );
		if ( $existing ) {
			return array_merge( array( 'status' => 'reused' ), $existing );
		}
		$found = $this->find_attachment( $url );
		if ( $found ) {
			$this->remember( $url, $found );
			return array_merge( array( 'status' => 'reused' ), $found );
		}
		if ( 'off' === $mode ) {
			return array(
				'status' => 'skipped',
				'error'  => 'media import is off',
			);
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp    = '';
		$source = '';
		$pack   = $this->pack_file( $url );
		if ( $pack && 'download' !== $mode ) {
			$tmp = wp_tempnam( basename( $pack ) );
			if ( ! $tmp || ! copy( $pack, $tmp ) ) {
				return array(
					'status' => 'failed',
					'error'  => 'cannot copy from media pack',
				);
			}
			$source = 'pack';
		} elseif ( 'pack' === $mode ) {
			return array(
				'status' => 'failed',
				'error'  => 'not in media pack',
			);
		} else {
			$tmp = download_url( $url, 30 );
			if ( is_wp_error( $tmp ) ) {
				return array(
					'status' => 'failed',
					'error'  => $tmp->get_error_message(),
				);
			}
			$source = 'download';
		}

		$name = sanitize_file_name( basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
		$file = array(
			'name'     => $name ? $name : 'image-' . md5( $url ) . '.jpg',
			'tmp_name' => $tmp,
		);

		$svg_filter = null;
		if ( preg_match( '/\.svg$/i', $file['name'] ) ) {
			// Allow SVG for this one upload only, so icons and logos from the library come through.
			$svg_filter = function ( $mimes ) {
				$mimes['svg'] = 'image/svg+xml';
				return $mimes;
			};
			add_filter( 'upload_mimes', $svg_filter );
		}
		$id = media_handle_sideload( $file, 0, null, array( 'post_status' => 'inherit' ) );
		if ( $svg_filter ) {
			remove_filter( 'upload_mimes', $svg_filter );
		}
		if ( is_wp_error( $id ) ) {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
			return array(
				'status' => 'failed',
				'error'  => $id->get_error_message(),
			);
		}

		update_post_meta( $id, '_distb_source_url', esc_url_raw( $url ) );
		update_post_meta( $id, '_distb_build_id', $build_id );
		$entry = array(
			'id'  => (int) $id,
			'url' => (string) wp_get_attachment_url( $id ),
		);
		$this->remember( $url, $entry );
		return array_merge( array( 'status' => $source ), $entry );
	}

	private function remember( $url, array $entry ) {
		$this->map[ $url ] = $entry;
		update_option( self::MAP_OPTION, $this->map, false );
	}

	/**
	 * Remove map entries whose attachment no longer exists.
	 */
	public function prune() {
		foreach ( $this->map as $url => $entry ) {
			if ( ! get_post( $entry['id'] ) ) {
				unset( $this->map[ $url ] );
			}
		}
		update_option( self::MAP_OPTION, $this->map, false );
	}

	private function find_attachment( $url ) {
		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_distb_source_url', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => esc_url_raw( $url ), // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		if ( $ids ) {
			return array(
				'id'  => (int) $ids[0],
				'url' => (string) wp_get_attachment_url( $ids[0] ),
			);
		}
		return null;
	}

	/**
	 * File in the media pack for a URL: media-map.json entry, else <sha1(url)>.<ext>.
	 *
	 * @param string $url URL.
	 * @return string|null Absolute path.
	 */
	public function pack_file( $url ) {
		$dir = $this->library->root() . 'media/';
		if ( null === $this->pack ) {
			$this->pack = array();
			if ( is_file( $dir . 'media-map.json' ) ) {
				try {
					$this->pack = distb_read_json( $dir . 'media-map.json' );
				} catch ( DistB_Exception $e ) {
					$this->pack = array();
				}
			}
		}
		if ( isset( $this->pack[ $url ] ) ) {
			$f = $dir . basename( $this->pack[ $url ] );
			return is_file( $f ) ? $f : null;
		}
		$ext = strtolower( pathinfo( (string) wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
		$f   = $dir . sha1( $url ) . ( $ext ? '.' . $ext : '' );
		return is_file( $f ) ? $f : null;
	}

	/**
	 * Has the library a media pack?
	 *
	 * @return bool
	 */
	public function has_pack() {
		return is_file( $this->library->root() . 'media/media-map.json' );
	}
}
