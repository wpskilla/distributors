<?php
/**
 * Makes the build plan: every random pick for one build, decided and validated
 * BEFORE anything is written to the site.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'DISTB_TESTING' ) ) {
	exit;
}

class DistB_Planner {

	/** @var DistB_Library */
	private $library;

	/** @var array */
	private $recipes;

	public function __construct( DistB_Library $library, array $recipes ) {
		$this->library = $library;
		$this->recipes = $recipes;
	}

	/**
	 * Build a plan.
	 *
	 * @param int   $seed    Seed.
	 * @param array $options site (brand, email, phone, address, logo_id), force_kit, exclude_kits, variety.
	 * @return array Plan.
	 * @throws DistB_Exception On an empty library or slot.
	 */
	public function plan( $seed, array $options = array() ) {
		$rand    = new DistB_Randomizer( $seed );
		$options = array_merge(
			array(
				'site'         => array(),
				'force_kit'    => 0,
				'exclude_kits' => array(),
				'variety'      => false,
			),
			$options
		);

		// 1. Base kit (random_build_site_no).
		$kits = $this->library->kits();
		if ( ! $kits ) {
			throw new DistB_Exception( 'No global kits found in the library.' );
		}
		$all_count = count( $kits );
		$forced    = false;
		if ( $options['force_kit'] ) {
			$want = 'site_' . (int) $options['force_kit'];
			if ( ! in_array( $want, $kits, true ) ) {
				throw new DistB_Exception( 'Forced kit ' . $want . ' does not exist in global_kits/.' );
			}
			$kit_pick = array(
				'index' => array_search( $want, $kits, true ) + 1,
				'of'    => $all_count,
				'item'  => $want,
			);
			$forced   = true;
		} else {
			$pool = $kits;
			if ( $options['exclude_kits'] ) {
				$exclude = array_map(
					function ( $n ) {
						return 'site_' . (int) $n;
					},
					(array) $options['exclude_kits']
				);
				$pool    = array_values( array_diff( $kits, $exclude ) );
				if ( ! $pool ) {
					throw new DistB_Exception( 'Every kit is excluded. Remove some numbers from "Exclude kits".' );
				}
			}
			$kit_pick = $rand->pick( 'global_kits', $pool );
		}
		$kit = $kit_pick['item'];

		$plan = array(
			'build_id'  => 'db-' . gmdate( 'Ymd-His' ) . '-' . substr( bin2hex( random_bytes( 2 ) ), 0, 4 ),
			'seed'      => $rand->seed(),
			'created'   => time(),
			'site'      => $options['site'],
			'variety'   => (bool) $options['variety'],
			'library'   => array(
				'kits'     => $all_count,
				'checksum' => $this->library->checksum(),
			),
			'kit'       => array(
				'name'   => $kit,
				'number' => (int) substr( $kit, 5 ),
				'index'  => $kit_pick['index'],
				'of'     => $kit_pick['of'],
				'forced' => $forced,
				'domain' => $this->kit_domain( $kit ),
			),
			'templates' => array(),
			'pages'     => array(),
			'menu'      => $this->recipes['menu'],
		);

		// 2. Templates.
		foreach ( $this->recipes['templates'] as $key => $tpl ) {
			if ( empty( $tpl['enabled'] ) ) {
				continue;
			}
			$plan['templates'][ $key ] = array(
				'title'        => $tpl['title'],
				'type'         => $tpl['type'],
				'conditions'   => $tpl['conditions'],
				'banner_title' => isset( $tpl['banner_title'] ) ? $tpl['banner_title'] : '',
				'slots'        => $this->pick_slots( $rand, $kit, $tpl['slots'], $plan['variety'] ),
			);
		}

		// 3. Pages.
		foreach ( $this->recipes['pages'] as $slug => $page ) {
			$plan['pages'][ $slug ] = array(
				'title' => $page['title'],
				'slots' => $this->pick_slots( $rand, $kit, $page['slots'], $plan['variety'] ),
			);
		}

		return $plan;
	}

	/**
	 * Rebuild a plan from a saved track JSON: same kit and same files, no new random picks.
	 *
	 * @param array $track Track JSON (has "plan").
	 * @param array $site  New site details.
	 * @return array
	 * @throws DistB_Exception When a file in the track no longer exists.
	 */
	public function plan_from_track( array $track, array $site ) {
		if ( empty( $track['plan']['kit']['name'] ) ) {
			throw new DistB_Exception( 'This file is not a Distribution Builder track (no plan inside).' );
		}
		$plan             = $track['plan'];
		$plan['build_id'] = 'db-' . gmdate( 'Ymd-His' ) . '-' . substr( bin2hex( random_bytes( 2 ) ), 0, 4 );
		$plan['created']  = time();
		$plan['site']     = $site;
		$plan['replayed'] = isset( $track['plan']['build_id'] ) ? $track['plan']['build_id'] : '';
		foreach ( array( 'templates', 'pages' ) as $group ) {
			foreach ( $plan[ $group ] as $entry ) {
				foreach ( $entry['slots'] as $slot ) {
					if ( ! is_file( $this->library->path( $slot['file'] ) ) ) {
						throw new DistB_Exception( 'File from the track is missing in this library: ' . $slot['file'] );
					}
				}
			}
		}
		return $plan;
	}

	/**
	 * Pick the file for every slot in a recipe.
	 *
	 * @param DistB_Randomizer $rand    Randomizer.
	 * @param string           $kit     Kit folder.
	 * @param array            $slots   Recipe slots.
	 * @param bool             $variety Avoid two random slots of one page coming from the same source site.
	 * @return array
	 */
	private function pick_slots( DistB_Randomizer $rand, $kit, array $slots, $variety ) {
		$out        = array();
		$used_hosts = array();
		foreach ( $slots as $slot ) {
			list( $kind, $key ) = $slot;
			if ( 'kit' === $kind ) {
				$file  = $this->library->kit_file( $kit, $key );
				$out[] = array(
					'kind'  => 'kit',
					'key'   => $key,
					'file'  => $file,
					'label' => distb_track_label( $file ),
					'index' => 0,
					'of'    => 0,
				);
				continue;
			}

			$files = $this->library->components( $key );
			if ( ! $files ) {
				throw new DistB_Exception( 'Empty slot: components/' . $key . ' has no comp_N.json files.', array( 'slot' => $key ) );
			}
			$pick    = $rand->pick( $key, $files );
			$host    = '';
			$retries = 0;
			if ( $variety && count( $files ) > 1 ) {
				$host = $this->library->sniff_source_domain( $pick['item'] );
				while ( '' !== $host && isset( $used_hosts[ $host ] ) && $retries < 10 ) {
					$retries++;
					$pick = $rand->pick( $key, $files, $retries );
					$host = $this->library->sniff_source_domain( $pick['item'] );
				}
				if ( '' !== $host ) {
					$used_hosts[ $host ] = true;
				}
			}
			$out[] = array(
				'kind'    => 'random',
				'key'     => $key,
				'file'    => $pick['item'],
				'label'   => distb_track_label( $pick['item'] ),
				'index'   => $pick['index'],
				'of'      => $pick['of'],
				'repicks' => $retries,
			);
		}
		return $out;
	}

	/**
	 * Source domain of a kit: registry first, then manifest.json "site", then the banner's siteurl.
	 *
	 * @param string $kit Kit folder.
	 * @return string
	 */
	public function kit_domain( $kit ) {
		$sources = $this->library->sources();
		if ( ! empty( $sources['kits'][ $kit ]['domain'] ) ) {
			return distb_clean_domain( $sources['kits'][ $kit ]['domain'] );
		}
		$manifest = $this->library->path( 'global_kits/' . $kit . '/manifest.json' );
		if ( is_file( $manifest ) ) {
			try {
				$m = distb_read_json( $manifest );
				if ( ! empty( $m['site'] ) ) {
					return distb_host( $m['site'] );
				}
			} catch ( DistB_Exception $e ) {
				unset( $e ); // Fall through.
			}
		}
		return $this->library->sniff_source_domain( $this->library->kit_file( $kit, 'home_banner' ) );
	}

	/**
	 * Every file the plan uses, without duplicates.
	 *
	 * @param array $plan Plan.
	 * @return string[]
	 */
	public static function files( array $plan ) {
		$files = array( 'global_kits/' . $plan['kit']['name'] . '/site-settings.json' => true );
		foreach ( array( 'templates', 'pages' ) as $group ) {
			foreach ( $plan[ $group ] as $entry ) {
				foreach ( $entry['slots'] as $slot ) {
					$files[ $slot['file'] ] = true;
				}
			}
		}
		return array_keys( $files );
	}

	/**
	 * Parse and check every file in the plan.
	 *
	 * @param array         $plan           Plan.
	 * @param callable|null $widget_checker fn( string[] $types ): string[] unknown types. Null = skip.
	 * @return array{errors:string[],warnings:string[]}
	 */
	public function validate( array $plan, $widget_checker = null ) {
		$errors   = array();
		$warnings = array();
		$types    = array();
		$where    = array();

		$kit_ids = array();
		try {
			$kit_json = distb_read_json( $this->library->path( 'global_kits/' . $plan['kit']['name'] . '/site-settings.json' ) );
			if ( empty( $kit_json['settings'] ) || ! is_array( $kit_json['settings'] ) ) {
				$errors[] = 'global_kits/' . $plan['kit']['name'] . '/site-settings.json has no "settings" object.';
			} else {
				$kit_ids = DistB_Transformer::kit_global_ids( $kit_json['settings'] );
			}
		} catch ( DistB_Exception $e ) {
			$errors[] = $e->getMessage() . ': ' . $this->short( $e );
		}

		foreach ( array( 'templates', 'pages' ) as $group ) {
			foreach ( $plan[ $group ] as $key => $entry ) {
				foreach ( $entry['slots'] as $slot ) {
					try {
						$doc = DistB_Transformer::load( $this->library->path( $slot['file'] ) );
						if ( ! $doc['elements'] ) {
							$errors[] = $slot['file'] . ': no elements inside.';
							continue;
						}
						foreach ( $doc['elements'] as $el ) {
							if ( isset( $el['elType'] ) && 'section' === $el['elType'] ) {
								$warnings[] = $slot['file'] . ': uses legacy Section/Column layout (works, but containers are recommended).';
								break;
							}
						}
						if ( 'templates' === $group && in_array( $key, array( 'loop_item', 'single_product' ), true ) && 'random' === $slot['kind'] && 'A' === $doc['format'] ) {
							$warnings[] = $slot['file'] . ': copied (format A), not a Theme Builder export (format B). Template page settings are not included.';
						}
						foreach ( DistB_Transformer::widget_types( $doc['elements'] ) as $type ) {
							$types[ $type ]   = true;
							$where[ $type ][] = $slot['file'];
						}
						if ( $kit_ids ) {
							$missing = DistB_Transformer::missing_globals( $doc['elements'], $kit_ids );
							if ( $missing ) {
								$warnings[] = $slot['file'] . ': ' . count( $missing ) . ' global style reference(s) not in ' . $plan['kit']['name'] . ' (' . implode( ', ', array_slice( $missing, 0, 5 ) ) . '). They will be removed and the section keeps its own values.';
							}
						}
					} catch ( DistB_Exception $e ) {
						$errors[] = $e->getMessage() . ': ' . $this->short( $e );
					}
				}
			}
		}

		if ( $widget_checker && $types ) {
			$unknown = call_user_func( $widget_checker, array_keys( $types ) );
			foreach ( $unknown as $type ) {
				$errors[] = 'Widget "' . $type . '" is not registered on this site (used in ' . implode( ', ', array_unique( $where[ $type ] ) ) . '). Activate the plugin that provides it, or re-roll with a new seed.';
			}
		}

		return array(
			'errors'   => array_values( array_unique( $errors ) ),
			'warnings' => array_values( array_unique( $warnings ) ),
		);
	}

	private function short( DistB_Exception $e ) {
		$file = isset( $e->context['file'] ) ? $e->context['file'] : '';
		return str_replace( $this->library->root(), '', $file );
	}
}
