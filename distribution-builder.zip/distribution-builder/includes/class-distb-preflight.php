<?php
/**
 * Requirement and library checks. The builder refuses to start while any check fails.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DistB_Preflight {

	/** @var DistB_Library */
	private $library;

	/** @var array */
	private $recipes;

	/** @var array */
	private $checks = array();

	public function __construct( DistB_Library $library, array $recipes ) {
		$this->library = $library;
		$this->recipes = $recipes;
	}

	/**
	 * @return array{ok:bool,checks:array}
	 */
	public function run() {
		$this->checks = array();
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		// Server.
		$this->add( 'PHP ' . PHP_VERSION, version_compare( PHP_VERSION, '7.4', '>=' ) ? ( version_compare( PHP_VERSION, '8.1', '>=' ) ? 'pass' : 'warn' ) : 'fail', 'PHP 8.1 or newer is recommended; 7.4 is the minimum.' );
		global $wp_version;
		$this->add( 'WordPress ' . $wp_version, version_compare( $wp_version, '6.0', '>=' ) ? 'pass' : 'fail', 'WordPress 6.0 or newer is required.' );
		$mem = wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) );
		$this->add( 'PHP memory_limit ' . ini_get( 'memory_limit' ), ( $mem <= 0 || $mem >= 256 * 1024 * 1024 ) ? 'pass' : 'warn', 'Set memory_limit to 512M for large library files.' );
		$up = wp_upload_dir();
		$this->add( 'Uploads folder writable', ( empty( $up['error'] ) && wp_is_writable( $up['basedir'] ) ) ? 'pass' : 'fail', 'Media and track files are written to wp-content/uploads.' );

		// Theme and plugins.
		$theme = wp_get_theme();
		$hello = 'hello-elementor' === get_template();
		$this->add( 'Theme: ' . $theme->get( 'Name' ), $hello ? 'pass' : 'warn', 'The source sites use Hello Elementor. Other themes may add their own header, footer or page titles.' );

		$el_ver = defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '';
		$this->add( 'Elementor ' . ( $el_ver ? $el_ver : 'not active' ), $el_ver ? 'pass' : 'fail', 'Install and activate Elementor.' );
		$pro_ver = defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : '';
		$this->add( 'Elementor Pro ' . ( $pro_ver ? $pro_ver : 'not active' ), $pro_ver ? 'pass' : 'fail', 'Elementor Pro is needed for the header, footer, loop item, single product and form widgets.' );
		$woo = class_exists( 'WooCommerce' );
		$this->add( 'WooCommerce ' . ( $woo && defined( 'WC_VERSION' ) ? WC_VERSION : ( $woo ? 'active' : 'not active' ) ), $woo ? 'pass' : 'fail', 'WooCommerce is needed for the product loop item, single product template and product widgets.' );

		if ( $el_ver ) {
			foreach ( DistB_Elementor::missing_apis() as $msg ) {
				$this->add( $msg, 'fail', 'An Elementor update may have changed this. Use the Elementor version the library was exported with.' );
			}
		}

		// Plugins and Elementor version listed in the kit manifests.
		$kits = $this->library->exists() ? $this->library->kits() : array();
		if ( $kits ) {
			$manifest = $this->library->path( 'global_kits/' . $kits[0] . '/manifest.json' );
			if ( is_file( $manifest ) ) {
				try {
					$m = distb_read_json( $manifest );
					if ( $el_ver && ! empty( $m['elementor_version'] ) ) {
						$same = (int) $m['elementor_version'] === (int) $el_ver;
						$this->add( 'Library exported with Elementor ' . $m['elementor_version'], $same ? 'pass' : 'warn', 'Keep the site on the same major Elementor version as the library (' . $m['elementor_version'] . ').' );
					}
					foreach ( isset( $m['plugins'] ) ? (array) $m['plugins'] : array() as $p ) {
						if ( empty( $p['plugin'] ) || false !== strpos( $p['plugin'], 'all-in-one-wp-migration' ) ) {
							continue;
						}
						$file   = $p['plugin'] . '.php';
						$active = is_plugin_active( $file );
						if ( in_array( $p['plugin'], array( 'elementor/elementor', 'elementor-pro/elementor-pro', 'woocommerce/woocommerce' ), true ) ) {
							continue; // Checked above.
						}
						$this->add( 'Plugin used by the source sites: ' . $p['name'], $active ? 'pass' : 'warn', 'Install and activate it; sections that use its widgets or icons stop the plan otherwise.' );
					}
				} catch ( DistB_Exception $e ) {
					$this->add( 'manifest.json of ' . $kits[0], 'warn', $e->getMessage() );
				}
			}
		}

		// Elementor experiments.
		if ( $el_ver && class_exists( '\Elementor\Plugin' ) ) {
			foreach ( DistB_Elementor::EXPERIMENTS as $exp ) {
				$on = DistB_Elementor::experiment_active( $exp );
				$this->add( 'Elementor experiment "' . $exp . '"', $on ? 'pass' : 'warn', 'Off now; the build switches it on (container layouts need it).' );
			}
		}

		// Permalinks.
		$this->add( 'Permalinks: ' . ( get_option( 'permalink_structure' ) ? get_option( 'permalink_structure' ) : 'plain' ), '/%postname%/' === get_option( 'permalink_structure' ) ? 'pass' : 'warn', 'The build sets "Post name" so links like /contact-us/ work.' );

		// Theme Builder templates already active on this site (would compete with the new ones).
		if ( $pro_ver ) {
			foreach ( array( 'header', 'footer', 'product' ) as $type ) {
				$found = array_filter(
					DistB_Elementor::existing_templates( $type ),
					function ( $id ) {
						return '' === (string) get_post_meta( $id, '_distb_build_id', true );
					}
				);
				if ( $found ) {
					$this->add( 'Existing ' . $type . ' template(s) with display conditions: post ' . implode( ', ', $found ), 'warn', 'They may show instead of the new ones. Remove their conditions or delete them.' );
				}
			}
		}

		// Woo shop page slug clash.
		if ( $woo ) {
			$shop = (int) get_option( 'woocommerce_shop_page_id' );
			if ( $shop && isset( $this->recipes['pages'][ get_post_field( 'post_name', $shop ) ] ) ) {
				$this->add( 'WooCommerce Shop page uses the slug "' . get_post_field( 'post_name', $shop ) . '"', 'warn', 'A Shop page shows the product archive, so its Elementor content is ignored. Change the Shop page in WooCommerce → Settings → Products.' );
			}
		}

		// Library.
		$structure = $this->library->check_structure( $this->recipes );
		if ( $structure['errors'] ) {
			foreach ( array_slice( $structure['errors'], 0, 30 ) as $err ) {
				$this->add( 'Library: ' . $err, 'fail', '' );
			}
			if ( count( $structure['errors'] ) > 30 ) {
				$this->add( 'Library: ' . ( count( $structure['errors'] ) - 30 ) . ' more problem(s)', 'fail', 'Run "wp distb library validate" for the full list.' );
			}
		} else {
			$n = isset( $structure['counts']['global_kits'] ) ? $structure['counts']['global_kits'] : 0;
			$this->add( 'Library: ' . $n . ' kits, every slot has files', 'pass', $this->library->root() );
		}
		foreach ( $structure['warnings'] as $w ) {
			$this->add( 'Library: ' . $w, 'warn', '' );
		}

		$ok = true;
		foreach ( $this->checks as $c ) {
			if ( 'fail' === $c['status'] ) {
				$ok = false;
			}
		}
		return array(
			'ok'     => $ok,
			'checks' => $this->checks,
		);
	}

	private function add( $label, $status, $help ) {
		$this->checks[] = array(
			'label'  => $label,
			'status' => $status,
			'help'   => 'pass' === $status ? '' : $help,
		);
	}
}
