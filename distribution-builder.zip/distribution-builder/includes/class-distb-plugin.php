<?php
/**
 * Boots the plugin and holds the shared "make a plan" service used by the admin screen, REST and WP-CLI.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Library folder. Default: the plugin's lib/ folder.
 * Override with define( 'DISTB_LIB_DIR', '/path/to/lib' ) in wp-config.php, or the 'distb_library_dir' filter,
 * to keep a large library outside the plugin (so plugin updates never replace it).
 *
 * @return string
 */
function distb_library_dir() {
	$dir = defined( 'DISTB_LIB_DIR' ) ? DISTB_LIB_DIR : DISTB_PATH . 'lib';
	return (string) apply_filters( 'distb_library_dir', $dir );
}

/**
 * Recipes (filterable).
 *
 * @return array
 */
function distb_recipes() {
	static $recipes = null;
	if ( null === $recipes ) {
		$recipes = (array) apply_filters( 'distb_recipes', require DISTB_PATH . 'includes/recipes.php' );
	}
	return $recipes;
}

function distb_library() {
	static $lib = null;
	if ( null === $lib ) {
		$lib = new DistB_Library( distb_library_dir() );
	}
	return $lib;
}

class DistB_Plugin {

	const PENDING_OPTION = 'distb_pending_plan';

	public static function boot() {
		if ( is_admin() ) {
			DistB_Admin::init();
		}
		add_action( 'rest_api_init', array( 'DistB_Rest', 'routes' ) );
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			WP_CLI::add_command( 'distb', 'DistB_CLI' );
		}
	}

	/**
	 * Clean site details from user input.
	 *
	 * @param array $in Input.
	 * @return array
	 */
	public static function site_details( array $in ) {
		$phone = isset( $in['phone'] ) ? preg_replace( '/[^\d+()\s.-]/', '', (string) $in['phone'] ) : '';
		return array(
			'brand'    => isset( $in['brand'] ) ? sanitize_text_field( wp_unslash( $in['brand'] ) ) : '',
			'email'    => isset( $in['email'] ) ? sanitize_email( wp_unslash( $in['email'] ) ) : '',
			'phone'    => trim( $phone ),
			'address'  => isset( $in['address'] ) ? sanitize_text_field( wp_unslash( $in['address'] ) ) : '',
			'logo_id'  => isset( $in['logo_id'] ) ? absint( $in['logo_id'] ) : 0,
			'site_url' => home_url(),
		);
	}

	/**
	 * Run preflight, pick everything, validate every picked file. Writes nothing to the site.
	 *
	 * @param array $in brand, email, phone, address, logo_id, seed, force_kit, exclude_kits, variety,
	 *                  replace_previous, media, track (decoded track JSON for a replay).
	 * @return array Plan.
	 * @throws DistB_Exception With 'errors' context on any blocking problem.
	 */
	public static function make_plan( array $in ) {
		$library = distb_library();
		$recipes = distb_recipes();

		$pre = ( new DistB_Preflight( $library, $recipes ) )->run();
		if ( ! $pre['ok'] ) {
			$errors = array();
			foreach ( $pre['checks'] as $c ) {
				if ( 'fail' === $c['status'] ) {
					$errors[] = $c['label'] . ( $c['help'] ? ' — ' . $c['help'] : '' );
				}
			}
			throw new DistB_Exception( 'Preflight failed. Fix these first:', array( 'errors' => $errors ) );
		}

		$site = self::site_details( $in );
		if ( '' === $site['brand'] ) {
			throw new DistB_Exception( 'Brand name is required.' );
		}

		$runner = new DistB_Runner( $library );
		if ( $runner->is_running() ) {
			$state = $runner->state();
			throw new DistB_Exception( 'Build ' . $state['build_id'] . ' is still running. Continue it or cancel it first.' );
		}
		$replace = ! isset( $in['replace_previous'] ) || ! empty( $in['replace_previous'] );
		if ( $runner->previous_build() && ! $replace ) {
			throw new DistB_Exception( 'This site already has build ' . $runner->previous_build() . '. Reset it first, or tick "Replace the previous build".' );
		}

		$planner = new DistB_Planner( $library, $recipes );
		if ( ! empty( $in['track'] ) && is_array( $in['track'] ) ) {
			$plan = $planner->plan_from_track( $in['track'], $site );
		} else {
			$seed = isset( $in['seed'] ) && '' !== trim( (string) $in['seed'] ) ? DistB_Randomizer::clean_seed( $in['seed'] ) : DistB_Randomizer::new_seed();
			$excl = array();
			if ( ! empty( $in['exclude_kits'] ) ) {
				$excl = array_filter( array_map( 'absint', is_array( $in['exclude_kits'] ) ? $in['exclude_kits'] : preg_split( '/[\s,]+/', (string) $in['exclude_kits'] ) ) );
			}
			$plan = $planner->plan(
				$seed,
				array(
					'site'         => $site,
					'force_kit'    => isset( $in['force_kit'] ) ? absint( $in['force_kit'] ) : 0,
					'exclude_kits' => $excl,
					'variety'      => ! empty( $in['variety'] ),
				)
			);
		}

		$checker = class_exists( '\Elementor\Plugin' ) ? array( 'DistB_Elementor', 'unknown_widgets' ) : null;
		$v       = $planner->validate( $plan, $checker );
		if ( $v['errors'] ) {
			throw new DistB_Exception(
				'The plan picked files that cannot be built (seed ' . $plan['seed'] . '):',
				array(
					'errors' => $v['errors'],
					'plan'   => $plan,
				)
			);
		}
		$plan['warnings'] = $v['warnings'];
		$plan['options']  = array(
			'replace_previous' => $replace,
			'media'            => isset( $in['media'] ) && in_array( $in['media'], array( 'auto', 'pack', 'download', 'off' ), true ) ? $in['media'] : 'auto',
		);
		update_option( self::PENDING_OPTION, $plan, false );
		return $plan;
	}

	/**
	 * Start the pending plan.
	 *
	 * @param string $build_id Must match the pending plan (protects against a stale screen).
	 * @return array Runner response.
	 * @throws DistB_Exception When there is no matching plan.
	 */
	public static function start_pending( $build_id ) {
		$plan = get_option( self::PENDING_OPTION, array() );
		if ( empty( $plan['build_id'] ) || $plan['build_id'] !== $build_id ) {
			throw new DistB_Exception( 'This plan is no longer current. Make the plan again.' );
		}
		$runner = new DistB_Runner( distb_library() );
		$runner->start( $plan, $plan['options'] );
		delete_option( self::PENDING_OPTION );
		return $runner->run_next();
	}
}
