<?php
/**
 * Generates a complete dummy library in the real folder layout, so every page, template,
 * menu and track line can be tested before the real library exists.
 *
 * Every section shows a label such as "DUMMY · home / section_2 / comp_1", so you can see
 * on the page which file landed in which slot. The dummy files use the same global color and
 * font IDs as your real kits (the shared Envato base), so real components drop in next to them.
 *
 * Run: wp distb library dummy --kits=4 --per-slot=3
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'DISTB_TESTING' ) ) {
	exit;
}

class DistB_Dummy {

	const DOMAIN = 'dummysource.test';

	/** @var int */
	private $n = 0;

	/** @var string */
	private $label = '';

	/** Palettes per kit: heading, text, button, button hover, light bg, extra light bg, dark bg, accent. */
	const PALETTES = array(
		array( 'Navy & Amber', '#0F1E3D', '#4A5568', '#F59E0B', '#D97706', '#EEF2F8', '#F8FAFC', '#0F1E3D', '#1E3A8A', 'Inter' ),
		array( 'Forest & Lime', '#123524', '#46574C', '#84CC16', '#65A30D', '#ECF5EE', '#F7FBF8', '#123524', '#166534', 'Poppins' ),
		array( 'Maroon & Gold', '#3B0A15', '#5B4A4E', '#C9A227', '#A8841A', '#F7EDEF', '#FCF8F9', '#3B0A15', '#7F1D1D', 'Playfair Display' ),
		array( 'Violet & Teal', '#24124A', '#4E4A5B', '#14B8A6', '#0D9488', '#F0ECF9', '#FAF8FD', '#24124A', '#5B21B6', 'Montserrat' ),
	);

	/** Dummy images (served from lib/media, the media pack). */
	public static function images() {
		$base = 'https://' . self::DOMAIN . '/wp-content/uploads/2026/10/';
		return array(
			'hero'   => $base . 'dummy-hero.jpg',
			'banner' => $base . 'dummy-banner.jpg',
			'cta'    => $base . 'dummy-cta.jpg',
			'about'  => $base . 'dummy-about.jpg',
			'card1'  => $base . 'dummy-card-1.jpg',
			'card2'  => $base . 'dummy-card-2.jpg',
		);
	}

	/**
	 * Write the dummy library.
	 *
	 * @param string $root     Library root.
	 * @param int    $kits     Number of kits.
	 * @param int    $per_slot Components per slot.
	 * @return int Files written.
	 */
	public function generate( $root, $kits = 4, $per_slot = 3 ) {
		$root  = rtrim( $root, '/\\' ) . '/';
		$count = 0;

		for ( $k = 1; $k <= $kits; $k++ ) {
			$dir = $root . 'global_kits/site_' . $k . '/';
			$p   = self::PALETTES[ ( $k - 1 ) % count( self::PALETTES ) ];
			distb_write_json( $dir . 'site-settings.json', $this->kit( $p ) );
			distb_write_json(
				$dir . 'manifest.json',
				array(
					'name'              => 'site_' . $k,
					'title'             => 'Dummy kit ' . $k . ' (' . $p[0] . ')',
					'site'              => 'https://' . self::DOMAIN,
					'elementor_version' => '4.2.4',
					'theme'             => array( 'slug' => 'hello-elementor' ),
					'plugins'           => array(),
				)
			);
			distb_write_json( $dir . 'header_dist.json', $this->format_b( 'header', 'Site Header', $this->header( $k ) ) );
			distb_write_json( $dir . 'footer_dist.json', $this->format_b( 'footer', 'Site Footer', $this->footer( $k ) ) );
			distb_write_json( $dir . 'home_banner.json', $this->format_a( $this->home_banner( $k ) ) );
			distb_write_json( $dir . 'page_banner.json', $this->format_a( $this->page_banner( $k ) ) );
			distb_write_json( $dir . 'cta.json', $this->format_a( $this->cta( $k ) ) );
			$count += 7;
		}

		$slots = array();
		for ( $s = 2; $s <= 10; $s++ ) {
			$slots[] = 'home/section_' . $s;
		}
		for ( $s = 2; $s <= 6; $s++ ) {
			$slots[] = 'about/section_' . $s;
		}
		$slots = array_merge( $slots, array( 'brands', 'category', 'category_card', 'faq', 'contact', 'products' ) );

		foreach ( $slots as $slot ) {
			for ( $c = 1; $c <= $per_slot; $c++ ) {
				$this->label = 'DUMMY · ' . $slot . ' / comp_' . $c;
				distb_write_json( $root . 'components/' . $slot . '/comp_' . $c . '.json', $this->format_a( $this->section( $slot, $c ) ) );
				$count++;
			}
		}
		for ( $c = 1; $c <= $per_slot; $c++ ) {
			$this->label = 'DUMMY · loop_item / comp_' . $c;
			distb_write_json( $root . 'components/loop_item/comp_' . $c . '.json', $this->format_b( 'loop-item', 'Loop Item ' . $c, $this->loop_item( $c ), array() ) );
			$this->label = 'DUMMY · single / comp_' . $c;
			distb_write_json( $root . 'components/single/comp_' . $c . '.json', $this->format_b( 'product', 'Single Product ' . $c, $this->single( $c ) ) );
			$count += 2;
		}
		return $count;
	}

	/* ------------------------------------------------------------------ */
	/* File formats                                                        */
	/* ------------------------------------------------------------------ */

	private function format_a( array $elements ) {
		return array(
			'type'     => 'elementor',
			'siteurl'  => 'https://' . self::DOMAIN . '/wp-json/',
			'elements' => $elements,
		);
	}

	private function format_b( $type, $title, array $content, array $page_settings = array() ) {
		return array(
			'content'       => $content,
			'page_settings' => $page_settings,
			'version'       => '0.4',
			'title'         => $title,
			'type'          => $type,
		);
	}

	private function kit( array $p ) {
		list( $name, $heading, $text, $btn, $btn_hover, $light, $xlight, $dark, $accent, $font ) = $p;
		$size = function ( $px ) {
			return array(
				'unit'  => 'px',
				'size'  => $px,
				'sizes' => array(),
			);
		};
		$typo = function ( $id, $title, $px, $weight, $family ) use ( $size ) {
			return array(
				'_id'                    => $id,
				'title'                  => $title,
				'typography_typography'  => 'custom',
				'typography_font_family' => $family,
				'typography_font_size'   => $size( $px ),
				'typography_font_weight' => $weight,
			);
		};
		$color = function ( $id, $title, $c ) {
			return array(
				'_id'   => $id,
				'title' => $title,
				'color' => $c,
			);
		};
		return array(
			'content'  => array(),
			'settings' => array(
				'system_colors'               => array(
					$color( 'secondary', 'Heading', $heading ),
					$color( 'primary', 'Basic Text', $text ),
					$color( 'text', 'Netral', '#FFFFFF' ),
					$color( 'accent', 'Transparent 20%', '#FFFFFF33' ),
				),
				'custom_colors'               => array(
					$color( '14caab8', 'Transparent 60%', '#FFFFFF99' ),
					$color( 'd49ac81', 'Button', $btn ),
					$color( '332724a', 'Button Hover', $btn_hover ),
					$color( '4d462f5', 'Line Color', '#E2E8F0' ),
					$color( 'cfa1f76', 'Light Background', $light ),
					$color( '7fbea4f', 'Extra Light Background', $xlight ),
					$color( 'c94d9ab', 'Smooth Dark Background', $accent ),
					$color( '044b931', 'Dark Background', $dark ),
					$color( '638d055', 'Extra Dark Background', '#0B0B12' ),
					$color( 'ec3c7a7', 'Accent 1', $btn ),
					$color( '3ee16e7', 'Accent 2', $accent ),
					$color( '529f949', 'Accent 3', $btn_hover ),
				),
				'system_typography'           => array(
					$typo( 'primary', 'Primary', 40, '700', $font ),
					$typo( 'secondary', 'Secondary', 24, '600', $font ),
					$typo( 'text', 'Text', 16, '400', 'Inter' ),
					$typo( 'accent', 'Accent', 15, '600', 'Inter' ),
				),
				'custom_typography'           => array(
					$typo( 'b2ce6af', 'Global Font', 16, '400', 'Inter' ),
					$typo( '69c152f', 'Small Font', 13, '500', 'Inter' ),
					$typo( '112b6c4', 'Footer', 15, '400', 'Inter' ),
					$typo( '520c191', 'Header', 15, '600', 'Inter' ),
					$typo( 'a435f28', 'Big Hero', 60, '700', $font ),
					$typo( '583e54c', 'H1', 52, '700', $font ),
					$typo( '5d167aa', 'H2', 40, '700', $font ),
					$typo( 'd3dae9a', 'H3', 30, '600', $font ),
					$typo( '83682a1', 'H4', 22, '600', $font ),
					$typo( '7044a64', 'H5', 19, '600', $font ),
					$typo( '84ca66e', 'H6', 14, '700', 'Inter' ),
				),
				'__globals__'                 => array(
					'body_color'                    => 'globals/colors?id=primary',
					'body_typography_typography'    => 'globals/typography?id=b2ce6af',
					'link_normal_color'             => 'globals/colors?id=d49ac81',
					'h1_color'                      => 'globals/colors?id=secondary',
					'h2_color'                      => 'globals/colors?id=secondary',
					'h3_color'                      => 'globals/colors?id=secondary',
					'h1_typography_typography'      => 'globals/typography?id=583e54c',
					'h2_typography_typography'      => 'globals/typography?id=5d167aa',
					'h3_typography_typography'      => 'globals/typography?id=d3dae9a',
					'button_text_color'             => 'globals/colors?id=text',
					'button_background_color'       => 'globals/colors?id=d49ac81',
					'button_hover_background_color' => 'globals/colors?id=332724a',
					'button_typography_typography'  => 'globals/typography?id=accent',
				),
				'button_border_radius'        => array(
					'unit'     => 'px',
					'top'      => '6',
					'right'    => '6',
					'bottom'   => '6',
					'left'     => '6',
					'isLinked' => true,
				),
				'container_width'             => $size( 1200 ),
				'viewport_md'                 => 768,
				'viewport_lg'                 => 1025,
				'page_title_selector'         => 'h1.entry-title',
				'hello_footer_copyright_text' => 'All rights reserved',
				'woocommerce_cart_page_id'    => 7,
				'woocommerce_checkout_page_id' => 8,
				'woocommerce_myaccount_page_id' => 9,
				'woocommerce_shop_page_id'    => '12',
				'activeItemIndex'             => 1,
			),
			'metadata' => array( 'dummy_palette' => $name ),
		);
	}

	/* ------------------------------------------------------------------ */
	/* Element helpers                                                     */
	/* ------------------------------------------------------------------ */

	private function id() {
		$this->n++;
		return substr( sha1( 'distb-dummy-' . $this->n ), 0, 7 );
	}

	private function pad( $t, $s = null ) {
		$s = null === $s ? $t : $s;
		return array(
			'unit'     => 'px',
			'top'      => (string) $t,
			'right'    => (string) $s,
			'bottom'   => (string) $t,
			'left'     => (string) $s,
			'isLinked' => false,
		);
	}

	private function box( array $settings, array $children, $inner = false ) {
		return array(
			'id'       => $this->id(),
			'elType'   => 'container',
			'isInner'  => $inner,
			'settings' => $settings,
			'elements' => $children,
		);
	}

	private function section_box( $bg, array $children, array $extra = array() ) {
		return $this->box(
			array_merge(
				array(
					'content_width'         => 'boxed',
					'flex_direction'        => 'column',
					'flex_gap'              => array(
						'unit'   => 'px',
						'size'   => 24,
						'column' => '24',
						'row'    => '24',
					),
					'padding'               => $this->pad( 90, 20 ),
					'padding_mobile'        => $this->pad( 60, 16 ),
					'background_background' => 'classic',
					'__globals__'           => array( 'background_color' => 'globals/colors?id=' . $bg ),
				),
				$extra
			),
			$children
		);
	}

	private function row( array $children, $gap = 30 ) {
		return $this->box(
			array(
				'content_width'      => 'full',
				'flex_direction'     => 'row',
				'flex_direction_mobile' => 'column',
				'flex_wrap'          => 'wrap',
				'flex_gap'           => array(
					'unit'   => 'px',
					'size'   => $gap,
					'column' => (string) $gap,
					'row'    => (string) $gap,
				),
			),
			$children,
			true
		);
	}

	private function col( array $children, $width = 50 ) {
		return $this->box(
			array(
				'content_width'  => 'full',
				'flex_direction' => 'column',
				'width'          => array(
					'unit' => '%',
					'size' => $width,
				),
				'width_mobile'   => array(
					'unit' => '%',
					'size' => 100,
				),
				'flex_gap'       => array(
					'unit'   => 'px',
					'size'   => 16,
					'column' => '16',
					'row'    => '16',
				),
				'flex_justify_content' => 'center',
			),
			$children,
			true
		);
	}

	private function w( $type, array $settings ) {
		return array(
			'id'         => $this->id(),
			'elType'     => 'widget',
			'widgetType' => $type,
			'settings'   => $settings,
			'elements'   => array(),
		);
	}

	private function tag( $dark ) {
		return $this->w(
			'heading',
			array(
				'title'       => $this->label,
				'header_size' => 'h6',
				'align'       => 'center',
				'__globals__' => array(
					'title_color'           => 'globals/colors?id=' . ( $dark ? 'ec3c7a7' : '3ee16e7' ),
					'typography_typography' => 'globals/typography?id=84ca66e',
				),
			)
		);
	}

	private function h( $text, $size = 'h2', $dark = false, $align = 'center' ) {
		$typo = array(
			'h1' => '583e54c',
			'h2' => '5d167aa',
			'h3' => 'd3dae9a',
			'h4' => '83682a1',
			'h5' => '7044a64',
		);
		return $this->w(
			'heading',
			array(
				'title'       => $text,
				'header_size' => $size,
				'align'       => $align,
				'__globals__' => array(
					'title_color'           => 'globals/colors?id=' . ( $dark ? 'text' : 'secondary' ),
					'typography_typography' => 'globals/typography?id=' . ( isset( $typo[ $size ] ) ? $typo[ $size ] : 'b2ce6af' ),
				),
			)
		);
	}

	private function p( $html, $dark = false, $align = 'center' ) {
		return $this->w(
			'text-editor',
			array(
				'editor'      => $html,
				'align'       => $align,
				'__globals__' => array(
					'text_color'            => 'globals/colors?id=' . ( $dark ? '14caab8' : 'primary' ),
					'typography_typography' => 'globals/typography?id=b2ce6af',
				),
			)
		);
	}

	private function btn( $text, $url, $align = 'center' ) {
		return $this->w(
			'button',
			array(
				'text'        => $text,
				'align'       => $align,
				'link'        => array(
					'url'               => $url,
					'is_external'       => '',
					'nofollow'          => '',
					'custom_attributes' => '',
				),
				'__globals__' => array(
					'background_color'      => 'globals/colors?id=d49ac81',
					'button_text_color'     => 'globals/colors?id=text',
					'typography_typography' => 'globals/typography?id=accent',
				),
			)
		);
	}

	private function img( $key ) {
		$images = self::images();
		return $this->w(
			'image',
			array(
				'image'      => array(
					'id'     => 9000 + $this->n,
					'url'    => $images[ $key ],
					'alt'    => '',
					'source' => 'library',
					'size'   => '',
				),
				'image_size' => 'large',
				'image_border_radius' => array(
					'unit'     => 'px',
					'top'      => '12',
					'right'    => '12',
					'bottom'   => '12',
					'left'     => '12',
					'isLinked' => true,
				),
			)
		);
	}

	private function icon_box( $icon, $title, $text, $dark = false ) {
		return $this->w(
			'icon-box',
			array(
				'selected_icon'    => array(
					'value'   => 'fas fa-' . $icon,
					'library' => 'fa-solid',
				),
				'title_text'       => $title,
				'description_text' => $text,
				'title_size'       => 'h4',
				'_padding'         => $this->pad( 24 ),
				'_background_background' => 'classic',
				'__globals__'      => array(
					'primary_color'                     => 'globals/colors?id=d49ac81',
					'title_color'                       => 'globals/colors?id=' . ( $dark ? 'text' : 'secondary' ),
					'description_color'                 => 'globals/colors?id=' . ( $dark ? '14caab8' : 'primary' ),
					'_background_color'                 => 'globals/colors?id=' . ( $dark ? '3ee16e7' : 'text' ),
					'title_typography_typography'       => 'globals/typography?id=7044a64',
					'description_typography_typography' => 'globals/typography?id=b2ce6af',
				),
			)
		);
	}

	private function cards( array $items, $dark ) {
		$cols = array();
		$w    = (int) floor( 100 / count( $items ) ) - 3;
		foreach ( $items as $it ) {
			$cols[] = $this->col( array( $this->icon_box( $it[0], $it[1], $it[2], $dark ) ), $w );
		}
		return $this->row( $cols );
	}

	/* ------------------------------------------------------------------ */
	/* Kit sections                                                        */
	/* ------------------------------------------------------------------ */

	private function home_banner( $k ) {
		$this->label = 'DUMMY · global_kits / site_' . $k . ' / home_banner';
		$img         = self::images();
		return array(
			$this->section_box(
				'044b931',
				array(
					$this->tag( true ),
					$this->h( 'Wholesale Supply Made Simple for {{brand_name}}', 'h1', true ),
					$this->p( '<p>Dummy Source Distribution connects retailers with reliable products, fair pricing and fast delivery. This hero comes from kit ' . $k . '.</p>', true ),
					$this->btn( 'Explore Partnership Opportunities', 'https://' . self::DOMAIN . '/contact-us/' ),
				),
				array(
					'min_height'                       => array(
						'unit' => 'vh',
						'size' => 80,
					),
					'flex_justify_content'             => 'center',
					'background_image'                 => array(
						'id'     => 101,
						'url'    => $img['hero'],
						'alt'    => '',
						'source' => 'library',
						'size'   => '',
					),
					'background_position'              => 'center center',
					'background_size'                  => 'cover',
					'background_overlay_background'    => 'classic',
					'background_overlay_opacity'       => array(
						'unit' => 'px',
						'size' => 0.7,
					),
					'__globals__'                      => array(
						'background_color'                 => 'globals/colors?id=044b931',
						'background_overlay_color'         => 'globals/colors?id=044b931',
					),
				)
			),
		);
	}

	private function page_banner( $k ) {
		$this->label = 'DUMMY · global_kits / site_' . $k . ' / page_banner';
		$img         = self::images();
		return array(
			$this->section_box(
				'044b931',
				array(
					$this->tag( true ),
					$this->h( 'Heading', 'h1', true ),
					$this->h( 'Reliable wholesale sourcing and product distribution for growing businesses.', 'h4', true ),
				),
				array(
					'min_height'                    => array(
						'unit' => 'px',
						'size' => 380,
					),
					'flex_justify_content'          => 'center',
					'background_image'              => array(
						'id'     => 102,
						'url'    => $img['banner'],
						'alt'    => '',
						'source' => 'library',
						'size'   => '',
					),
					'background_size'               => 'cover',
					'background_position'           => 'center center',
					'background_overlay_background' => 'classic',
					'background_overlay_opacity'    => array(
						'unit' => 'px',
						'size' => 0.75,
					),
					'__globals__'                   => array(
						'background_color'         => 'globals/colors?id=044b931',
						'background_overlay_color' => 'globals/colors?id=044b931',
					),
				)
			),
		);
	}

	private function cta( $k ) {
		$this->label = 'DUMMY · global_kits / site_' . $k . ' / cta';
		$img         = self::images();
		return array(
			$this->section_box(
				'c94d9ab',
				array(
					$this->tag( true ),
					$this->h( 'Ready to Strengthen Your Product Supply?', 'h2', true ),
					$this->p( '<p>Talk to the {{brand_name}} team today. Call {{phone}} or email {{email}}.</p>', true ),
					$this->btn( 'Contact Us', 'https://' . self::DOMAIN . '/contact-us/' ),
				),
				array(
					'background_image'              => array(
						'id'     => 103,
						'url'    => $img['cta'],
						'alt'    => '',
						'source' => 'library',
						'size'   => '',
					),
					'background_size'               => 'cover',
					'background_overlay_background' => 'classic',
					'background_overlay_opacity'    => array(
						'unit' => 'px',
						'size' => 0.8,
					),
					'__globals__'                   => array(
						'background_color'         => 'globals/colors?id=c94d9ab',
						'background_overlay_color' => 'globals/colors?id=c94d9ab',
					),
				)
			),
		);
	}

	private function header( $k ) {
		$this->label = 'DUMMY header site_' . $k;
		return array(
			$this->box(
				array(
					'content_width'         => 'boxed',
					'flex_direction'        => 'row',
					'flex_justify_content'  => 'space-between',
					'flex_align_items'      => 'center',
					'padding'               => $this->pad( 16, 20 ),
					'background_background' => 'classic',
					'__globals__'           => array( 'background_color' => 'globals/colors?id=text' ),
				),
				array(
					$this->w(
						'heading',
						array(
							'title'       => '{{brand_name}}',
							'header_size' => 'div',
							'link'        => array(
								'url'               => 'https://' . self::DOMAIN . '/',
								'is_external'       => '',
								'nofollow'          => '',
								'custom_attributes' => '',
							),
							'__globals__' => array(
								'title_color'           => 'globals/colors?id=secondary',
								'typography_typography' => 'globals/typography?id=83682a1',
							),
						)
					),
					$this->w(
						'nav-menu',
						array(
							'menu'        => 'main-menu',
							'layout'      => 'horizontal',
							'__globals__' => array(
								'color_menu_item'               => 'globals/colors?id=secondary',
								'color_menu_item_hover'         => 'globals/colors?id=d49ac81',
								'menu_typography_typography'    => 'globals/typography?id=520c191',
							),
						)
					),
					$this->btn( 'Get Started', 'https://' . self::DOMAIN . '/contact-us/', 'right' ),
				)
			),
		);
	}

	private function footer( $k ) {
		$this->label = 'DUMMY footer site_' . $k;
		$link        = function ( $url ) {
			return array(
				'url'               => $url,
				'is_external'       => '',
				'nofollow'          => '',
				'custom_attributes' => '',
			);
		};
		$items       = function ( array $rows ) {
			$out = array();
			foreach ( $rows as $i => $r ) {
				$out[] = array(
					'_id'           => substr( sha1( $r[0] . $i ), 0, 7 ),
					'text'          => $r[0],
					'selected_icon' => array(
						'value'   => isset( $r[2] ) ? $r[2] : '',
						'library' => isset( $r[2] ) ? 'fa-solid' : '',
					),
					'link'          => array(
						'url'               => $r[1],
						'is_external'       => '',
						'nofollow'          => '',
						'custom_attributes' => '',
					),
				);
			}
			return $out;
		};
		$d           = 'https://' . self::DOMAIN;
		$list        = function ( array $rows ) use ( $items ) {
			return $this->w(
				'icon-list',
				array(
					'icon_list'   => $items( $rows ),
					'__globals__' => array(
						'text_color'                 => 'globals/colors?id=14caab8',
						'icon_color'                 => 'globals/colors?id=d49ac81',
						'icon_typography_typography' => 'globals/typography?id=112b6c4',
					),
				)
			);
		};
		unset( $link );
		return array(
			$this->section_box(
				'638d055',
				array(
					$this->row(
						array(
							$this->col(
								array(
									$this->h( '{{brand_name}}', 'h4', true, 'left' ),
									$this->p( '<p>Dummy Source Distribution creates stronger connections between businesses and market opportunities through efficient distribution.</p>', true, 'left' ),
								),
								30
							),
							$this->col(
								array(
									$this->h( 'Quick Links', 'h5', true, 'left' ),
									$list(
										array(
											array( 'About Us', $d . '/about-us/' ),
											array( 'Products', $d . '/products/' ),
											array( 'Brands', $d . '/brands/' ),
											array( 'FAQs', $d . '/faqs/' ),
											array( 'Contact Us', $d . '/contact-us/' ),
										)
									),
								),
								30
							),
							$this->col(
								array(
									$this->h( 'Contact Information', 'h5', true, 'left' ),
									$list(
										array(
											array( '+1 917-555-0100', 'tel:+19175550100', 'fas fa-phone' ),
											array( 'info@' . self::DOMAIN, 'mailto:info@' . self::DOMAIN, 'fas fa-envelope' ),
											array( '{{address}}', '#', 'fas fa-map-marker-alt' ),
										)
									),
								),
								30
							),
						)
					),
					$this->w(
						'heading',
						array(
							'title'       => 'Copyright© 2024 Dummy Source Distribution, All rights reserved. Powered by MoxCreative.',
							'header_size' => 'div',
							'align'       => 'center',
							'__globals__' => array(
								'title_color'           => 'globals/colors?id=14caab8',
								'typography_typography' => 'globals/typography?id=69c152f',
							),
						)
					),
				),
				array( 'padding' => $this->pad( 60, 20 ) )
			),
		);
	}

	/* ------------------------------------------------------------------ */
	/* Components                                                          */
	/* ------------------------------------------------------------------ */

	private function section( $slot, $c ) {
		$dark = 2 === $c;
		$bg   = array( 1 => 'cfa1f76', 2 => '044b931', 3 => '7fbea4f' );
		$bg   = $bg[ ( ( $c - 1 ) % 3 ) + 1 ];
		$d    = 'https://' . self::DOMAIN;

		$topic = $this->topic( $slot );
		$body  = array( $this->tag( $dark ), $this->h( $topic[0], 'h2', $dark ), $this->p( '<p>' . $topic[1] . '</p>', $dark ) );

		switch ( $topic[2] ) {
			case 'cards':
				$body[] = $this->cards(
					array(
						array( 'truck', 'Fast Delivery', 'Orders leave our warehouse within 48 hours.' ),
						array( 'tags', 'Fair Pricing', 'Wholesale rates for every order size.' ),
						array( 'handshake', 'Trusted Partners', 'Brands that retailers already know.' ),
					),
					$dark
				);
				break;
			case 'categories':
				$body[] = $this->w(
					'wc-categories',
					array(
						'columns' => '4',
						'number'  => 8,
						'source'  => 'by_id',
						'categories' => array( '15', '16' ),
					)
				);
				break;
			case 'products':
				if ( 2 === $c ) {
					$body[] = $this->w(
						'loop-grid',
						array(
							'_skin'       => 'product',
							'template_id' => '4242',
							'columns'     => 4,
						)
					);
				} else {
					$body[] = $this->w(
						'woocommerce-products',
						array(
							'columns'        => '4',
							'rows'           => 2,
							'paginate'       => '',
							'query_post_type' => 'product',
							'query_posts_ids' => array( '311', '312' ),
						)
					);
				}
				break;
			case 'faq':
				$body[] = $this->w(
					'accordion',
					array(
						'tabs' => array(
							array(
								'_id'         => 'a1b2c31',
								'tab_title'   => 'What is the minimum order?',
								'tab_content' => '<p>There is no minimum for first orders with {{brand_name}}.</p>',
							),
							array(
								'_id'         => 'a1b2c32',
								'tab_title'   => 'How fast do you ship?',
								'tab_content' => '<p>Most orders ship within 48 hours.</p>',
							),
							array(
								'_id'         => 'a1b2c33',
								'tab_title'   => 'How do I become a partner?',
								'tab_content' => '<p>Email info@' . self::DOMAIN . ' or call +1 917-555-0100.</p>',
							),
						),
					)
				);
				break;
			case 'contact':
				$body[] = $this->row(
					array(
						$this->col(
							array(
								$this->h( 'Talk to Us', 'h3', $dark, 'left' ),
								$this->p( '<p>Phone: +1 917-555-0100<br>Email: info@' . self::DOMAIN . '<br>Address: {{address}}</p>', $dark, 'left' ),
							),
							40
						),
						$this->col(
							array(
								$this->w(
									'form',
									array(
										'form_name'      => 'Contact',
										'form_fields'    => array(
											array(
												'_id'         => 'name',
												'custom_id'   => 'name',
												'field_type'  => 'text',
												'field_label' => 'Name',
												'placeholder' => 'Your name',
												'required'    => 'true',
											),
											array(
												'_id'         => 'email',
												'custom_id'   => 'email',
												'field_type'  => 'email',
												'field_label' => 'Email',
												'placeholder' => 'you@company.com',
												'required'    => 'true',
											),
											array(
												'_id'         => 'message',
												'custom_id'   => 'message',
												'field_type'  => 'textarea',
												'field_label' => 'Message',
												'placeholder' => 'How can we help?',
											),
										),
										'button_text'    => 'Send Message',
										'email_to'       => 'info@' . self::DOMAIN,
										'submit_actions' => array( 'email' ),
										'email_subject'  => 'New message from {{brand_name}} website',
									)
								),
							),
							55
						),
					)
				);
				break;
			case 'brands':
				$names = array();
				foreach ( array( 'Northwind', 'Contoso', 'Fabrikam', 'Tailspin' ) as $b ) {
					$names[] = $this->col( array( $this->h( $b, 'h4', $dark ) ), 20 );
				}
				$body[] = $this->row( $names );
				break;
			case 'split':
			default:
				$body = array(
					$this->row(
						array(
							$this->col( array( $this->img( 3 === $c ? 'card2' : 'about' ) ), 45 ),
							$this->col(
								array(
									$this->tag( $dark ),
									$this->h( $topic[0], 'h2', $dark, 'left' ),
									$this->p( '<p>' . $topic[1] . '</p>', $dark, 'left' ),
									$this->btn( 'Learn More', $d . '/about-us/', 'left' ),
								),
								50
							),
						),
						40
					),
				);
		}

		if ( 3 === $c && 'split' !== $topic[2] ) {
			array_unshift( $body, $this->img( 'card1' ) );
		}
		return array( $this->section_box( $bg, $body ) );
	}

	private function topic( $slot ) {
		$map = array(
			'home/section_2'  => array( 'About Dummy Source Distribution', 'We help retailers source the right products at the right price.', 'split' ),
			'home/section_3'  => array( 'Shop by Category', 'Browse the product families we carry.', 'categories' ),
			'home/section_4'  => array( 'Why Businesses Choose Us', 'Three reasons partners stay with {{brand_name}}.', 'cards' ),
			'home/section_5'  => array( 'Featured Products', 'Popular items this month.', 'products' ),
			'home/section_6'  => array( 'Our Process', 'From first call to delivery in four steps.', 'cards' ),
			'home/section_7'  => array( 'Brands We Carry', 'Trusted names our customers ask for.', 'brands' ),
			'home/section_8'  => array( 'Built for Growth', 'Flexible supply that grows with your store.', 'split' ),
			'home/section_9'  => array( 'What Our Partners Say', 'Retailers on working with us.', 'cards' ),
			'home/section_10' => array( 'Frequently Asked Questions', 'Quick answers before you get in touch.', 'faq' ),
			'about/section_2' => array( 'Who We Are', 'A distribution partner focused on reliability.', 'split' ),
			'about/section_3' => array( 'Our Mission', 'Make wholesale simple and fair.', 'cards' ),
			'about/section_4' => array( 'Our Values', 'What guides every order we ship.', 'cards' ),
			'about/section_5' => array( 'Our Story', 'How Dummy Source Distribution started.', 'split' ),
			'about/section_6' => array( 'Partners', 'Brands we work with every day.', 'brands' ),
			'brands'          => array( 'Our Brands', 'The brands we distribute.', 'brands' ),
			'category'        => array( 'Product Category', 'Products in this category.', 'products' ),
			'category_card'   => array( 'All Product Categories', 'Find what your store needs.', 'categories' ),
			'faq'             => array( 'Questions & Answers', 'Everything about ordering from {{brand_name}}.', 'faq' ),
			'contact'         => array( 'Get in Touch', 'We reply within one business day.', 'contact' ),
			'products'        => array( 'Our Products', 'The full catalog.', 'products' ),
		);
		return isset( $map[ $slot ] ) ? $map[ $slot ] : array( ucfirst( $slot ), 'Dummy section.', 'cards' );
	}

	private function loop_item( $c ) {
		$bg = array( 1 => 'text', 2 => 'cfa1f76', 3 => '7fbea4f' );
		return array(
			$this->box(
				array(
					'content_width'         => 'full',
					'flex_direction'        => 'column',
					'flex_gap'              => array(
						'unit'   => 'px',
						'size'   => 10,
						'column' => '10',
						'row'    => '10',
					),
					'padding'               => $this->pad( 16 ),
					'background_background' => 'classic',
					'border_radius'         => array(
						'unit'     => 'px',
						'top'      => '10',
						'right'    => '10',
						'bottom'   => '10',
						'left'     => '10',
						'isLinked' => true,
					),
					'__globals__'           => array( 'background_color' => 'globals/colors?id=' . $bg[ $c > 3 ? 1 : $c ] ),
				),
				array(
					$this->tag( false ),
					$this->w( 'theme-post-featured-image', array() ),
					$this->w( 'woocommerce-product-title', array( 'header_size' => 'h4' ) ),
					$this->w( 'woocommerce-product-price', array() ),
					$this->w( 'woocommerce-product-add-to-cart', array() ),
				)
			),
		);
	}

	private function single( $c ) {
		$bg = 2 === $c ? 'cfa1f76' : '7fbea4f';
		return array(
			$this->section_box(
				$bg,
				array(
					$this->tag( false ),
					$this->row(
						array(
							$this->col( array( $this->w( 'woocommerce-product-images', array() ) ), 48 ),
							$this->col(
								array(
									$this->w( 'woocommerce-product-title', array( 'header_size' => 'h2' ) ),
									$this->w( 'woocommerce-product-price', array() ),
									$this->w( 'woocommerce-product-short-description', array() ),
									$this->w( 'woocommerce-product-add-to-cart', array() ),
								),
								48
							),
						)
					),
				)
			),
			$this->section_box(
				'text',
				array(
					$this->w( 'woocommerce-product-data-tabs', array() ),
					$this->w( 'woocommerce-product-related', array() ),
				)
			),
		);
	}
}
