<?php
/**
 * WP-CLI commands. Same planner and step runner as the Build screen.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build distribution sites from the section library.
 */
class DistB_CLI {

	/**
	 * Run the preflight checks.
	 *
	 * ## EXAMPLES
	 *     wp distb check
	 *
	 * @param array $args  Args.
	 * @param array $assoc Assoc args.
	 */
	public function check( $args, $assoc ) {
		$this->as_admin( $assoc );
		$res = ( new DistB_Preflight( distb_library(), distb_recipes() ) )->run();
		foreach ( $res['checks'] as $c ) {
			$line = str_pad( strtoupper( $c['status'] ), 6 ) . $c['label'] . ( $c['help'] ? '  — ' . $c['help'] : '' );
			if ( 'fail' === $c['status'] ) {
				WP_CLI::line( WP_CLI::colorize( '%R' . $line . '%n' ) );
			} elseif ( 'warn' === $c['status'] ) {
				WP_CLI::line( WP_CLI::colorize( '%Y' . $line . '%n' ) );
			} else {
				WP_CLI::line( $line );
			}
		}
		$res['ok'] ? WP_CLI::success( 'Ready to build.' ) : WP_CLI::error( 'Fix the FAIL items first.' );
	}

	/**
	 * Print a build plan (all picks) without writing anything.
	 *
	 * ## OPTIONS
	 * [--seed=<seed>]
	 * : Seed. Empty = random.
	 * [--kit=<n>]
	 * : Force global_kits/site_<n>.
	 * [--exclude=<list>]
	 * : Kit numbers to skip, comma separated.
	 * [--variety]
	 * : No two sections on one page from the same source site.
	 * [--brand=<name>]
	 * : Brand name (for the track header).
	 *
	 * ## EXAMPLES
	 *     wp distb plan --seed=83920144
	 *
	 * @param array $args  Args.
	 * @param array $assoc Assoc args.
	 */
	public function plan( $args, $assoc ) {
		$this->as_admin( $assoc );
		$planner = new DistB_Planner( distb_library(), distb_recipes() );
		try {
			$seed = ! empty( $assoc['seed'] ) ? DistB_Randomizer::clean_seed( $assoc['seed'] ) : DistB_Randomizer::new_seed();
			$plan = $planner->plan(
				$seed,
				array(
					'site'         => DistB_Plugin::site_details( array( 'brand' => isset( $assoc['brand'] ) ? $assoc['brand'] : 'plan preview' ) ),
					'force_kit'    => isset( $assoc['kit'] ) ? (int) $assoc['kit'] : 0,
					'exclude_kits' => isset( $assoc['exclude'] ) ? array_filter( array_map( 'absint', explode( ',', $assoc['exclude'] ) ) ) : array(),
					'variety'      => isset( $assoc['variety'] ),
				)
			);
			$checker          = class_exists( '\Elementor\Plugin' ) ? array( 'DistB_Elementor', 'unknown_widgets' ) : null;
			$v                = $planner->validate( $plan, $checker );
			$plan['warnings'] = $v['warnings'];
			WP_CLI::line( DistB_Track::text( $plan ) );
			foreach ( $v['errors'] as $e ) {
				WP_CLI::warning( $e );
			}
			$v['errors'] ? WP_CLI::error( 'This plan cannot be built.' ) : WP_CLI::success( 'Plan is valid. Nothing was written.' );
		} catch ( DistB_Exception $e ) {
			WP_CLI::error( $e->getMessage() );
		}
	}

	/**
	 * Build the site: plan, then run every step.
	 *
	 * ## OPTIONS
	 * --brand=<name>
	 * : Brand name of the new site.
	 * [--email=<email>]
	 * [--phone=<phone>]
	 * [--address=<address>]
	 * [--logo=<id-or-file>]
	 * : Attachment ID, or a local image file to upload as the logo.
	 * [--seed=<seed>]
	 * [--kit=<n>]
	 * [--exclude=<list>]
	 * [--variety]
	 * [--media=<mode>]
	 * : auto | pack | download | off
	 * ---
	 * default: auto
	 * ---
	 * [--from-track=<file>]
	 * : Replay the exact picks of a track-*.json file.
	 * [--keep-previous]
	 * : Do not remove the previous build first (stops if one exists).
	 * [--yes]
	 * : Do not ask for confirmation.
	 *
	 * ## EXAMPLES
	 *     wp distb build --brand="New Brand Distribution" --email=info@newbrand.com --phone="+1 555 010 0100" --yes
	 *     wp distb build --brand="New Brand" --seed=83920144 --kit=3 --yes
	 *     wp distb build --brand="New Brand" --from-track=track-db-20261008-143205-ab12.json --yes
	 *
	 * @param array $args  Args.
	 * @param array $assoc Assoc args.
	 */
	public function build( $args, $assoc ) {
		$this->as_admin( $assoc );
		$in = array(
			'brand'            => isset( $assoc['brand'] ) ? $assoc['brand'] : '',
			'email'            => isset( $assoc['email'] ) ? $assoc['email'] : '',
			'phone'            => isset( $assoc['phone'] ) ? $assoc['phone'] : '',
			'address'          => isset( $assoc['address'] ) ? $assoc['address'] : '',
			'logo_id'          => isset( $assoc['logo'] ) ? $this->logo( $assoc['logo'] ) : 0,
			'seed'             => isset( $assoc['seed'] ) ? $assoc['seed'] : '',
			'force_kit'        => isset( $assoc['kit'] ) ? (int) $assoc['kit'] : 0,
			'exclude_kits'     => isset( $assoc['exclude'] ) ? $assoc['exclude'] : '',
			'variety'          => isset( $assoc['variety'] ),
			'media'            => isset( $assoc['media'] ) ? $assoc['media'] : 'auto',
			'replace_previous' => ! isset( $assoc['keep-previous'] ),
		);
		if ( ! empty( $assoc['from-track'] ) ) {
			if ( ! is_file( $assoc['from-track'] ) ) {
				WP_CLI::error( 'Track file not found: ' . $assoc['from-track'] );
			}
			$in['track'] = json_decode( (string) file_get_contents( $assoc['from-track'] ), true ); // phpcs:ignore
		}

		try {
			$plan = DistB_Plugin::make_plan( $in );
		} catch ( DistB_Exception $e ) {
			if ( ! empty( $e->context['errors'] ) ) {
				foreach ( $e->context['errors'] as $err ) {
					WP_CLI::warning( $err );
				}
			}
			WP_CLI::error( $e->getMessage() );
			return;
		}
		WP_CLI::line( DistB_Track::text( $plan ) );
		foreach ( $plan['warnings'] as $w ) {
			WP_CLI::warning( $w );
		}
		WP_CLI::confirm( 'Build this site now?', $assoc );

		try {
			$res = DistB_Plugin::start_pending( $plan['build_id'] );
			$this->print_step( $res );
			$runner = new DistB_Runner( distb_library() );
			$guard  = 0;
			while ( ! $res['done'] && ! $res['failed'] && $guard++ < 500 ) {
				$runner = new DistB_Runner( distb_library() );
				$res    = $runner->run_next();
				$this->print_step( $res );
			}
			$runner = new DistB_Runner( distb_library() );
			WP_CLI::line( '' );
			WP_CLI::line( DistB_Track::text( $runner->plan(), $runner->state() ) );
			if ( $res['failed'] ) {
				WP_CLI::error( 'Build stopped at a failed step. Fix it, then run: wp distb resume --retry' );
			}
			WP_CLI::success( 'Site built. Track: ' . DistB_Track::dir() . 'track-' . $plan['build_id'] . '.txt' );
		} catch ( DistB_Exception $e ) {
			WP_CLI::error( $e->getMessage() );
		}
	}

	/**
	 * Continue a build that stopped (optionally retrying the failed step).
	 *
	 * ## OPTIONS
	 * [--retry]
	 * : Retry the failed step.
	 *
	 * @param array $args  Args.
	 * @param array $assoc Assoc args.
	 */
	public function resume( $args, $assoc ) {
		$this->as_admin( $assoc );
		$retry = isset( $assoc['retry'] );
		try {
			$guard = 0;
			do {
				$runner = new DistB_Runner( distb_library() );
				$res    = $runner->run_next( $retry );
				$retry  = false;
				$this->print_step( $res );
			} while ( ! $res['done'] && ! $res['failed'] && $guard++ < 500 );
			$runner = new DistB_Runner( distb_library() );
			WP_CLI::line( DistB_Track::text( $runner->plan(), $runner->state() ) );
			$res['failed'] ? WP_CLI::error( 'Stopped at a failed step.' ) : WP_CLI::success( 'Build finished.' );
		} catch ( DistB_Exception $e ) {
			WP_CLI::error( $e->getMessage() );
		}
	}

	/**
	 * Remove the last build (or a given one) and restore what it changed.
	 *
	 * ## OPTIONS
	 * [--build=<id>]
	 * : Build ID. Default: the last build.
	 * [--keep-media]
	 * : Keep imported images.
	 * [--yes]
	 *
	 * @param array $args  Args.
	 * @param array $assoc Assoc args.
	 */
	public function reset( $args, $assoc ) {
		$this->as_admin( $assoc );
		$runner = new DistB_Runner( distb_library() );
		$state  = $runner->state();
		$id     = isset( $assoc['build'] ) ? $assoc['build'] : ( isset( $state['build_id'] ) ? $state['build_id'] : '' );
		if ( ! $id ) {
			WP_CLI::error( 'No build to reset.' );
		}
		WP_CLI::confirm( 'Remove build ' . $id . ' from this site?', $assoc );
		if ( $runner->is_running() ) {
			$runner->cancel();
		}
		$res = ( new DistB_Cleaner() )->reset( $id, isset( $assoc['keep-media'] ) );
		WP_CLI::success( $res['summary'] );
	}

	/**
	 * Print the track of the last build (or a given one).
	 *
	 * ## OPTIONS
	 * [--build=<id>]
	 * [--json]
	 *
	 * @param array $args  Args.
	 * @param array $assoc Assoc args.
	 */
	public function track( $args, $assoc ) {
		$runner = new DistB_Runner( distb_library() );
		$id     = isset( $assoc['build'] ) ? $assoc['build'] : ( $runner->plan() ? $runner->plan()['build_id'] : '' );
		$track  = get_option( 'distb_track_' . $id, array() );
		if ( ! $track && $runner->plan() && $runner->plan()['build_id'] === $id ) {
			$track = DistB_Track::build( $runner->plan(), $runner->state() );
		}
		if ( ! $track ) {
			WP_CLI::error( 'No track for ' . $id );
		}
		WP_CLI::line( isset( $assoc['json'] ) ? wp_json_encode( $track, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) : $track['text'] );
	}

	/**
	 * Library tools.
	 *
	 * ## OPTIONS
	 * <action>
	 * : validate | index | dummy | split | extract | media-pack
	 * [--kits=<n>]
	 * : dummy: number of kits. Default 4.
	 * [--per-slot=<n>]
	 * : dummy: components per slot. Default 3.
	 * [--page=<key>]
	 * : split: home | about-us | brands | product-categories | faqs | contact-us | products
	 * [--file=<json>]
	 * : split: page data from "wp post meta get <id> _elementor_data".
	 * [--site=<n>]
	 * : split/extract: number of the source site (site_N, comp_N).
	 * [--siteurl=<url>]
	 * : split: source site URL (for link and brand replacement).
	 * [--out=<dir>]
	 * : split/extract: library folder to write to. Default: this plugin's library.
	 * [--pages=<map>]
	 * : extract: page IDs when slugs differ, e.g. about-us=12,faqs=40
	 * [--force]
	 * : Overwrite existing files.
	 * [--yes]
	 *
	 * ## EXAMPLES
	 *     wp distb library validate
	 *     wp distb library dummy --kits=4 --per-slot=3 --yes
	 *     wp distb library extract --site=3 --out=/tmp/lib
	 *     wp distb library split --page=home --file=home.json --site=3 --siteurl=https://treasuresdistribution.com
	 *     wp distb library media-pack
	 *
	 * @param array $args  Args.
	 * @param array $assoc Assoc args.
	 */
	public function library( $args, $assoc ) {
		$action = isset( $args[0] ) ? $args[0] : '';
		$lib    = distb_library();
		$out    = isset( $assoc['out'] ) ? $assoc['out'] : $lib->root();

		try {
			if ( 'validate' === $action ) {
				$this->as_admin( $assoc );
				$checker = class_exists( '\Elementor\Plugin' ) ? array( 'DistB_Elementor', 'unknown_widgets' ) : null;
				$v       = DistB_Extractor::validate_library( $lib, distb_recipes(), $checker );
				foreach ( $v['warnings'] as $w ) {
					WP_CLI::warning( $w );
				}
				foreach ( $v['duplicates'] as $d ) {
					WP_CLI::line( 'DUPLICATE ' . $d[0] . ' = ' . $d[1] );
				}
				WP_CLI::line( 'Widgets: ' . implode( ', ', array_map( function ( $k, $n ) { return $k . ' ' . $n; }, array_keys( $v['widgets'] ), $v['widgets'] ) ) );
				foreach ( $v['errors'] as $e ) {
					WP_CLI::line( WP_CLI::colorize( '%RERROR%n ' . $e ) );
				}
				$v['ok'] ? WP_CLI::success( $v['files'] . ' files OK.' ) : WP_CLI::error( count( $v['errors'] ) . ' error(s) in ' . $v['files'] . ' files.' );
			} elseif ( 'index' === $action ) {
				$s = $lib->check_structure( distb_recipes() );
				$index = array(
					'generated' => gmdate( 'c' ),
					'checksum'  => $lib->checksum(),
					'counts'    => $s['counts'],
				);
				distb_write_json( $lib->root() . 'registry/library-index.json', $index );
				foreach ( $s['counts'] as $k => $n ) {
					WP_CLI::line( str_pad( $k, 34 ) . $n );
				}
				WP_CLI::success( 'Wrote registry/library-index.json (checksum ' . $index['checksum'] . ').' );
			} elseif ( 'dummy' === $action ) {
				WP_CLI::confirm( 'Write a dummy library into ' . $out . '? Files with the same names are overwritten.', $assoc );
				$n = ( new DistB_Dummy() )->generate( $out, isset( $assoc['kits'] ) ? (int) $assoc['kits'] : 4, isset( $assoc['per-slot'] ) ? (int) $assoc['per-slot'] : 3 );
				WP_CLI::success( $n . ' dummy files written.' );
			} elseif ( 'split' === $action ) {
				foreach ( array( 'page', 'file', 'site' ) as $req ) {
					if ( empty( $assoc[ $req ] ) ) {
						WP_CLI::error( '--' . $req . ' is required.' );
					}
				}
				$doc    = DistB_Transformer::load( $assoc['file'] );
				$res    = array(
					'written'  => array(),
					'warnings' => array(),
				);
				$banner = is_file( rtrim( $out, '/' ) . '/global_kits/site_' . (int) $assoc['site'] . '/page_banner.json' ) && empty( $assoc['force'] );
				$cta    = is_file( rtrim( $out, '/' ) . '/global_kits/site_' . (int) $assoc['site'] . '/cta.json' ) && empty( $assoc['force'] );
				$url    = isset( $assoc['siteurl'] ) ? rtrim( $assoc['siteurl'], '/' ) . '/wp-json/' : '';
				DistB_Extractor::split_page( $assoc['page'], $doc['elements'], (int) $assoc['site'], rtrim( $out, '/' ) . '/', $url, ! empty( $assoc['force'] ), $res, $banner, $cta );
				$this->report( $res );
			} elseif ( 'extract' === $action ) {
				$this->as_admin( $assoc );
				if ( empty( $assoc['site'] ) ) {
					WP_CLI::error( '--site=<n> is required (the number this source site gets in the library).' );
				}
				$pages = array();
				if ( ! empty( $assoc['pages'] ) ) {
					foreach ( explode( ',', $assoc['pages'] ) as $pair ) {
						$kv = explode( '=', $pair );
						if ( 2 === count( $kv ) ) {
							$pages[ trim( $kv[0] ) ] = (int) $kv[1];
						}
					}
				}
				$res = DistB_Extractor::extract(
					(int) $assoc['site'],
					$out,
					array(
						'force' => ! empty( $assoc['force'] ),
						'pages' => $pages,
					)
				);
				$this->report( $res );
				WP_CLI::line( 'Registry entry (merged into registry/sources.json; add email and phone):' );
				WP_CLI::line( wp_json_encode( $res['registry'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
			} elseif ( 'media-pack' === $action ) {
				$res = DistB_Extractor::media_pack(
					$lib,
					function ( $line ) {
						WP_CLI::line( $line );
					}
				);
				WP_CLI::success( $res['total'] . ' image URLs, ' . $res['new'] . ' downloaded now, ' . count( $res['failed'] ) . ' failed.' );
			} else {
				WP_CLI::error( 'Unknown action. Use: validate | index | dummy | split | extract | media-pack' );
			}
		} catch ( DistB_Exception $e ) {
			WP_CLI::error( $e->getMessage() . ( ! empty( $e->context['file'] ) ? ' [' . $e->context['file'] . ']' : '' ) );
		}
	}

	/**
	 * Plan a batch: one seed and a different kit for every site.
	 *
	 * ## OPTIONS
	 * --count=<n>
	 * : Number of sites.
	 * [--seed=<n>]
	 * : Batch seed (same seed = same batch).
	 * [--out=<file.csv>]
	 * : Write CSV here. Default: print.
	 *
	 * ## EXAMPLES
	 *     wp distb batch-plan --count=40 --out=batch-2026-10-09.csv
	 *
	 * @subcommand batch-plan
	 * @param array $args  Args.
	 * @param array $assoc Assoc args.
	 */
	public function batch_plan( $args, $assoc ) {
		try {
			$res = DistB_Extractor::batch_plan( distb_library(), max( 1, (int) $assoc['count'] ), isset( $assoc['seed'] ) ? (int) $assoc['seed'] : 0 );
		} catch ( DistB_Exception $e ) {
			WP_CLI::error( $e->getMessage() );
			return;
		}
		$lines = array( 'row,seed,kit,domain,brand,email,phone,address' );
		foreach ( $res['rows'] as $r ) {
			$lines[] = implode( ',', $r );
		}
		$csv = implode( "\n", $lines ) . "\n";
		if ( ! empty( $assoc['out'] ) ) {
			file_put_contents( $assoc['out'], $csv ); // phpcs:ignore
			WP_CLI::success( 'Batch seed ' . $res['batch_seed'] . ' → ' . $assoc['out'] );
		} else {
			WP_CLI::line( $csv );
			WP_CLI::line( 'Batch seed ' . $res['batch_seed'] );
		}
		if ( $res['repeats'] ) {
			WP_CLI::warning( 'More sites than kits: some kits are used twice.' );
		}
		WP_CLI::line( 'Per site: wp distb build --brand="<brand>" --email=<email> --phone="<phone>" --seed=<seed> --kit=<kit> --yes' );
	}

	/* ------------------------------------------------------------------ */

	private function print_step( array $res ) {
		if ( ! $res['step'] ) {
			return;
		}
		$s    = $res['steps'][ $res['step'] ];
		$line = str_pad( $res['progress'] . '%', 5 ) . str_pad( strtoupper( $s['status'] ), 8 ) . $s['label'] . ( $s['note'] ? ' — ' . $s['note'] : '' ) . ( $s['error'] ? ' — ' . $s['error'] : '' );
		'failed' === $s['status'] ? WP_CLI::line( WP_CLI::colorize( '%R' . $line . '%n' ) ) : WP_CLI::line( $line );
	}

	private function report( array $res ) {
		foreach ( $res['written'] as $f ) {
			WP_CLI::line( 'wrote ' . $f );
		}
		foreach ( $res['warnings'] as $w ) {
			WP_CLI::warning( $w );
		}
		WP_CLI::success( count( $res['written'] ) . ' file(s) written.' );
	}

	private function logo( $value ) {
		if ( is_numeric( $value ) ) {
			return (int) $value;
		}
		if ( ! is_file( $value ) ) {
			WP_CLI::error( 'Logo file not found: ' . $value );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$tmp = wp_tempnam( basename( $value ) );
		copy( $value, $tmp );
		$id = media_handle_sideload(
			array(
				'name'     => basename( $value ),
				'tmp_name' => $tmp,
			),
			0
		);
		if ( is_wp_error( $id ) ) {
			WP_CLI::error( 'Logo upload failed: ' . $id->get_error_message() );
		}
		return (int) $id;
	}

	/**
	 * Elementor saves documents only for a user who can edit them. Run as the first administrator
	 * unless --user was given.
	 *
	 * @param array $assoc Assoc args.
	 */
	private function as_admin( $assoc ) {
		unset( $assoc );
		if ( get_current_user_id() ) {
			return;
		}
		$admins = get_users(
			array(
				'role'   => 'administrator',
				'number' => 1,
				'fields' => 'ID',
			)
		);
		if ( $admins ) {
			wp_set_current_user( (int) $admins[0] );
		}
	}
}
