<?php
/**
 * Seeded picker. The same seed and the same library always give the same picks,
 * so any build can be replayed for debugging.
 *
 * A pick is always made from the list of files that exist, so it can never be
 * above the file count: 20 files → a number from 1 to 20.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'DISTB_TESTING' ) ) {
	exit;
}

class DistB_Randomizer {

	const MAX_SEED = 2147483647;

	/** @var int */
	private $seed;

	public function __construct( $seed ) {
		$this->seed = self::clean_seed( $seed );
	}

	public function seed() {
		return $this->seed;
	}

	/**
	 * A new random seed from a cryptographically secure source.
	 *
	 * @return int
	 */
	public static function new_seed() {
		return random_int( 1, self::MAX_SEED );
	}

	/**
	 * @param mixed $seed Seed input.
	 * @return int
	 * @throws DistB_Exception On an invalid seed.
	 */
	public static function clean_seed( $seed ) {
		if ( ! is_numeric( $seed ) || (int) $seed < 1 || (int) $seed > self::MAX_SEED || (string) (int) $seed !== trim( (string) $seed ) ) {
			throw new DistB_Exception( 'Seed must be a whole number from 1 to ' . self::MAX_SEED . '.' );
		}
		return (int) $seed;
	}

	/**
	 * Pick one item for a slot.
	 *
	 * @param string $slot_key Slot identity, such as "global_kits" or "home/section_4". Each slot gets its own pick.
	 * @param array  $items    Items in natural order (as returned by DistB_Library).
	 * @param int    $attempt  Re-pick number (0 = first pick). Used by the variety rule.
	 * @return array{index:int,of:int,item:string}  index is 1-based.
	 * @throws DistB_Exception When there is nothing to pick from.
	 */
	public function pick( $slot_key, array $items, $attempt = 0 ) {
		$items = array_values( $items );
		$n     = count( $items );
		if ( 0 === $n ) {
			throw new DistB_Exception( 'Nothing to pick from: ' . $slot_key . ' is empty.', array( 'slot' => $slot_key ) );
		}
		$index = $this->number( $slot_key . ( $attempt ? '#' . $attempt : '' ), $n );
		return array(
			'index' => $index + 1,
			'of'    => $n,
			'item'  => $items[ $index ],
		);
	}

	/**
	 * Deterministic number 0 .. n-1 for a key. Uses 48 bits of SHA-256, so the bias is negligible.
	 *
	 * @param string $key Key.
	 * @param int    $n   Upper bound (exclusive).
	 * @return int
	 */
	public function number( $key, $n ) {
		$hash = hash( 'sha256', $this->seed . '|' . $key );
		$big  = hexdec( substr( $hash, 0, 12 ) );
		return (int) fmod( $big, $n );
	}

	/**
	 * Deterministic shuffle (used by the batch planner to give 40 sites 40 different kits).
	 *
	 * @param array  $items Items.
	 * @param string $key   Key.
	 * @return array
	 */
	public function shuffle( array $items, $key ) {
		$items = array_values( $items );
		for ( $i = count( $items ) - 1; $i > 0; $i-- ) {
			$j           = $this->number( $key . '|' . $i, $i + 1 );
			$tmp         = $items[ $i ];
			$items[ $i ] = $items[ $j ];
			$items[ $j ] = $tmp;
		}
		return $items;
	}
}
