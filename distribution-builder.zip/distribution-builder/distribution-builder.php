<?php
/**
 * Plugin Name:       Distribution Builder
 * Description:       Builds a complete Elementor distribution site in one click: one random global kit (settings, header, footer, banners, CTA) plus random sections from the component library, in fixed order, with a full build track.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Shahmir
 * License:           GPL-2.0-or-later
 * Text Domain:       distribution-builder
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DISTB_VERSION', '1.0.0' );
define( 'DISTB_FILE', __FILE__ );
define( 'DISTB_PATH', plugin_dir_path( __FILE__ ) );
define( 'DISTB_URL', plugin_dir_url( __FILE__ ) );

require_once DISTB_PATH . 'includes/functions.php';
require_once DISTB_PATH . 'includes/class-distb-library.php';
require_once DISTB_PATH . 'includes/class-distb-randomizer.php';
require_once DISTB_PATH . 'includes/class-distb-planner.php';
require_once DISTB_PATH . 'includes/class-distb-transformer.php';
require_once DISTB_PATH . 'includes/class-distb-track.php';
require_once DISTB_PATH . 'includes/class-distb-elementor.php';
require_once DISTB_PATH . 'includes/class-distb-media.php';
require_once DISTB_PATH . 'includes/class-distb-runner.php';
require_once DISTB_PATH . 'includes/class-distb-cleaner.php';
require_once DISTB_PATH . 'includes/class-distb-preflight.php';
require_once DISTB_PATH . 'includes/class-distb-dummy.php';
require_once DISTB_PATH . 'includes/class-distb-extractor.php';
require_once DISTB_PATH . 'includes/class-distb-plugin.php';
require_once DISTB_PATH . 'includes/class-distb-rest.php';
require_once DISTB_PATH . 'includes/class-distb-admin.php';
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once DISTB_PATH . 'includes/class-distb-cli.php';
}

add_action( 'plugins_loaded', array( 'DistB_Plugin', 'boot' ) );
