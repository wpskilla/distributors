<?php
/**
 * Uninstall: removes the plugin's own options only. Pages, templates, menus and media
 * made by builds stay (they are the site). Use Reset before uninstalling to remove a build.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;
$distb_like = $wpdb->esc_like( 'distb_' ) . '%';
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $distb_like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
