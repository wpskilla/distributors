<?php
/**
 * Build screen markup. Behaviour lives in admin/assets/builder.js.
 *
 * @package DistributionBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$distb_lib = distb_library();
?>
<div class="wrap distb">
	<h1>Distribution Builder <span class="distb-ver">v<?php echo esc_html( DISTB_VERSION ); ?></span></h1>
	<p class="distb-sub">One random global kit + random sections from the library, in fixed order, with a full build track.</p>

	<nav class="nav-tab-wrapper distb-tabs">
		<a href="#build" class="nav-tab nav-tab-active" data-tab="build">Build</a>
		<a href="#library" class="nav-tab" data-tab="library">Library</a>
		<a href="#history" class="nav-tab" data-tab="history">History</a>
		<a href="#reset" class="nav-tab" data-tab="reset">Reset</a>
	</nav>

	<!-- BUILD -->
	<section class="distb-panel" data-panel="build">
		<div class="distb-grid">
			<div class="distb-card">
				<h2>1. Site details</h2>
				<table class="form-table distb-form" role="presentation">
					<tr><th><label for="distb-brand">Brand name <span class="req">*</span></label></th>
						<td><input id="distb-brand" type="text" class="regular-text" placeholder="New Brand Distribution" value="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"></td></tr>
					<tr><th><label for="distb-email">Email</label></th>
						<td><input id="distb-email" type="email" class="regular-text" placeholder="info@<?php echo esc_attr( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?>"></td></tr>
					<tr><th><label for="distb-phone">Phone</label></th>
						<td><input id="distb-phone" type="text" class="regular-text" placeholder="+1 555 010 0100"></td></tr>
					<tr><th><label for="distb-address">Address</label></th>
						<td><input id="distb-address" type="text" class="regular-text" placeholder="123 Main St, City, ST 00000"></td></tr>
					<tr><th>Logo</th>
						<td><input id="distb-logo" type="hidden" value="0"><button type="button" class="button" id="distb-logo-btn">Choose logo</button>
							<span id="distb-logo-preview" class="distb-logo-preview"></span></td></tr>
				</table>
				<details class="distb-adv">
					<summary>Advanced</summary>
					<table class="form-table" role="presentation">
						<tr><th><label for="distb-seed">Seed</label></th>
							<td><input id="distb-seed" type="text" class="regular-text" placeholder="empty = random">
								<p class="description">Same seed + same library = same site. Copy it from a track to replay a build.</p></td></tr>
						<tr><th><label for="distb-kit">Force kit</label></th>
							<td><input id="distb-kit" type="number" min="0" max="9999" class="small-text" value="0">
								<p class="description">0 = random. 3 = always use global_kits/site_3 (for testing one kit).</p></td></tr>
						<tr><th><label for="distb-exclude">Exclude kits</label></th>
							<td><input id="distb-exclude" type="text" class="regular-text" placeholder="3, 17, 42">
								<p class="description">Kit numbers already used in this batch.</p></td></tr>
						<tr><th>Variety</th>
							<td><label><input id="distb-variety" type="checkbox"> No two sections on one page from the same source site</label></td></tr>
						<tr><th><label for="distb-media">Media</label></th>
							<td><select id="distb-media">
								<option value="auto">Media pack, else download from source site</option>
								<option value="pack">Media pack only</option>
								<option value="download">Download from source sites only</option>
								<option value="off">Off (keep remote image URLs)</option>
							</select></td></tr>
						<tr><th>Previous build</th>
							<td><label><input id="distb-replace" type="checkbox" checked> Replace the previous build on this site (media is kept)</label></td></tr>
						<tr><th><label for="distb-track-file">Replay a track</label></th>
							<td><input id="distb-track-file" type="file" accept=".json,application/json">
								<p class="description">Load a track-*.json to rebuild exactly the same picks (site details above are used).</p></td></tr>
					</table>
				</details>
				<p class="distb-actions">
					<button type="button" class="button" id="distb-check">Check requirements</button>
					<button type="button" class="button button-primary" id="distb-plan">Plan build</button>
				</p>
			</div>

			<div class="distb-card distb-side">
				<h2>2. Plan &amp; build</h2>
				<div id="distb-msg" class="distb-msg" hidden></div>
				<ul id="distb-checks" class="distb-checks" hidden></ul>
				<div id="distb-plan-box" hidden>
					<p><strong>Plan <span id="distb-plan-id"></span></strong> · kit <code id="distb-plan-kit"></code> · seed <code id="distb-plan-seed"></code></p>
					<p class="distb-actions">
						<button type="button" class="button button-primary button-hero" id="distb-build">Build site</button>
						<button type="button" class="button" id="distb-replan">New random plan</button>
					</p>
				</div>
				<div id="distb-progress" hidden>
					<div class="distb-bar"><span id="distb-bar"></span></div>
					<ol id="distb-steps" class="distb-steps"></ol>
					<p class="distb-actions">
						<button type="button" class="button button-primary" id="distb-continue" hidden>Continue</button>
						<button type="button" class="button button-primary" id="distb-retry" hidden>Retry failed step</button>
						<button type="button" class="button" id="distb-cancel" hidden>Cancel build</button>
					</p>
				</div>
				<div id="distb-done" hidden>
					<h3>Site built</h3>
					<ul id="distb-pages" class="distb-pages"></ul>
				</div>
			</div>
		</div>

		<div class="distb-card">
			<h2>Build track <button type="button" class="button button-small" id="distb-copy">Copy</button>
				<button type="button" class="button button-small" id="distb-download">Download JSON</button></h2>
			<pre id="distb-track" class="distb-track">No plan yet.</pre>
		</div>
	</section>

	<!-- LIBRARY -->
	<section class="distb-panel" data-panel="library" hidden>
		<div class="distb-card">
			<h2>Library</h2>
			<p>Folder: <code><?php echo esc_html( $distb_lib->root() ); ?></code></p>
			<p class="description">Change it with <code>define( 'DISTB_LIB_DIR', '/path/to/lib' );</code> in wp-config.php to keep a large library outside the plugin.</p>
			<p class="distb-actions">
				<button type="button" class="button" id="distb-lib-refresh">Refresh counts</button>
				<button type="button" class="button button-primary" id="distb-lib-validate">Validate every file</button>
			</p>
			<div id="distb-lib"></div>
		</div>
	</section>

	<!-- HISTORY -->
	<section class="distb-panel" data-panel="history" hidden>
		<div class="distb-card">
			<h2>Build history</h2>
			<table class="widefat striped" id="distb-history">
				<thead><tr><th>Build</th><th>Date</th><th>Status</th><th>Kit</th><th>Seed</th><th>Brand</th><th></th></tr></thead>
				<tbody><tr><td colspan="7">Loading…</td></tr></tbody>
			</table>
		</div>
	</section>

	<!-- RESET -->
	<section class="distb-panel" data-panel="reset" hidden>
		<div class="distb-card">
			<h2>Remove a build</h2>
			<p>Deletes every page, template, menu and (optionally) image the build made, restores pages it updated, and restores the kit settings, front page, site title, permalinks and menu locations from before the build. Content the build did not make is never touched.</p>
			<table class="form-table" role="presentation">
				<tr><th>Build</th><td><code id="distb-reset-id">—</code></td></tr>
				<tr><th><label for="distb-reset-confirm">Confirm</label></th>
					<td><input id="distb-reset-confirm" type="text" class="regular-text" placeholder="type the brand name">
						<p class="description" id="distb-reset-hint"></p></td></tr>
				<tr><th>Media</th><td><label><input type="checkbox" id="distb-reset-keep"> Keep imported images</label></td></tr>
			</table>
			<p><button type="button" class="button button-link-delete" id="distb-reset">Remove this build</button></p>
			<div id="distb-reset-msg" class="distb-msg" hidden></div>
		</div>
	</section>
</div>
