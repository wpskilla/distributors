/* Distribution Builder admin screen. Talks to the distb/v1 REST routes. */
(function () {
	'use strict';

	var $ = function (id) { return document.getElementById(id); };
	var state = { planId: '', buildId: '', running: false, trackJson: null, brand: '' };

	function api(path, method, body) {
		return fetch(DISTB.rest + path, {
			method: method || 'GET',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': DISTB.nonce },
			body: body ? JSON.stringify(body) : undefined
		}).then(function (r) {
			return r.text().then(function (t) {
				var data;
				try { data = JSON.parse(t); } catch (e) {
					throw { message: 'The server returned something that is not JSON (HTTP ' + r.status + '). A PHP error or timeout is likely; check the PHP error log.', raw: t.slice(0, 500) };
				}
				if (!r.ok) { throw data; }
				return data;
			});
		});
	}

	function esc(s) {
		return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	function msg(el, kind, html) {
		el.hidden = false;
		el.className = 'distb-msg distb-' + kind;
		el.innerHTML = html;
	}

	function errorHtml(err) {
		var h = '<strong>' + esc(err.message || 'Error') + '</strong>';
		var list = (err.data && err.data.errors) || err.errors;
		if (list && list.length) {
			h += '<ul>' + list.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul>';
		}
		if (err.raw) { h += '<pre>' + esc(err.raw) + '</pre>'; }
		return h;
	}

	function setTrack(text) { $('distb-track').textContent = text || 'No plan yet.'; }

	/* Tabs */
	document.querySelectorAll('.distb-tabs .nav-tab').forEach(function (tab) {
		tab.addEventListener('click', function (e) {
			e.preventDefault();
			document.querySelectorAll('.distb-tabs .nav-tab').forEach(function (t) { t.classList.remove('nav-tab-active'); });
			tab.classList.add('nav-tab-active');
			document.querySelectorAll('.distb-panel').forEach(function (p) { p.hidden = p.dataset.panel !== tab.dataset.tab; });
			if (tab.dataset.tab === 'library') { loadLibrary(); }
			if (tab.dataset.tab === 'history') { loadStatus(); }
		});
	});

	/* Logo picker */
	$('distb-logo-btn').addEventListener('click', function () {
		if (!window.wp || !wp.media) { window.alert('The WordPress media library did not load on this screen. Reload the page, or pass --logo to WP-CLI.'); return; }
		var frame = wp.media({ title: 'Choose logo', library: { type: 'image' }, multiple: false });
		frame.on('select', function () {
			var a = frame.state().get('selection').first().toJSON();
			$('distb-logo').value = a.id;
			$('distb-logo-preview').innerHTML = '<img src="' + esc(a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url) + '" alt=""> <a href="#" id="distb-logo-clear">remove</a>';
			$('distb-logo-clear').addEventListener('click', function (e) { e.preventDefault(); $('distb-logo').value = 0; $('distb-logo-preview').innerHTML = ''; });
		});
		frame.open();
	});

	/* Track replay file */
	$('distb-track-file').addEventListener('change', function () {
		var f = this.files[0];
		state.trackJson = null;
		if (!f) { return; }
		var reader = new FileReader();
		reader.onload = function () { state.trackJson = reader.result; msg($('distb-msg'), 'info', 'Track loaded. <strong>Plan build</strong> will replay its exact picks.'); };
		reader.readAsText(f);
	});

	function input() {
		return {
			brand: $('distb-brand').value.trim(),
			email: $('distb-email').value.trim(),
			phone: $('distb-phone').value.trim(),
			address: $('distb-address').value.trim(),
			logo_id: parseInt($('distb-logo').value, 10) || 0,
			seed: $('distb-seed').value.trim(),
			force_kit: parseInt($('distb-kit').value, 10) || 0,
			exclude_kits: $('distb-exclude').value.trim(),
			variety: $('distb-variety').checked,
			media: $('distb-media').value,
			replace_previous: $('distb-replace').checked,
			track_json: state.trackJson || ''
		};
	}

	/* Check */
	$('distb-check').addEventListener('click', function () {
		var btn = this; btn.disabled = true;
		api('check', 'POST', {}).then(function (res) {
			var ul = $('distb-checks');
			ul.hidden = false;
			ul.innerHTML = res.checks.map(function (c) {
				return '<li class="distb-' + c.status + '"><span>' + c.status.toUpperCase() + '</span> ' + esc(c.label) + (c.help ? '<small>' + esc(c.help) + '</small>' : '') + '</li>';
			}).join('');
			msg($('distb-msg'), res.ok ? 'ok' : 'error', res.ok ? 'Ready to build.' : 'Fix the FAIL items first.');
		}).catch(function (e) { msg($('distb-msg'), 'error', errorHtml(e)); })
			.finally(function () { btn.disabled = false; });
	});

	/* Plan */
	function plan(fresh) {
		var data = input();
		if (fresh) { data.seed = ''; data.track_json = ''; }
		if (!data.brand) { msg($('distb-msg'), 'error', 'Brand name is required.'); $('distb-brand').focus(); return; }
		$('distb-plan').disabled = true;
		msg($('distb-msg'), 'info', 'Planning: picking the kit and every section, then checking each picked file…');
		api('plan', 'POST', data).then(function (res) {
			state.planId = res.build_id;
			state.brand = data.brand;
			$('distb-plan-id').textContent = res.build_id;
			$('distb-plan-kit').textContent = res.kit;
			$('distb-plan-seed').textContent = res.seed;
			$('distb-plan-box').hidden = false;
			$('distb-done').hidden = true;
			$('distb-checks').hidden = true;
			setTrack(res.track);
			var w = res.warnings || [];
			msg($('distb-msg'), w.length ? 'warn' : 'ok', 'Plan ready. Nothing has been written yet.' + (w.length ? '<ul>' + w.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' : ''));
		}).catch(function (e) {
			msg($('distb-msg'), 'error', errorHtml(e));
			if (e.data && e.data.track) { setTrack(e.data.track); }
		}).finally(function () { $('distb-plan').disabled = false; });
	}
	$('distb-plan').addEventListener('click', function () { plan(false); });
	$('distb-replan').addEventListener('click', function () { plan(true); });

	/* Build */
	$('distb-build').addEventListener('click', function () {
		$('distb-build').disabled = true;
		$('distb-plan-box').hidden = true;
		$('distb-progress').hidden = false;
		$('distb-msg').hidden = true;
		state.buildId = state.planId;
		state.running = true;
		api('build', 'POST', { build_id: state.planId }).then(handleStep).catch(stepError)
			.finally(function () { $('distb-build').disabled = false; });
	});

	function renderSteps(steps, progress) {
		var ol = $('distb-steps');
		ol.innerHTML = Object.keys(steps).map(function (k) {
			var s = steps[k];
			var t = s.ms ? ' <small>' + (s.ms / 1000).toFixed(1) + ' s</small>' : '';
			return '<li class="distb-step-' + s.status + '"><b>' + esc(s.label) + '</b>' + t +
				(s.note ? '<br><small>' + esc(s.note) + '</small>' : '') +
				(s.error ? '<br><em>' + esc(s.error) + '</em>' : '') + '</li>';
		}).join('');
		if (progress !== undefined) { $('distb-bar').style.width = progress + '%'; }
	}

	function handleStep(res) {
		renderSteps(res.steps, res.progress);
		if (res.track) { setTrack(res.track); }
		$('distb-retry').hidden = !res.failed;
		$('distb-cancel').hidden = res.done;
		$('distb-continue').hidden = true;
		if (res.done) {
			state.running = false;
			$('distb-bar').style.width = '100%';
			loadStatus();
			return;
		}
		if (res.failed) {
			state.running = false;
			msg($('distb-msg'), 'error', 'A step failed. Read the error in the list and the track, then press <strong>Retry failed step</strong>.');
			return;
		}
		return api('step', 'POST', {}).then(handleStep).catch(stepError);
	}

	function stepError(e) {
		state.running = false;
		msg($('distb-msg'), 'error', errorHtml(e) + '<p>Press <strong>Continue</strong> to try the next step again.</p>');
		$('distb-continue').hidden = false;
		$('distb-cancel').hidden = false;
	}

	$('distb-retry').addEventListener('click', function () {
		$('distb-retry').hidden = true;
		$('distb-msg').hidden = true;
		state.running = true;
		api('step', 'POST', { retry: true }).then(handleStep).catch(stepError);
	});
	$('distb-continue').addEventListener('click', function () {
		$('distb-continue').hidden = true;
		$('distb-msg').hidden = true;
		state.running = true;
		api('step', 'POST', {}).then(handleStep).catch(stepError);
	});
	$('distb-cancel').addEventListener('click', function () {
		if (!window.confirm('Cancel this build? What it already made stays until you Reset it.')) { return; }
		api('cancel', 'POST', {}).then(function () { state.running = false; loadStatus(); });
	});

	/* Track copy / download */
	$('distb-copy').addEventListener('click', function () {
		var t = $('distb-track').textContent;
		if (navigator.clipboard) { navigator.clipboard.writeText(t); }
		this.textContent = 'Copied';
		var b = this; setTimeout(function () { b.textContent = 'Copy'; }, 1500);
	});
	function download(id) {
		api('track/' + encodeURIComponent(id)).then(function (track) {
			var blob = new Blob([JSON.stringify(track, null, 2)], { type: 'application/json' });
			var a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = 'track-' + id + '.json';
			document.body.appendChild(a); a.click(); a.remove();
		}).catch(function (e) { window.alert(e.message || 'No track'); });
	}
	$('distb-download').addEventListener('click', function () {
		if (state.buildId) { download(state.buildId); } else { window.alert('Start a build first.'); }
	});

	/* Status (on load, after build, history tab) */
	function loadStatus() {
		return api('status').then(function (s) {
			if (s.state) {
				state.buildId = s.state.build_id;
				$('distb-reset-id').textContent = s.state.build_id + ' (' + s.state.status + ')';
				$('distb-progress').hidden = false;
				renderSteps(s.state.steps);
				if (s.track) { setTrack(s.track); }
				var running = s.state.status === 'running';
				var failed = Object.keys(s.state.steps).some(function (k) { return s.state.steps[k].status === 'failed'; });
				$('distb-cancel').hidden = !running;
				$('distb-retry').hidden = !(running && failed);
				$('distb-continue').hidden = !(running && !failed && !state.running);
				if (s.state.status === 'done') { $('distb-bar').style.width = '100%'; }
			}
			if (s.pending && !state.running) {
				state.planId = s.pending.build_id;
				$('distb-plan-id').textContent = s.pending.build_id;
				$('distb-plan-box').hidden = false;
				setTrack(s.pending.track);
			}
			var pages = $('distb-pages');
			if (s.pages && s.pages.length && s.state && s.state.status === 'done') {
				$('distb-done').hidden = false;
				pages.innerHTML = s.pages.map(function (p) {
					return '<li>' + esc(p.title) + ' — <a href="' + esc(p.view) + '" target="_blank">view</a> · <a href="' + esc(p.edit) + '" target="_blank">edit with Elementor</a></li>';
				}).join('');
			}
			var tb = document.querySelector('#distb-history tbody');
			tb.innerHTML = (s.history || []).length ? s.history.map(function (h) {
				return '<tr><td><code>' + esc(h.build_id) + '</code></td><td>' + esc(new Date(h.time * 1000).toLocaleString()) + '</td><td>' + esc(h.status) +
					'</td><td>' + esc(h.kit) + '</td><td>' + esc(h.seed) + '</td><td>' + esc(h.brand) +
					'</td><td><button type="button" class="button button-small" data-dl="' + esc(h.build_id) + '">Track JSON</button></td></tr>';
			}).join('') : '<tr><td colspan="7">No builds yet.</td></tr>';
			tb.querySelectorAll('[data-dl]').forEach(function (b) { b.addEventListener('click', function () { download(b.dataset.dl); }); });
			if (s.state) {
				$('distb-reset-hint').textContent = 'Type the brand name of this build to confirm (or the build ID if the brand is unknown).';
			}
		}).catch(function () {});
	}

	/* Library */
	function loadLibrary() {
		api('library').then(function (l) {
			var h = '<p>Checksum <code>' + esc(l.checksum) + '</code> · media pack: ' + (l.media ? 'yes' : 'no') + '</p>';
			h += '<table class="widefat striped distb-counts"><thead><tr><th>Folder</th><th>Files</th></tr></thead><tbody>';
			Object.keys(l.counts).forEach(function (k) { h += '<tr><td><code>' + esc(k) + '</code></td><td>' + esc(l.counts[k]) + '</td></tr>'; });
			h += '</tbody></table>';
			if (l.errors.length) { h += '<div class="distb-msg distb-error"><ul>' + l.errors.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></div>'; }
			if (l.warnings.length) { h += '<div class="distb-msg distb-warn"><ul>' + l.warnings.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></div>'; }
			$('distb-lib').innerHTML = h;
		}).catch(function (e) { $('distb-lib').innerHTML = '<div class="distb-msg distb-error">' + errorHtml(e) + '</div>'; });
	}
	$('distb-lib-refresh').addEventListener('click', loadLibrary);
	$('distb-lib-validate').addEventListener('click', function () {
		var btn = this; btn.disabled = true;
		$('distb-lib').innerHTML = '<p>Reading every file… (large libraries take a minute; WP-CLI <code>wp distb library validate</code> is faster)</p>';
		api('library/validate', 'POST', {}).then(function (v) {
			var h = '<p><strong>' + v.files + ' files read.</strong> ' + (v.ok ? 'No errors.' : v.errors.length + ' error(s).') + ' ' + v.warnings.length + ' warning(s). ' + v.duplicates.length + ' duplicate section(s).</p>';
			if (v.errors.length) { h += '<div class="distb-msg distb-error"><ul>' + v.errors.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></div>'; }
			if (v.warnings.length) { h += '<div class="distb-msg distb-warn"><ul>' + v.warnings.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></div>'; }
			if (v.duplicates.length) { h += '<h3>Identical sections (keep one)</h3><ul>' + v.duplicates.map(function (d) { return '<li><code>' + esc(d[0]) + '</code> = <code>' + esc(d[1]) + '</code></li>'; }).join('') + '</ul>'; }
			h += '<h3>Widgets used</h3><p>' + Object.keys(v.widgets).map(function (w) { return '<code>' + esc(w) + '</code> ' + v.widgets[w]; }).join(' · ') + '</p>';
			$('distb-lib').innerHTML = h;
		}).catch(function (e) { $('distb-lib').innerHTML = '<div class="distb-msg distb-error">' + errorHtml(e) + '</div>'; })
			.finally(function () { btn.disabled = false; });
	});

	/* Reset */
	$('distb-reset').addEventListener('click', function () {
		var btn = this;
		if (!window.confirm('Remove this build from the site?')) { return; }
		btn.disabled = true;
		api('reset', 'POST', { confirm: $('distb-reset-confirm').value, keep_media: $('distb-reset-keep').checked })
			.then(function (r) { msg($('distb-reset-msg'), 'ok', esc(r.summary)); loadStatus(); })
			.catch(function (e) { msg($('distb-reset-msg'), 'error', errorHtml(e)); })
			.finally(function () { btn.disabled = false; });
	});

	window.addEventListener('beforeunload', function (e) {
		if (state.running) { e.preventDefault(); e.returnValue = ''; }
	});

	loadStatus();
})();
